<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.css" />
</div>

<div class="content-page">
<!-- Start Content here -->
<div class="content">
<?php if($this->session->flashdata('message')):?>
<?=$this->session->flashdata('message')?>
<?php endif?>
<div class="page-heading">
   <h1><i class='fa fa-table'></i>Product List</h1>
   <!-- Button trigger modal -->
   <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
   <i class="fa fa-plus-square" aria-hidden="true">Add New</i>
   </button>
   <hr>
</div>
<!--Modal-->
<div class="row">
   <div class="col-md-12">
      <div class="widget">
         <div class="widget-content">
            <div class="table-responsive">
               <table id="datatables-1" class="table table-bordered" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>Order By</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Photo</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php foreach($member_list as $sl){ ?>
                     <tr>
                        <td><?= $sl['order_by'];?></td>
                        <td><?= $sl['member_name'];?></td>
                        <td><?= $sl['member_desig'];?></td>
                        <td><img width="60px;" height="auto" class=" man_image img-circle center-block zoom-image" src="<?= base_url()?>upload/managing_committee/<?= $sl['member_image'];?>" alt=""></td>
                        
                        
                        <td>
                      <a class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="Update" href="<?php echo base_url();?>web/allproducts_list_edit/<?php echo $sl['member_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
                <a href="<?php echo base_url();?>web/managing_committee_delete/<?php echo $sl['member_id'];?>" class="DeleteCategory btn btn-danger btn-sm" name="B7DFWBPPJM8X3OG" data-toggle="tooltip" data-placement="right" title="" data-original-title="Delete "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                        </td>
                     </tr>
                     <?php 	} ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <!--Content-->
      <div class="modal-content">
         <!--Header-->
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title w-100" id="myModalLabel">Managing Committee</h4>
         </div>
         <!--Body-->
         <div class="modal-body">
            <form  action="" role="form" method="post" enctype="multipart/form-data">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-12 col-md-12">
                        <label>Name</label>
                        <input type="text" name="m_name" id="m_name" class="form-control" required="required"/>
                        <input type="hidden" name="member_id" id="member_id" value="0" />
                     </div>
                     <div class="col-sm-12 col-md-12">
                     <div class="form-group">
                           <label>Description</label>
                           <textarea id="wysiwig_simple" id="m_des" name="m_des"  style="min-height:300px;"> <?= $message[0]['m_des'];?> </textarea>
                           <input type="hidden" name="member_desig" id="member_desig" value="0" />
                        </div>
                      </div>
                 
                     <div class="col-sm-6 col-md-6">
                        <label>Order</label>
                        <input type="text" name="m_order" id="m_order" class="form-control" required="required" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Photo</label>
                        <input type="file" name="m_image" id="m_image">
                     </div>
                  </div>
               </div>
         </div>
         <!--Footer-->
         <div class="modal-footer">
         <button type="reset" class="btn btn-primary reset" id="reset">Clear</button>
         <button type="button" id="alert" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
         <input type="submit" name="submit" value="submit" class="btn btn-success" id="sub"   />
         <input type="submit" value="Update" class="btn btn-success" id="update">				
         </div>
         </form>
      </div>
      <!--/.Content-->
   </div>
</div>
<!-- /.Live preview-->
<!--modal end-->
<?php include 'application/views/includes/footer.php';?>

<script type="text/javascript">
   window.onload = function () {
    // Create Wysiwig editor for textare
    TinyMCEStart('#wysiwig_simple', null);
    TinyMCEStart('#wysiwig_full', 'extreme');
   };
</script>
  
<script>
   function get_edit_data(member_id)
   {
      var member_json=<?= json_encode($member_list); ?>;
      for(i=0; i < member_json.length; i++){
   	   	if(member_json[i].member_id==member_id)
   	   	{
   	   		$('#m_name').val(member_json[i].member_name);
   	   		$('#m_des').val(member_json[i].member_desig);
   	   		$('#m_order').val(member_json[i].order_by);
   	   		
   	   		$('#member_id').val(member_json[i].member_id);
   	   	}
      }
   }
   function get_class_group_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'academic/group_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#group_id').html(html_data);
   			$("#group_id").val($("#group_id option:first").val('all'));
   			document.getElementById('group_id').value = '<?=$this->session->userdata('group_id')?>';
           }
       }
       });  
   }
   
   

   
   
</script>





