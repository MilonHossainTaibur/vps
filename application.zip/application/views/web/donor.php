<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>		
<!--Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<style>

</style>
<div class="content-page">
	<!-- Start Content here -->
	<div class="content">
	<?php if($this->session->flashdata('message')):?>
		<?=$this->session->flashdata('message')?>
	<?php endif?>
		<div class="page-heading">
			<h1><i class='fa fa-table'></i> Donor List</h1>
		</div>
		   <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
   <i class="fa fa-plus-square" aria-hidden="true"> Add Donor</i>
   </button><hr>
		<div class="row">
			<div class="col-md-12">
				<div class="widget">							
					<div class="widget-content">
						<div class="table-responsive">
							<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th>Donor ID</th>
										<th>Donor Name</th>
										<th>Phone</th>
										<th>Address</th>
										<!--th>Create Date</th-->

										<!--th>Image</th-->
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach($donor_list as $sl){ ?>
									<tr>
										<td><?= $sl['id'];?></td>
										<td><?= $sl['donnor_name'];?></td>
										<td><?= $sl['donnor_phone'];?></td>
										<td><?= $sl['donnor_address'];?></td>
										<!--td><?= $sl['created_on'];?></td-->
										
										<td>
											 <a class="test" data-toggle="modal" data-target="#myModal"  href="javascript:void(0)" onClick="get_edit_data(<?= $sl['id'];?>)" title="Edit"><i class="fa fa-edit"></i></a> |
											<a href="<?= base_url();?>web/donor_delete/<?= $sl['id'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a> 
										</td>
									</tr>
									<?php 	} ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <!--Content-->
      <div class="modal-content">
         <!--Header-->
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title w-100" id="myModalLabel">Donor</h4>
         </div>
         <!--Body-->
         <div class="modal-body">
            <form  action="" role="form" method="post" enctype="multipart/form-data">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6 col-md-6">
                        <label>Name ddd</label>
			<input type="text" name="d_name" id="d_name" class="form-control"/>
                        <input type="hidden" name="id" id="id" value="0" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Phone No</label>
		<input type="text" name="d_phone" id="d_phone" class="form-control"/>
                     </div>
                     <div class="col-sm-12 col-md-12">
                        <label>Address</label>
			<textarea  name="d_add" id="d_add" class="form-control"/></textarea>
                     </div>
                     <!--div class="col-sm-6 col-md-6">
                        <label>Photo</label>
                        <input type="file" name="m_image" id="m_image">
                     </div-->
                  </div>
               </div>
         </div>
         <!--Footer-->
         <div class="modal-footer">
         <button type="reset" class="btn btn-primary reset" id="reset">Clear</button>
         <button type="button" id="alert" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
         <input type="submit" name="submit" value="submit" class="btn btn-success" id="sub"   />
         <input type="submit" value="Update" class="btn btn-success" id="update">				
         </div>
         </form>
      </div>
      <!--/.Content-->
   </div>
</div>
<!-- /.Live preview-->
<!--modal end-->

<?php include 'application/views/includes/footer.php';?>
<script>
window.onload=function(){
	
	get_class_section_list(<?=$this->session->userdata('class_id')?>);
	get_class_group_list(<?=$this->session->userdata('class_id')?>);
}
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
			$("#section_id").val($("#section_id option:first").val('all'));
			document.getElementById('section_id').value = '<?=$this->session->userdata('section_id')?>';
        }
    }
    });  
}
function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
			$("#group_id").val($("#group_id option:first").val('all'));
			document.getElementById('group_id').value = '<?=$this->session->userdata('group_id')?>';
        }
    }
    });  
}







   function get_edit_data(id)
   {
      var donor_json=<?= json_encode($donor_list); ?>;
      for(i=0; i < donor_json.length; i++){
   	   	if(donor_json[i].id==id)
   	   	{
   	   		$('#d_name').val(donor_json[i].donnor_name);
   	   		$('#d_phone').val(donor_json[i].donnor_phone);
   	   		$('#d_add').val(donor_json[i].donnor_address);
   	   		$('#id').val(donor_json[i].id);
   	   	}
      }
   }
</script>
