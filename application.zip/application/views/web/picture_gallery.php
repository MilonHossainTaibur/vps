<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-picture-o"></i> Photo Gallery </h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                        <div class="widget-content padding"> <a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Photo</a>
                                            <div class="insertion_div">
											<hr/>
                                                <form action="<?= base_url();?>web/picture_gallery_save" method="POST" enctype="multipart/form-data" >
													<div class="form-group">
														<div class="row">
														   <div class="col-sm-12 col-md-4">
																<label>Photo Caption</label>
																<input type="text" class="form-control" name="photo_caption" id="photo_caption" required />
															</div>
															<div class="col-sm-12 col-md-4">
																<label>Catagory</label>
																<select name="catagory_id" id="catagory_id" class="form-control" required>
																	<option value="">Select Catagory</option>
																		<?php foreach($catagory_list as $catl){ ?>
																	<option value="<?= $catl['catagory_id'];?>"><?= $catl['catagory_name'];?></option>      
																		<?php } ?>
																</select>
															</div>
														</div>
													</div>
													<div class="form-group">
														<div class="row">
														   <div class="col-sm-12 col-md-4">
																<label>Gallery Image</label>
																<input type="file" name="gallery_image_name" id="gallery_image_name" required>
																<p><font color="red">*</font>Photo must be 750 X 570 pixel (width X height) and file size not more than <b>500 KB</b>. Colour Photo is a must.</p>
															</div>
														</div>
													</div>
													<div class="form-group">
														<button type="submit" class="btn btn-primary">Save</button>
													</div>
												</form>
                                            </div>
                                        </div>

                                        <div class="widget-content">
                                            <div id="qq-template-bootstrap">
												<div class="qq-uploader-selector qq-uploader span12">
													<ul style="list-style-type:none;">
														<?php foreach($gallery_image as $img){ ?>
														<li style="float:left; padding:5px; margin:8px;" class="img-thumbnail">
															<img class="qq-thumbnail-selector" src="<?= base_url();?>upload/photo_gallery/<?= $img['gallery_image_name'];?>" alt="" width="150" height="150">
															<div class="pull-justify" style="text-align:center" >
															<?=anchor("web/delete_gallery_image/".$img['photo_gallery_id']."/".$img['gallery_image_name'],"<i class=\"fa fa-remove\"></i> Delete",array('onclick' => "return confirm('Do you want delete this record')"))?>
																
															</div>
														</li>
														<?php } ?>
													</ul>
												</div>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>