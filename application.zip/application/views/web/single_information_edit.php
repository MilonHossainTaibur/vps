<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i> <?= $information_list[0]['information_type'];?></h1>
			</div>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                        <form action="<?= base_url();?>web/information_edit_save" method="POST" enctype="multipart/form-data" id="message-form">
											<div class="form-group">
												<?php  $informations=array('Important Information','Rules & Regulations','Steps','Facility','Principal List','Vice Principal List','Cultural Information'); ?>
												<label>Information Type</label>
													<select class="form-control" name="information_type" id="information_type" required >
														<?php foreach($informations as $info): ?>
														<option value="<?= $info; ?>" <?php if($info == $information_list[0]['information_type']) {echo 'selected';} ?>><?= $info ?></option>
														<?php endforeach; ?>
													</select>
												<input type="hidden" name="info_id" id="info_id" value="<?= $information_list[0]['info_id'];?>">
											</div>
											<div class="form-group">
												<label>Notice Heading</label>
												<input type="text" class="form-control" name="information_heading" value="<?= $information_list[0]['information_heading'];?>">
											</div>
											<div class="form-group">
												<label>Details</label>
												<textarea id="wysiwig_simple" name="information_details" style="min-height:300px;"> <?= $information_list[0]['information_details'];?> </textarea>
											</div>
											<div class="form-group">
												<button type="submit" class="btn btn-primary btn-label-left">Update</button>
											</div>
										</form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<?php include 'application/views/includes/footer.php';?>     

<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>