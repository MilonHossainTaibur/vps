<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-picture-o" aria-hidden="true"></i>
 Slide Image </h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                        <div class="widget-content padding"><a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Image</a>
                                            <div class="insertion_div">
						<hr/>
                                                 <form action="<?php echo base_url();?>web/slide_image_save" method="POST" enctype="multipart/form-data" id="message-form">
							<div class="form-group">
								<div class="row">
									<div class="col-sm-6 col-md-4">
										<label>Slide Caption</label>
										<input type="text" class="form-control" name="slide_caption" id="slide_caption" required />
									</div>
								</div>
							</div>
							<div class="form-group">
								<label>Slide Image</label>
								<input type="file" name="slide_image" id="slide_image"> 
                                                        <p><font color="red">*</font>Photo must be 1140 X 592 pixel (width X height) and file size not more than <b>300 KB. Colour Photo is a must.</p>
                                                    </div>
							<div class="form-group">
								<button type="submit" class="btn btn-primary">Add</button>
							</div>
						</form>
                                            </div>
                                        </div>

                                        <div class="widget-content">
                                            <div id="qq-template-bootstrap">
                                                <div class="qq-uploader-selector qq-uploader span12">
                                                    <ul style="list-style-type:none;">
                                                        <?php foreach($slide_image as $img){ ?>
                                                        <li style="float:left; padding:5px; margin:8px;" class="img-thumbnail">
                                                            <img class="qq-thumbnail-selector" src="<?= base_url();?>upload/slides/<?= $img['slide_image_name'];?>" alt="" width="100" height="100">
                                                            <div class="pull-justify" style="text-align:center" >
                                                                <?=anchor("web/delete_slide_image/".$img['slide_image_id']."/".$img['slide_image_name'],"<i class=\"fa fa-remove\"></i> Delete",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                            </div>
                                                        </li>
                                                        <?php   } ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>
