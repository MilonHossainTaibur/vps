<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
<div class="content">
<div class="page-heading">
   <h1><i class="fa fa-file-text-o"></i> <?= $message[0]['type'];?> Message</h1>
</div>
<div class="row">
   <div class="col-sm-12">
      <div class="widget" style="min-height:500px;">
         <div class="widget-content padding">
            <div class="row">
               <div class="col-md-12">
                  <div class="widget">
                     <form action="<?= base_url();?>web/message_update_save" method="POST" enctype="multipart/form-data" id="message-form">
                        <div class="form-group">
                           <label>Message Type</label>
                           <input type="text" class="form-control" name="type" value="<?= $message[0]['type'];?>">
                           <input type="hidden" name="message_id" id="message_id" value="<?= $message[0]['message_id'];?>">
                        </div>
                        <div class="form-group">
                           <label>Messenger Name</label>
                           <input type="text" class="form-control" name="name" value="<?= $message[0]['name'];?>">
                        </div>
                        <div class="form-group">
                           <label>Message</label>
                           <textarea id="wysiwig_simple" name="message" style="min-height:300px;"> <?= $message[0]['message'];?> </textarea>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-xs-12 col-sm-6">
                                 <label>Current Picture</label>
                                 <?php if($message[0]['image']!=''): ?>
                                 <img src="<?php echo base_url();?>upload/message_image/<?= $message[0]['image'];?>" alt="" height="150" width="150" />    
                                 <?php else: ?>
                                 <img src="<?= base_url();?>upload/message_image/no_picture.png" alt="" height="150" width="150" />
                                 <?php endif; ?>
                                 <input type="hidden" name="image_name" value="<?= $message[0]['image'];?>" />
                              </div>
                              <div class="col-xs-12 col-sm-6">
                                 <label>New Picture</label>
                                 <input type="file" name="image" id="image"> 
                                 <p>Photo must be 200 X 200 pixel (width X height) and file size not more than <b>120 KB. Colour Photo is a must.</p>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <button type="submit" class="btn btn-primary btn-label-left">Update</button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/includes/footer.php';?>      
<script type="text/javascript">
   window.onload = function () {
   	// Create Wysiwig editor for textare
   	TinyMCEStart('#wysiwig_simple', null);
   	TinyMCEStart('#wysiwig_full', 'extreme');
   };
</script>
