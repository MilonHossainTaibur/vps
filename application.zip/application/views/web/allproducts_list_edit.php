<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
<div class="content">
<div class="page-heading">
   <h1><i class="fa fa-file-text-o"></i> <?= $message[0]['type'];?> Message</h1>
</div>
<div class="row">
   <div class="col-sm-12">
      <div class="widget" style="min-height:500px;">
         <div class="widget-content padding">
            <div class="row">
               <div class="col-md-12">
                  <div class="widget">
                     <form action="<?= base_url();?>web/message_update_save" method="POST" enctype="multipart/form-data" id="message-form">
                        <div class="form-group" style="display:none;">
                           <label>Message Type</label>
                           <input type="hidden" name="member_id" id="member_id" value="<?= $product_list[0]['member_id'];?>">
                        </div>
                        <div class="form-group">
                           <label>Product Name</label>
                           <input type="text" class="form-control" name="member_name" value="<?= $product_list[0]['member_name'];?>">
                        </div>
                        <div class="form-group">
                           <label>Discription</label>
                           <textarea id="wysiwig_simple" name="member_desig" style="min-height:300px;"> <?= $product_list[0]['member_desig'];?> </textarea>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-xs-12 col-sm-6">
                                 <label>Current Picture</label>
                                 <?php if($product_list[0]['member_image']!=''): ?>
                                 <img src="<?= base_url()?>upload/managing_committee/<?= $product_list[0]['member_image'];?>" alt="" height="150" width="150" />    
                                 <?php else: ?>
                                 <img src="<?= base_url()?>upload/managing_committee/<?= $product_list[0]['member_image'];?>" alt="" height="150" width="150" />
                                 <?php endif; ?>
                                 <input type="hidden" name="member_image" value="<?= base_url()?>upload/managing_committee/<?= $product_list[0]['member_image'];?>" />
                              </div>
                              <div class="col-xs-12 col-sm-6">
                                 <label>New Picture</label>
                                 <input type="file" name="member_image" id="member_image"> 
                                 <p>Photo must be 200 X 200 pixel (width X height) and file size not more than <b>120 KB. Colour Photo is a must.</p>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <button type="submit" class="btn btn-primary btn-label-left">Update</button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/includes/footer.php';?>      
<script type="text/javascript">
   window.onload = function () {
   	// Create Wysiwig editor for textare
   	TinyMCEStart('#wysiwig_simple', null);
   	TinyMCEStart('#wysiwig_full', 'extreme');
   };
</script>
