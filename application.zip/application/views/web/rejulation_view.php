<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
		<div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i> Rejulation </h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
										<hr/>
                                        <form method="POST" action="<?php echo base_url();?>web/rejulation_save" enctype="multipart/form-data">
											
											<div class="form-group">
												<div class="row">
													 <div class="col-sm-6 col-md-3">
                                                <label>Rejulation Image</label>
                                                <input type="file" class="btn btn-default btn-sm" title="Browse Picture" name="rejulation_image" required />

                                                
                                            </div>
												</div>
                                            </div>
											<div class="form-group">
												<button type="submit" class="btn btn-primary btn-label-left">
                                                   Submit
                                                </button>
											</div>
										</form>
                                    </div>
                                </div>
                           			
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-content">
                                      
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="80%">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                
                                                        <th>Picture</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach($rejulation_viewimage as $tl){ ?>
                                                    <tr>
                                                        <td><?php echo $tl['r_id'];?></td>
                                                        

                                                        <td>
								                        <img src="<?php echo base_url();?>upload/institute_logo/<?php echo $tl['rejulation_image'];?>" height="100" width="100"/>
                                                           
                                                        </td>
							<td>
                                                            <a href="#" class="DeleteCategory btn btn-danger btn-sm" name="B7DFWBPPJM8X3OG" data-toggle="tooltip" data-placement="right" title="" data-original-title="Delete "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php } ?>
                                                   
                                                </tbody>
                                            </table>
                                        
                                    </div>
                                </div>
                            </div>
                       
            </div>


<?php include 'application/views/includes/footer.php';?>    

<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>