<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
             <?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Session List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <!-- Page Heading End-->				<!-- Your awesome content goes here -->
                                <div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                        	<div class="widget-content padding">
                                            	 <a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Session</a>
                                                	<div class="insertion_div">
                                                    	<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>admin/session_save">
                                                        	<div class="form-group">
                                                                <div class="row">
                                                                    <div class="col-sm-1"></div>
                                                                    <div class="col-sm-4">
                                                                        <div class="form-group">
                                                                            <label>Session name </label>
                                                                            <input type="text" class="form-control" name="session_name" id="session_name">
                                                                        </div>
                                                                    </div>
                                                                    <br/>
                                                                    <button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
                                                                     
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                            </div>
                                                    
                                            <div class="widget-content">
                                            	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                	<thead>
                                                    	<tr>
                                                        	<th>Session ID</th>
                                                            <th>Session Name</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php foreach($session_list as $tl){ ?>
                                                    	<tr>
                                                        	<td><?php echo $tl['session_id'];?></td>
                                                            <td><?php echo $tl['session_name'];?></td>
                                                            <td>
                                                                <a href="<?php echo base_url();?>admin/session_edit/<?php echo $tl['session_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
                                                                <a href="<?php echo base_url();?>admin/session_delete/<?php echo $tl['session_id'];?>" title="Delete" onclick="return confirm('Do you want to delete this session?');"><i class="fa fa-remove"></i></a> 
                                                            </td>
                                                        </tr>
                                                    <?php    } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				

				
				

				
<?php include 'application/views/includes/footer.php';?>