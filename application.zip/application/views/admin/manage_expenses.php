<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Manage Expenses</h1>
                </div>
				
				<?php if($this->session->flashdata('message')):?>
				<div class="alert alert-success">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
					<?=$this->session->flashdata('message')?>
				</div>
				<?php endif?>
	
				
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
					
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" name="registerForm" method="POST" action="<?php echo base_url();?>admin/manage_expenses_save" enctype="multipart/form-data">
									
									<div class="form-group">
										<ul class="list-unstyled">
											<li><a href="<?php echo base_url();?>admin/manage_expenses_list" class="text-muted small">Manage Expenses View</a></li>
										</ul>
									</div>
										

									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>Pay to (Name) <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="pay_to_name" id="pay_to_name" required>
                                            </div>
                                            
											<div class="col-sm-6">
                                                <label>Expenses Name <span style="color:red;">*</span></label>
                                                <select class="form-control" name="coa_id" id="coa_id" required>
                                                    <option value="">Select</option>
                                                    <?php
														foreach($coa_list as $row){ ?>
														<option value="<?php echo $row['id'];?>"><?php echo $row['ac_name'];?></option>
													<?php  } ?>
                                                </select>			
                                            </div>
                                        </div>
                                    </div>									
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>Designation <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="designation" id="designation" required>
                                            </div>
                                            
											<div class="col-sm-6">
                                                <label>Amount <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="dr_amount" id="dr_amount" required>
                                            </div>
                                        </div>
                                    </div>
									
                                    <div class="form-group">
                                        <div class="row">
											<div class="col-sm-12">
                                                <label>Remark</label>
                                                <textarea name="remark" id="remark" cols="30" rows="5" style="width:100%;resize:none"></textarea>
                                            </div>
                                        </div>
                                    </div>
									<button type="submit" class="btn btn-primary">Insert</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				

				
<?php include 'application/views/includes/footer.php';?>
                
<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}
</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>

<!--For Calculating Age---->
<script> 
function myAgeValidation() { 
    var lre = /^\s*/;
    var datemsg = "";    
    var inputDate = document.registerForm.birth_date.value;
    inputDate = inputDate.replace(lre, "");
    document.registerForm.birth_date.value = inputDate;
    datemsg = isValidDate(inputDate);
        if (datemsg != "") {
            alert(datemsg);
            return;
        }
        else {
            //Now find the Age based on the Birth Date
            getAge(new Date(inputDate));
        }
 
}
 
function getAge(birth) { 
    var today = new Date();
    var nowyear = today.getFullYear();
    var nowmonth = today.getMonth();
    var nowday = today.getDate();
 
    var birthyear = birth.getFullYear();
    var birthmonth = birth.getMonth();
    var birthday = birth.getDate();
 
    var age = nowyear - birthyear;
    var age_month = nowmonth - birthmonth;
    var age_day = nowday - birthday;
    
    if(age_month < 0 || (age_month == 0 && age_day <0)) {
            age = parseInt(age) -1;
        }		
    //alert(age);
	document.getElementById('age').value=age;	
}
 
function isValidDate(dateStr) {
    var msg = "";    
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;
 
    var matchArray = dateStr.match(datePat); // is the format ok?
    if (matchArray == null) {
        msg = "Date is not in a valid format.";
        return msg;
    }
 
    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[4]; 
    
    if (month < 1 || month > 12) { // check month range
        msg = "Month must be between 1 and 12.";
        return msg;
    }
 
    if (day < 1 || day > 31) {
        msg = "Day must be between 1 and 31.";
        return msg;
    }
 
    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        msg = "Month "+month+" doesn't have 31 days!";
        return msg;
    }
 
    if (month == 2) { // check for february 29th
    var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
    if (day>29 || (day==29 && !isleap)) {
        msg = "February " + year + " doesn't have " + day + " days!";
        return msg;
    }
    }
 
    if (day.charAt(0) == '0') day= day.charAt(1);
    return msg;  // date is valid
}
 
</script>