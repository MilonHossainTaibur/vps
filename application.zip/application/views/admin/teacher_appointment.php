<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
            <?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
            
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Teachers Appointment</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
            	<!-- Page Heading End-->				<!-- Your awesome content goes here -->
				<div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content">
                                                New Teacher Appoint- <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
                                                        <div class="insertion_div">
                                                            <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/teacher_appointment_save" enctype="multipart/form-data">
                                                                <div class="form-group">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                              <label>Teacher Name</label>
                                                                            <select class="form-control" name="teacher_id" id="teacher_id">
                                                                                <option value="">Select</option>
                                                                                <?php
                                                                                    foreach($teacher_list as $tl){ ?> 
                                                                                <option value="<?php echo $tl['teacher_id'];?>"><?php echo $tl['teacher_name'];?></option>
                                                                              <?php } ?>
                                                                              </select>
                                                                        </div>

                                                                        <div class="col-sm-4">
                                                                            <label>Salary</label>
                                                                            <input type="text" class="form-control" name="salary" id="salary">

                                                                        </div>

                                                                        <div class="col-sm-4">
                                                                            <label></label>

                                                                            <button type="submit" class="btn btn-primary" style="margin-top:25px;" onclick="">Appointment</button>
                                                                        </div>
                                                                    </div>
                                                                </div> 
                                                            </form>
                                                        </div>
                                                
                                                <hr/>
                                                
                                                <div class="widget-content">
                                                        <div class="table-responsive">
                                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Name</th>
                                                                        <th>Department</th>
                                                                        <th>Designation</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php
                                                                        foreach($appoint_list as $al){ ?>
                                                                    <tr>
                                                                        <td><?php echo $al['teacher_name'];?></td>
                                                                        <td><?php echo $al['department_name'];?></td>
                                                                        <td><?php echo $al['designation_name'];?></td>

                                                                        <td>
                                                                            <a href="<?php echo base_url();?>admin/appointment_view/<?php echo $al['appointment_id'];?>" title="View"><i class="fa fa-retweet"></i></a> | <a href="<?php echo base_url();?>admin/appointment_edit/<?php echo $al['appointment_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <a href="<?php echo base_url();?>admin/appointment_delete/<?php echo $al['appointment_id'];?>" title="Delete"><i class="fa fa-remove"></i></a> 
                                                                        </td>
                                                                    </tr>
                                                                    <?php    } ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                
                                            </div>
                                        </div>
                                    </div>
				</div>
                            </div>
                        </div>
                    </div>
                </div>
			
				
<?php include 'application/views/includes/footer.php';?>


                

