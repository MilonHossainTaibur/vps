<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Class List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <!-- Page Heading End-->
                                <div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                        	<div class="widget-content padding">
                                            <a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Class</a>
<hr>
                                                <div class="insertion_div">
                                                    <div class="widget-content padding">
                                                        <form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>admin/class_save">
                                                            <div class="form-group">
                                                                <div class="row">
                                                                    <div class="col-sm-4">
                                                                        <label>Class name </label>
                                                                        <input type="text" class="form-control" name="class_name" id="class_name" required>
                                                                    </div>
                                                                            
                                                                    <div class="col-sm-4">
                                                                        <label>Class Short Code </label>
                                                                        <input type="text" class="form-control" name="class_short_form" required pattern="[0-9]*" id="class_short_form" placeholder="00">
                                                                        <span style="font-weight:bold;"> NB: </span>Before class one Evere class short name is 0 .<br />
                
                                                                        <span style="font-weight:bold;"> Example: </span> For class KG/Baby class class short is 0, for class ONE class short code 1...
                                                                    </div>
                                                                </div>        
                                                            </div>            
                                                             <div class="form-group">
                                                                <div class="row">
                                                                    <div class="col-sm-4">
                                                                        <button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
                                                                    </div>    
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                                
                                                <div class="widget-content">
                                                    <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Class ID</th>
                                                                    <th>Class Name</th>
                                                                    <th>Class Short Code</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                    <?php foreach($class_list as $tl){ ?>
                                                                <tr>
                                                                    <td><?php echo $tl['class_id'];?></td>
                                                                    <td><?php echo $tl['class_name'];?></td>
                                                                    <td><?php echo $tl['class_short_form'];?></td>
                                                                    <td>
                                                                        <a href="<?php echo base_url();?>admin/class_edit/<?php echo $tl['class_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
                                                                        <?=anchor("admin/class_delete/".$tl['class_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                                    </td>
                                                                </tr>
                                                                <?php    } ?>
                                                            </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            	</div>
                        	</div>
                    	</div>
                	</div>
<?php include 'application/views/includes/footer.php';?>