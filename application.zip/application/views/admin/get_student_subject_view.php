<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <tr>
        <th>Student id</th>
        <th>Student Name</th>
        <th>Optional Subject</th>
        <th>Compulsory Subject</th>        
        <th>Action</th>
    </tr>
<?php
    foreach($subject_list as $sl){  ?>
    <tr>
        <td><?= $sl['student_id']; ?></td>
        <td><?= $sl['student_name']; ?></td>
        <td>
        <?php 
          $opts=explode(',',$sl['opt']);
				$optss='';
                foreach($opts as $opt):
					if($opt)
						$optss.=$opt.', ';
				endforeach;
				
				echo rtrim($optss,', ');?>
        </td>
        <td>
            <?php
            
            
            
				$coms=explode(',',$sl['com']);
				$comss='';
                foreach($coms as $com):
                if($com)
                	$comss.=$com.', ';
					//echo $com;
			
				endforeach;
				echo rtrim($comss,', ');
				
				
				
            ?>
        </td>
        <td>
            <a href="<?php echo base_url();?>admin/student_subject_edit/<?= $sl['student_id']; ?>/<?= $data['class_id']; ?>/<?= $data['group_id']; ?>/<?= $data['session_id']; ?>" title="Edit">
                <i class="fa fa-edit"></i>
            </a>
        </td>
    </tr>
<?php    } ?>
</table>