<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
            <?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
            
            
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Debit Voucher List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
            	<!-- Page Heading End-->				<!-- Your awesome content goes here -->
				<div class="row">				
					<div class="col-md-12">
						<div class="widget">
                                                    
                                                    
                                                    
							<div class="widget-content padding">
								Add Debit Voucher - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
								<div class="insertion_div">
									<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>admin/voucher_save">
										<div class="form-group">
											<div class="row">
												<div class="col-sm-1"></div>
												<div class="col-sm-4">
													<div class="form-group">
														<label> Pay T0 </label>
														<input type="text" class="form-control" name="from_to" id="from_to">
													</div>
												</div>
												
												<div class="col-sm-4" style="margin-top:0px;margin-left:10px;">
													<div class="form-group">
														<label>Purpose of Payment </label>
														<select class="form-control" name="purpose" id="purpose">
														<?php
														foreach($account_name as $chartof_acc){ ?>
														<option value="<?php echo $chartof_acc['id']; ?>"><?php echo $chartof_acc['accounts_name']; ?></option>
														
														<?php } ?>															
														</select>
														<input type="hidden" class="form-control" name="tttype" id="tttype" value="debit">
													</div>
												</div>
												
												<!--<br/>
												<button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button> -->
											</div>
											
											<div class="row">
												<div class="col-sm-1"></div>
												<div class="col-sm-4">
													<div class="form-group">
														<label> Amount </label>
														<input type="text" class="form-control" name="amount" id="amount">
													</div>
												</div>
												
												
												<br/>
												<button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
											</div>
											
											
										</div>
									</form>
								</div>
							</div>
							
							
							<!--  Voucher List  -->
							
							<div class="widget-content">
								<div class="table-responsive">
									<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>Voucher ID</th>
												<th>Pay To</th>
												<th>Amount</th>
												<th>Date</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($voucher_list as $v){ ?>
											<tr>
												<td><?php echo $v['voucher_id'];?></td>
												<td><?php echo $v['from_to'];?></td>
												<td><?php echo $v['amount'];?></td>
												<td><?php echo $v['created_on'];?></td>

												<td>
													<a href="<?php echo base_url();?>admin/department_edit/<?php echo $dl['department_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <a href="<?php echo base_url();?>admin/department_delete/<?php echo $dl['department_id'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a> 
												</td>
											</tr>
											<?php    } ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>

                            </div>
                        </div>
                    </div>
                </div>
				

				
				

				
<?php include 'application/views/includes/footer.php';?>