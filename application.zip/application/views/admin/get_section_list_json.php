<?php
if($section_list && $class_id)
{
    foreach($section_list as $sList)
    {
        $section_id = $sList['section_id'];
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        
        $sql = "SELECT class_section_id FROM tbl_class_section WHERE school_id = $school_id AND class_id = $class_id AND section_id = $section_id LIMIT 1";
        $query = $this->db->query($sql);
        $row = $query->row_array();
        if($row['class_section_id'])
        {
            $checked = 'checked="checked"';
        }
        else 
        {
            $checked = '';
        }
?>
        <div class="rowBox">
            <div class="rowBox_lft">                
                <div class="input_div_l">
                    <input <?php echo $checked?> type="checkbox" id="section_<?php echo $sList['section_id']?>" name="section_name[<?php echo $sList['section_id']?>]" value="<?php echo $sList['section_id']?>" /> <?php echo $sList['section_name']?>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div> 
        </div>
        <div class="clear"></div> 


<?php
    }
    ?>     
        <div class="lavel_div">&nbsp;</div>
        <div class="clear"></div>

        <div class="rowBox">            
            <div class="rowBox_lft">                
                <div class="input_div_l">
                    <button type="submit" class="btn btn-primary" style="margin-top:25px;" onclick="">Save</button>
                </div>
                <div class="clear"></div>
            </div>           

            <div class="clear"></div>
        </div>
        <div class="clear"></div>
                
   <?php     
}
?>