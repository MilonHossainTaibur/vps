<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
            <!-- Page Heading Start -->
            <div class="page-heading">
                <h1><i class='fa fa-check'></i> Designation List</h1>
            </div>
			<!-- Page Heading End-->
            <!-- Your awesome content goes here -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
							<div class="row">				
								<div class="col-md-12">
									<div class="widget">
                                        <div class="widget-content padding">
                                            Add New Designation - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
											<div class="insertion_div">
											<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>admin/designation_save">
												<div class="form-group">
													<div class="row">
														<div class="col-sm-1"></div>
														<div class="col-sm-4">
															<div class="form-group">
																<label>Designation name </label>
																<input type="text" class="form-control" name="designation_name" />
															</div>
														</div>
														<div class="col-sm-4">
															<div class="form-group">
																<label>Designation name (বাংলায়)</label>
																<input type="text" class="form-control" name="bn_designation_name" />
															</div>
														</div>
														<br/>
														<button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
													</div>
												</div>
											</form>
											</div>
										</div>
                                        <div class="widget-content">
                                            <div class="table-responsive">
                                                <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Designation ID</th>
                                                            <th>Designation Name</th>
                                                            <th>Designation name (বাংলায়)</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach($designation_list as $dl){ ?>
                                                        <tr>
                                                            <td><?php echo $dl['designation_id'];?></td>
                                                            <td><?php echo $dl['designation_name'];?></td>
                                                            <td><?php echo $dl['bn_designation_name'];?></td>
															<td>
                                                                <a href="<?php echo base_url();?>admin/designation_edit/<?php echo $dl['designation_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <a href="<?php echo base_url();?>admin/designation_delete/<?php echo $dl['designation_id'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a> 
                                                            </td>
                                                        </tr>
                                                        <?php    } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
									</div>
								</div>
							</div>
						</div>
                    </div>
                </div>
            </div>
<?php include 'application/views/includes/footer.php';?>