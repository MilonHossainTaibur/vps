<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
	<div class="content">
		<?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Teachers/Staff Salary Structure</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
						<div class="row">				
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-content">
                                        <a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Teacher/Staff Salary</a>
                                        <div class="insertion_div">
                                            <form method="POST" action="<?php echo base_url();?>admin/teacher_salary_structure_save">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <label>Teacher/Staff Name</label>
                                                            <select class="form-control" name="teacher_id" id="teacher_id">
                                                                <option value="">----Select Teacher/Staff----</option>
                                                                <?php foreach($teacher_list as $tl){ ?> 
                                                                <option value="<?= $tl['teacher_id'];?>"><?= $tl['teacher_name'];?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
													<?php 
														if($salary_cat):
															foreach($salary_cat as $sc):
													?>
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <label><?= $sc['salary_particulars']?></label>
                                                            <input type="text" class="form-control salary_particulars" id="<?= $sc['effect']?>" name="amount[]" onkeyup="totalsalary()">
                                                            <input type="hidden" name="effect[]" value="<?= $sc['effect']?>">
                                                            <input type="hidden" name="salary_particulars[]" value="<?= $sc['id']?>">
                                                        </div>
                                                    </div>
													<?php endforeach; endif; ?>
													<div class="row">
														<div class="col-sm-6">
															<label>Total</label>
															<input type="text" class="form-control" id="total" readonly="">
														</div>
													</div>
                                                    <button type="submit" class="btn btn-primary" style="margin-top:25px;" onclick="">Save</button>
                                                </div> 
                                            </form>
                                        </div>
                                        <hr/>
                                        <div class="widget-content">
                                            <div class="table-responsive">
                                                <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Name</th>
															<th>Department</th>
															<th>Designation</th>
															<th>Action</th>
														</tr>
													</thead>
													<tbody>
                                                        <?php  foreach($salary_list as $sl){ ?>
                                                        <tr>
                                                            <td><?= $sl['teacher_name'];?></td>
                                                            <td><?= $sl['department_name'];?></td>
                                                            <td><?= $sl['designation_name'];?></td>
															<td><a href="<?= base_url();?>admin/salary_structure_view/<?= $sl['teacher_id'];?>" title="View"><i class="fa fa-retweet"></i></a> | <a href="<?= base_url();?>admin/salary_structure_edit/<?= $sl['teacher_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
															 <?=anchor("admin/salary_structure_delete/".$sl['teacher_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                            </td>
                                                        </tr>
                                                        <?php } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
						</div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">

function totalsalary(){
	var total=0;
	$( ".salary_particulars" ).each(function() {
		// particulars value
		var field1=$(this).val();
		if(field1=="" || field1!=parseFloat(field1)) field1=0;
		// add or reduce value
		if($(this).attr("id")=="-")
		total -=parseFloat(field1);
		else
		total +=parseFloat(field1);
	});
	$( "#total" ).val(total);
}
</script>

