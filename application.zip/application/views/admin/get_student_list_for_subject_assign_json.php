<hr />
<div class="form-group">
    <div class="row">        
        <div class="col-sm-12">
            <table class="table table-bordered table-striped">
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Optional Subject</th>
                    <th>Compulsory Subject</th>
                </tr>
           
            <?php
            foreach($student_list as $sl){ ?>
                <tr>
                    <td>
                        <?php echo $sl['student_id'];?> 
                    </td>
                    <td><?php echo $sl['student_name'];?></td>
                    <td><?php foreach($subject_list as $sublist){ ?>
						<input type="checkbox" name="subject_op[]" value="<?= $sl['student_id'];?>,<?= $sublist['subject_id'];?>,1"/>
						<?php echo $sublist['subject_name'];?>- <?php echo $sublist['subject_code'];?><br/>
						<?php 	} ?>
                    </td>
                     <td><?php foreach($subject_list as $sublist){ ?>
						<input type="checkbox" name="subject_com[]" value="<?= $sl['student_id'];?>,<?= $sublist['subject_id'];?>,0"/>
						<?php echo $sublist['subject_name'];?>- <?php echo $sublist['subject_code'];?><br/>
						<?php 	} ?>
                    </td>
                </tr>
                
                
        <?php 	} ?>
            </table>
        </div>       
    </div>
</div>
<hr />

<div class="form-group">
    <div class="row">
        <div class="col-sm-4">
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </div>
</div>