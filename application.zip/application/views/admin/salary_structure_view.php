<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!--Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Teachers/Staff Salary Structure View</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
						<div class="form-group">
                            <div class="row">
                                <div class="col-sm-12">
                                   <center>
                                        <h2><?= $teacher_list[array_search($teacher_details['teacher_id'], array_column($teacher_list, 'teacher_id'))]['teacher_name'] ?></h2>
                                        <h4><?= $teacher_list[array_search($teacher_details['teacher_id'], array_column($teacher_list, 'teacher_id'))]['department_name'] ?></h4>
                                        <h4><?= $teacher_list[array_search($teacher_details['teacher_id'], array_column($teacher_list, 'teacher_id'))]['designation_name'] ?></h4>
                                    </center>
                                </div>
                            </div>
                        </div>
						<div class="form-group">
                            <div class="row">
                                <div class="col-sm-12 col-md-6 col-md-offset-3">
									<table class="table table-striped table-bordered" cellspacing="0" width="60%">
										<?php $total=0; if($salary_list): foreach($salary_list as $sl): ?>
										<tr>
											<td><b><?= $sl['salary_particulars']?></b></td>
											<td><?= $sl['amount']?><?php if( $sl['effect']=="+") $total+=$sl['amount']; else $total-=$sl['amount'];?></td>
										</tr>
										<?php endforeach; endif; ?>
										<tr>
											<td><b>Total</b></td>
											<td><?= $total ?></td>
										</tr>
									</table>
								</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>