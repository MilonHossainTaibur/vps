<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            	
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Teacher Registration</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12 col-md-10 col-md-offset-1">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
							<span> All Information should be </span>
                                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/teacher_registration_save" enctype="multipart/form-data">
                                    <legend><i class="icon32 icon-square-plus"></i> A. Personal Details</legend>
                                    <div class="form-group">
                                        <div class="row">                                              
                                            <div class="col-sm-6">
						<label>Name <span style="color:red;">*</span></label>
						<input type="text" class="form-control" name="teacher_name" id="teacher_name"  />
                                            </div>
					    <div class="col-sm-6">
						<label>Name (বাংলায়)</label>
						<input type="text" class="form-control" name="teacher_name_bn" />
                                            </div>
					    <div class="col-sm-6">
                                                <label>Father's name <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="father_name" id="father_name"  />
                                            </div>
                                            <div class="col-sm-6">
                                                <label>Mother's name <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="mother_name" id="mother_name"  />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Date of Birth <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control datepicker-input" placeholder="YYYY-MM-DD" name="birth_date" />
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Gender <span style="color:red;">*</span></label>
                                                <select class="form-control" name="gender" id="gender"  />
                                                    <option value="">Select</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Religion <span style="color:red;">*</span></label>
                                                <select class="form-control" name="religion" id="religion"  />
                                                    <option value="">Select</option>
                                                    <option value="1"> Islam </option>
                                                    <option value="2">Hinduism</option>
                                                    <option value="3">Christianity</option>
                                                    <option value="4">Buddhism</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Marital Status <span style="color:red;">*</span></label>
                                                <select class="form-control" name="marital_status" id="marital_status" onChange="is_married(this.value)" >
                                                    <option value="">Select</option>
                                                    <option value="Married">Married</option>
                                                    <option value="Unmarried">Unmarried</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4 spouse" style="display:none;">
                                                <label>Spouse </label>
                                                <input type="text" class="form-control" name="spouse_name" id="spouse_name">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <h4> Present Address</h4>
									<div class="form-group">
                                        <label>Address <span style="color:red;">*</span></label>
                                        <input type="text" class="form-control" name="present_address" id="present_address" />
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Thana <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="present_thana" id="present_thana" />
                                            </div>
                                            <div class="col-sm-4">
                                                <label>District <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="present_district" id="present_district" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr/>
					<h4> Permanent Address</h4>
                                    
                                    <div class="form-group">
                                        <label>Address <span style="color:red;">*</span></label>
                                        <input type="text" class="form-control" name="permanent_address" id="permanent_address"  />
                                    </div>
                                    <div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-4">
                                                <label>Thana <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="permanent_thana" id="permanent_thana"  />
                                            </div>
                                            <div class="col-sm-4">
                                                <label>District <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="permanent_district" id="permanent_district"  />
                                            </div>
                                        </div>
                                    </div>
									<hr/>
                                    <legend><i class="icon32 icon-square-plus"></i>B. Educational Qualification</legend>
                                 	<div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-3">
						<label>Degree/Diploma <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="degree[]" id="degree"  />
					    </div>
					    <div class="col-sm-3">
						<label>School/College/University <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="institute[]" id="institute"  />
					    </div>
					    <div class="col-sm-3">
						<label>Result <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="result[]" id="result"  />
					    </div>
						<div class="col-sm-3">
							<label>Passing Year <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="passing_year[]" id="passing_year"  />
						</div>
                                        </div>
                                    </div>
                                    <span id="add_edu_box">
                                    <!-- add more box if user want to add more education -->
                                    </span>
                                    <div><a herf="#" onClick="add_more_edu()" style="cursor:pointer;" >Add More</a></div>
                                    <br/>
                                    
                                    <legend><i class="icon32 icon-square-plus"></i>C. Other Info</legend>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Account Number</label>
                                                <input type="text" class="form-control" name="account_number" id="account_number">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Bank Name</label>
                                                <input type="text" class="form-control" name="bank_name" id="bank_name">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Branch Name</label>
                                                <input type="text" class="form-control" name="branch_name" id="branch_name">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                        	
                                        	 <div class="col-sm-4">
                                                <label>Blood group</label>
                                                <select class="form-control" name="blood_group" id="blood_group">
                                                    <option value="">Select</option>
                                                    <option value="AB+">AB+</option>
                                                    <option value="AB−">AB−</option>
                                                    <option value="B+">B+</option>
                                                    <option value="B−">B−</option>
                                                    <option value="A+">A+</option>
                                                    <option value="A−">A−</option>
                                                    <option value="O+">O+</option>
                                                    <option value="O−">O−</option>
                                                </select>                                      
                                            </div>                                          
                                            <div class="col-sm-4">
                                                <label>Nationality <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="nationality" id="nationality"  />
                                            </div>
                                            <div class="col-sm-4">
                                                <label>National ID Card No. </label>
                                                <input type="text" class="form-control" name="national_id_card_no" id="national_id_card_no">
                                            </div>
                                        </div>
                                    </div>
                                    
                                   
                                    <div class="form-group">
                                        <div class="row">
                                           <div class="col-sm-4">
                                                <label>E-Mail</label>
                                                <input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Email">
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Contact Number <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" data-mask="01999999999" placeholder="8801*********" name="present_contact" id="present_contact"  />
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Department</label>
                                                <input type="text" class="form-control" id="department_id" name="department_id">
                                               
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-6 col-md-3">
                                                <label>Designation <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" id="designation_id" name="designation_id">
                                             
                                            </div> 
                                            <div class="col-sm-6 col-md-3">
                                                <label>Date of Joining <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control datepicker-input" placeholder="mm/dd/yyyy" name="joining_date" id="joining_date" />
                                            </div>
                                            <div class="col-sm-6 col-md-3">
                                                <label>Date of MPO</label>
                                                <input type="text" class="form-control datepicker-input" placeholder="mm/dd/yyyy" name="mpo_date" id="joining_date" />
                                            </div>
											<div class="col-sm-6 col-md-3">
                                                <label>Index No</label>
                                                <input type="text" class="form-control" name="index_no"/>
                                            </div>
                                        </div>
                                    </div>
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-md-3">
                                                <label>User Name</label>
                                                <input type="text" class="form-control" id="user_name" name="user_name" onkeyup="check_user_name(this.value);" onblur="check_user_name(this.value);"/>
												<span id="user_wrong"></span>
                                            </div>
											<div class="col-sm-6 col-md-3">
                                                <label>Password</label>
                                                <input type="text" class="form-control" name="password"/>
                                            </div>
                                            <div class="col-sm-6 col-md-3">
                                                <label>Teacher Image</label>
                                                <input type="file" class="btn btn-default btn-sm" title="Browse Picture" name="teacher_image" id="teacher_image" />
                                                <output id="list"></output>
                                            </div>
											<div class="col-sm-6 col-md-3">
                                                <label>Teacher Certificate</label>
                                                <input type="file" class="btn btn-default btn-sm" title="Browse PDF" name="teacher_certificate" />
                                            </div>
                                        </div>
                                    </div>
                                     
                                    <button type="submit" class="btn btn-primary">Register</button>
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
				
			
<?php include 'application/views/includes/footer.php';?>
<script src="<?= base_url();?>template/js/jquery.ajaxfileupload.js"></script>
<script>
function is_married(value)
{
	if(value=='Married')
	{
		$( ".spouse" ).show( "slow" );
	}
	else
	{
		$( ".spouse" ).hide( "slow" );	
	}
}
function add_more_edu()
{
	uid=new Date().getTime();
	$('#add_edu_box').append('<div class="form-group" id="'+uid+'"><div class="row"><div class="col-sm-3"><input type="text" class="form-control" name="degree[]" id="degree" required /></div><div class="col-sm-3"><input type="text" class="form-control" name="institute[]" id="institute" required /></div><div class="col-sm-3"><input type="text" class="form-control" name="result[]" id="result" required /></div><div class="col-sm-2"><input type="text" class="form-control" name="passing_year[]" id="passing_year" required /></div><div class="col-sm-1"><a herf="#" onclick="remove_div(\''+uid+'\')"><i class="fa fa-remove"></i></a></div></div></div>');
		
}
function check_user_name(user_name)
{
	$.ajax({
    type: "POST",
    url: baseUrl + 'login/check_user_name',
    data:
    {
        'user_name':user_name
    }, 
    success: function(html_data)
    {
        if (html_data == 1)
        {
            $('#user_wrong').html('<div class="alert alert-danger">This user name is not available. Please try another user name<div>');
			$( "#user_name" ).focus();
        }
		else{
			$('#user_wrong').html('');
		}
    }
    });  
}
function remove_div(id)
{
	$( "#"+id ).remove();
}
/*

// uoplad image
function upload_file(){
alert($('#teacher_name').val());
    $.ajaxFileUpload({
        url:baseUrl + 'admin/teacher_image_upload',
        secureuri:false,
        fileElementId:'image',
        dataType: 'json',
        data    : {
            'teacher_image' : $('#teacher_image').val(),
            'teacher_name' : $('#teacher_name').val()
        },
        success: function (data, status){alert(data);
            if( data.error != '' ){
                console.log(data.error);
            }else{
				alert(data.msg);
                //console.log(data.msg);
                // Refresh image list
                }
            },
        error: function (data, status, e){alert(data);
           // console.log(e);
        }
    });
}*/

 function handleFileSelect(evt) {
    var files = evt.target.files; // FileList object

    // Loop through the FileList and render image files as thumbnails.
    for (var i = 0, f; f = files[i]; i++) {

      // Only process image files.
      if (!f.type.match('image.*')) {
        continue;
      }

      var reader = new FileReader();

      // Closure to capture the file information.
      reader.onload = (function(theFile) {
        return function(e) {
          // Render thumbnail.
          var span = document.createElement('span');
          span.innerHTML = ['<img class="thumb" height="200" width="200" src="', e.target.result,
                            '" title="', escape(theFile.name), '"/>'].join('');
          document.getElementById('list').innerHTML=span.innerHTML;
        };
      })(f);

      // Read in the image file as a data URL.
      reader.readAsDataURL(f);
    }
  }

  document.getElementById('teacher_image').addEventListener('change', handleFileSelect, false);
</script>