<table border="1" id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%" style="text-align:center;">
	<thead>
		<tr>
			<th>Student ID</th>
			<th>Name</th>
			<th>Father Name</th>
			<th>Mother Name</th>
			<!--th>Present Address</th>
			<th>Permanaent Address</th-->
			<th>Class</th>
			<th>Roll</th>
			<th>Section</th>
			<th>Date of birth</th>
			<th>Nationality</th>
			<th>Photo</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($student_list as $sl){ ?>
		<tr>
			<td><?= $sl['student_id'];?></td>
			<td><?= $sl['student_name'];?></td>
			<td><?= $sl['father_name'];?></td>
			<td><?= $sl['mother_name'];?></td>
			<!--td><?= $sl['present_address'];?><?= $sl['present_po'];?><?= $sl['present_upazila'];?><?= $sl['present_district'];?><?= $sl['present_division'];?></td-->
			<td><?= $sl['class_name'];?></td>
			<td><?= $sl['roll_no'];?></td>
			<td><?= $sl['section_name'];?></td>
			<td><?= $sl['birth_date'];?></td>
			
			<td><?= $sl['nationality'];?></td>
			<td><?php if(!empty($sl['student_image'])){ ?>
	<img class="zoom-image img-responsive center-block" src="<?= base_url()?>upload/student_image/<?= $sl['student_image'];?>" width="40" class="stu_image" />								
	<?php 

	}else{
	 
	?>
	<img class="zoom-image img-responsive center-block" src="<?= base_url() ?>template/assets/images/no_image.png" width="40" class="stu_image" /> 
	<?php  } ?></td>
			
		</tr>
		<?php 	} ?>
	</tbody>
</table>
						