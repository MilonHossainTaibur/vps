<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
             <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Subject Assign</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:300px;">
                           
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/save_class_subject" enctype="multipart/form-data">
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
                                            	<label>Class</label>
                                                <select class="form-control" name="class_id" id="class_id" onchange="get_class_group_list(this.value);">
                                                	<option value="">----Select Class----</option>
                                                    <?php foreach($class_list as $cl){ ?>
                                                    <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
                                                    <?php    } ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                            	<label>Group</label>
                                                <select class="form-control" name="group_id" id="group_id" required />
                                                	<option value="">-----Select group-----</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                         <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
												<input type="button" id="button" value="Get List" class="btn btn-success" onClick="check_subject_list();">
                                                
                                            </div>
                                        </div>
                                    </div>
                                   
                                    <div id="display">
                                        
                                        
                                        <!--Subject List will be display here--->
                                        
                                        
                                    </div>
                                    
                                    
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
				

			
<?php include 'application/views/includes/footer.php';?>

<script>

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}


function check_subject_list(group_id)
{
	var class_id=$('#class_id').val();
	var group_id=$('#group_id').val();
	
	if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a class name </div>")
						$('#validation_class').fadeToggle(5000);
						return;
			
		}
		if(!group_id)
		{
			$('#group_id').after("<div id='validation_class' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a class name </div>")
						$('#validation_class').fadeToggle(5000);
						return;
			
		}
		
     $.ajax({ 
      url: baseUrl+'admin/get_subject_list_json',        
      data:
      {
            'class_id':class_id,
			'group_id':group_id
      },
      dataType: 'json',
      success: function(data)
      {
          result = ''+data['result']+'';
          mainContent = ''+data['mainContent']+'';

          if(result == 'success')
          {
             $('#display').html(mainContent);     
          }
          else if(result == 'fail')
          {
             
          }  
      }
  });
  return false; // keeps the page from not refreshing 
}
function save_class_subject_form(frm)
{
    //alert('Save task will be done very soon');
    //return false;
    frm.submit();
}
</script>