<div class="table-responsive">
	<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>admin/fees_management_edit">
			<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="60%">
				<thead>
					<tr>
						<th>Fees Cat ID</th>
						<th>Particulars</th>
						<th>Amount</th>
						<th>period</th>
						
						
					</tr>
				</thead>

			   <tbody>
					<?php
						foreach($fee_management as $fl){ ?>
						<tr>
							<td><?php echo $fl['fees_cat_id'];?></td>
							<td><?php echo $fl['fees_particulars'];?></td>
							<td>
							<input type="text" class="form-control" name="fees_amount[]" id="fees_amount" value="<?php echo $fl['amount'];?>">
							</td>
							<td>	
							
							<?php
							$period =  $fl['period'];
							if($period==1)
								$pp="One Time Fee";
							elseif($period==2)
								$pp="Monthly Fee";
							elseif($period==3)
								$pp="Yearly Fee";
							else
								$pp="Others Fee";
								
								//echo $pp;
								?>
								<select class="form-control" name="period[]" id="period">
									<?php
                                    //foreach($period as $periods){ ?>
									<option value="1"
									<?php
										if($period == 1){
											echo "selected";
										}
									 echo "One Time Fee";?></option>
									<option value="2"
									<?php
										if($period == 2){
											echo "selected";
										}
									 echo "Monthly Fee"; ?> 
									 </option>
									<option value="3"
									<?php
										if($period == 3){
											echo "selected";
										}
									 echo "Yearly Fee";?> </option>
									<option value="4"
									<?php
										if($period == 4){
											echo "selected";
										}
									 echo "Others Fee";?></option>
								<?php //} ?>
								</select>
								
							</td>
							</tr>
						   <tr> 
						   
						    <input type="hidden" class="form-control" name="fees_cat_id[]" id="fees_cat_id" value="<?php echo $fl['fees_cat_id'];?>">
						   
						    <input type="hidden" class="form-control" name="fee_mngt_id[]" id="fee_mngt_id" value="<?php echo $fl['fee_mngt_id'];?>">
						   
						    <input type="hidden" class="form-control" name="class_id[]" id="class_id" value="<?php echo $fl['class_id'];?>">
						   
						    <input type="hidden" class="form-control" name="school_id" id="school_id" value="<?php echo $fl['school_id'];?>">
						   
						</tr>
					<?php 	} ?>
					 
				</tbody>
			</table>
	
			<br/>
			<button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Update</button>
	</form>
</div>