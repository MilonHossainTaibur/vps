<?php include 'application/views/home/inc/header.php';?>

  <!-- Primary Starts -->
            <section id="primary" class="content-full-width grey1">
              
                <div class="dt-sc-margin20"></div>
                <h2 class="aligncenter">ভর্তি তথ্য</h2>
                <div class="container">
                   <table >
                                            </table>    

                              
                </div>      
      </section>

<?php include 'application/views/home/inc/footer.php';?>