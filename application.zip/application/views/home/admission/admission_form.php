<?php include 'application/views/home/inc/header.php';?>

      <section id="primary" class="content-full-width grey1">     

          <div class="full-width-section">
            <div class="dt-sc-margin30"></div>
                
                <div class="container">
                    <div class="woocommerce">
                        <h3>অনলাইন ভর্তি আবেদন</h3>
                            <!-- **col2-set - Starts** -->    
                            <div class="col2-set" id="customer_details">
                                <!-- **col-1 - Starts** -->  
                              <form name="checkout" method="post"  enctype="multipart/form-data" class="checkout" action="">  

                                <div class="col-1">                         
                                                                        
                                        <p class="form-row form-row-wide validate-required" id="billing_first_name_field">
                                        <label for="billing_first_name" class="">Applicant Name &nbsp; </label>
                                        <input type="text" class="input-text" name="data[studentName]" placeholder="Applicant Name*"  value="" required /></p>
                                
                                    
                                        <p class="form-row form-row-first validate-required"  id="billing_company_field">
                                        <label for="billing_company" class="">Father Name &nbsp;  </label>
                                        <input type="text" class="input-text " name="data[fatherName]" placeholder="Father Name"  value="" required="" /></p>
                                        
                                        <p class="form-row form-row-last validate-required" id="billing_address_2_field">
                                        <label for="billing_address_2" class="">Mother Name &nbsp; </label>
                                        <input type="text" class="input-text " name="data[motherName]" placeholder="Mother Name"  value=""  /></p>

                                        <p class="form-row form-row-first validate-required" id="billing_address_1_field">
                                        <label for="billing_address_1" class="">Father NID &nbsp; </label>
                                        <input type="text" class="input-text " name="data[fatherNID]" placeholder="National Id"  value=""  /></p>

                                        <p class="form-row form-row-last validate-required" id="billing_address_1_field">
                                        <label for="billing_address_1" class="">Mother NID &nbsp; </label>
                                        <input type="text" class="input-text " name="data[motherNID]" placeholder="National Id"  value=""  /></p>

                                        <p class="form-row form-row-first validate-required" id="billing_address_1_field">
                                        <label for="billing_address_1" class="">Previous Class Name &nbsp; </label>
                                        <input type="text" class="input-text " name="data[preClass]" placeholder="Previous Class"  value=""  /></p>

                                        <p class="form-row form-row-last validate-required" id="billing_address_1_field">
                                        <label for="billing_address_1" class="">Previous Class Result &nbsp; </label>
                                        <input type="text" class="input-text " name="data[preClassResult]" placeholder="Previous Class Result"  value=""  /></p>
                                      
                                        <div class="form-row form-row-first address-field update_totals_on_change validate-required" id="shipping_country_field">
                                                <label for="shipping_country" class="">Class &nbsp; </label>
                                                <div class="selection-box">    
                                                    <select  class="country_to_state country_select" name="datax[classId]">
                                                                                                                               <option value="9"
                                                                            >
                                                                               ClassTen                                                                   </option>
                                                                                                                                      <option value="8"
                                                                            >
                                                                               Class Nine                                                                   </option>
                                                                                                                                      <option value="3"
                                                                            >
                                                                               Class Eight                                                                   </option>
                                                                                                                                      <option value="2"
                                                                            >
                                                                               Class Seven                                                                   </option>
                                                                                                                                      <option value="1"
                                                                            >
                                                                               Class Six                                                                   </option>
                                                                                                                       </select>
                                                </div>
                                           </div>

                                            <div class="form-row form-row-last address-field validate-required">        
                                                <label>Group &nbsp;  </label>
                                                <div class="selection-box">
                                                    <select class="country_to_state country_select" name="datax[groupId]">
                                                                                                                        <option value="4"
                                                                         >
                                                                            General                                                                </option>
                                                                                                                    </select>
                                                </div>
                                          </div>                             
                                
                                </div> <!-- **col-1 - Ends** -->  
                    <!-- **col-2 - Starts** --> 
                                <div class="col-2">
                                   
                                    
                                        
                                            <div class="form-row form-row-first address-field validate-required">        
                                                <label>Gendar  &nbsp; </label>
                                                <div class="selection-box">
                                                    <select name="data[sex]" class="country_to_state country_select" >
                                                        <option value="">-- Select --</option>
                                                                                                                        <option value="1"  >
                                                                    Male                                                                </option>
                                                                                                                                <option value="2"  >
                                                                    Female                                                                </option>
                                                                                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-row form-row-last address-field validate-required">        
                                                <label>Religion  &nbsp; </label>
                                                <div class="selection-box">
                                                    <select name="data[religion]" class="country_to_state country_select" >
                                                        <option value="">-- Select --</option>
                                                                                                                          <option value="1"  >
                                                                      Buddiest                                                                  </option>
                                                                                                                                    <option value="2"  >
                                                                      Christan                                                                  </option>
                                                                                                                                    <option value="3"  >
                                                                      Hindu                                                                  </option>
                                                                                                                                    <option value="4"  >
                                                                      Islam                                                                  </option>
                                                                                                                      </select>
                                                </div>
                                            </div>

                                            
                                        <p class="form-row form-row-first address-field" id="billing_address_2_field">
                                          <label for="billing_address_2" class="">Birth Date  &nbsp; </label>
                                          <input type="text" class="input-text " name="data[birthDate]" placeholder="Birth Date"  value=""  /></p>
                                      
                                        <p class="form-row form-row-last address-field" id="billing_address_2_field">
                                          <label for="billing_address_2" class="">Birth Registration No. &nbsp;  </label>
                                          <input type="text" class="input-text " name="data[birthRegistration]" placeholder="Birth Registration No."  value=""  /></p>
                                         <p class="form-row form-row-first validate-required" id="billing_address_1_field">
                                        <label for="billing_address_1" class="">Father Mobile &nbsp; </label>
                                        <input type="text" class="input-text " name="data[fatherPhone]" placeholder="Father Mobile"  value=""  /></p>

                                         <p class="form-row form-row-last validate-required" id="billing_address_1_field">
                                              <label for="billing_address_1" class="">Present Address &nbsp; </label>
                                              <input type="text" class="input-text " name="data[presentAddress]" placeholder="Present Address"  value=""  />
                                            </p>        
                                             <p class="form-row form-row-wide address-field" id="billing_address_2_field">
                                              <label for="billing_first_name" class="btn">Attach Image  &nbsp; </label>
                                              <input type="file" class="browse" name="photo" required />
                                           </p>
                                           <br>
                                            <div class="form-row form-row-first address-field update_totals_on_change validate-required" id="shipping_country_field">
                                                <label for="shipping_country" class="">Session &nbsp; </label>
                                                <div class="selection-box">    
                                                    <select class="country_to_state country_select" name="datax[sessionId]">
                                                                                                                                <option value="2"
                                                                             >
                                                                                2016                                                                    </option>
                                                                                                                                        <option value="1"
                                                                             >
                                                                                2015                                                                    </option>
                                                                                                                          </select>
                                                      
                                                </div>
                                           </div>

                                          
                                      
                                           <hr>
                                                                                        
                                        <p> <input type="submit" value="Apply" name="submit" /> </p></span>
                                      
                                     
                                    </div> 

                         </form>            

                        <div class="dt-sc-margin30"></div>
                                        
       </div>   
</section>         <!-- **Footer** -->
<?php include 'application/views/home/inc/footer.php';?>