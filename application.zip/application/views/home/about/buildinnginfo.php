<?php include 'application/views/home/inc/header.php';?>
 <!-- **Full-width-section - Starts** -->       
            <div class="full-width-section grey1">
                <div class="container">
                    <div class="dt-sc-margin50"></div> 
                                 <div class="hr-title dt-sc-hr-invisible-small">
                                    <h3> ভবন সংখ্যা </h3>
                                    <div class="title-sep"> </div>
                                </div>
                                <table class="table table-striped">
    <thead>
      <tr>
        <th>ভবনের নাম</th>
        <th>সংখ্যা</th>
        <th>কক্ষ সংখ্যা</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>প্রশাসনিক ভবন</td>
        <td>১টি</td>
        <td>৪টি</td>
      </tr>
       <tr>
        <td>ফ্যাসিলিটিজ বিল্ডিং</td>
        <td>১টি</td>
        <td>৮টি</td>
      </tr>
      </tr>
       <tr>
        <td>মুক্তিযোদ্ধা একাডেমিক ভবন</td>
        <td>১টি</td>
        <td>৪টি</td>
      </tr>
      <tr>
        <td>ইউনেস্কো বিাল্ডং</td>
        <td>১টি</td>
        <td>৬টি</td>
      </tr>
      <tr>
        <td>অডিটোরিয়াম ভবন</td>
        <td>১টি</td>
        <td>১টি</td>
      </tr>
      <tr>
        <td>এডভোকেট রহমত আলী অডিটোরিয়াম</td>
        <td>১টি</td>
        <td>১টি</td>
      </tr>
      <tr>
        <td>সাইন্স ল্যাব,কম্পিউটার ল্যাব</td>
        <td>১টি</td>
        <td>২টি</td>
      </tr>
      <tr>
        <td>গ্রন্থাগার</td>
        <td>১টি</td>
        <td>১টি</td>
      </tr>
    </tbody>
  </table>       
                              </div>
            </div> <!-- **Full-width-section - Ends** --> 
               
<?php include 'application/views/home/inc/footer.php';?>
    