<?php include 'application/views/home/inc/header.php';?>

<div class="container-fluid">    
    
    <div class="row section-course-title add-padding" style="background-image: url('<?php echo base_url();?>template/vps/img/contactus.jpg'); height: 200px;">
      <div class="container">
        <div class="col-md-12">
            <div class="course-head">
                <h1 style="margin-top: 80px; font-weight: 300px; font-size: 50px">Contact Us</h1>
               
            </div>
        </div>
     

       

         </div>
        </div>
</div>

             <section class="pos-rel mob-mt-30 content-footer" style="background-color: #f6f6f6; border-bottom: 1px solid #dadada; padding-bottom: 30px; margin-top:0;">
                     <div class="panel-pane pane-custom pane-1 dummy-contact"  >
                        <div class="pane-content">
                           <p>.</p>
                        </div>
                     </div>
                     <div class="container">
                        <div class="row">
             
                           
                            <div class="contact-corp col-sm-12 col-xs-12">
                              <h3 class="pane-title"><i class="fa fa-map-marker" aria-hidden="true"></i> Address : </h3>
                              <p style="color:#000000; font-size: 18px;">Darul Yusuf Apartment Bhaban,102/1, West Agargaon (7thFloor),  
                                             Dhaka 1207, Bangladesh</p>
                           </div>
                          <div class="contact-corp col-sm-12 col-xs-12 contact-links">
                              <h3 class="pane-title"><i class="fa fa-phone" aria-hidden="true"></i> Mobile : </h3>

                              <a href="tel:+01614099910" title="01614099910"><p style="color:#000000; font-size: 18px;">+88 01614 099901,+88 01614099908, +88 01614099910</p></a>
                           </div>

                           <div class="contact-corp col-sm-12 col-xs-12 contact-links">
                              <h3 class="pane-title"><i class="fa fa-fax" aria-hidden="true"></i> Phone : </h3>

                              <a href="tel:+01614099910" title="8802 9133685"><p style="color:#000000; font-size: 18px;">+8802 9133685</p></a>
                           </div>
                           <div class="contact-corp col-sm-12 col-xs-12 contact-links">
                              <h3 class="pane-title"><i class="fa fa-envelope-o" aria-hidden="true"></i> Email : </h3>
                              <a href="mailto:concrete.schwing@gmail.com" title="concrete.schwing@gmail.com"><p style="color:#000000; font-size: 18px;">info.vps@virtualbd.net, rahaman.vps@virtualbd.net, shawon.vps@virtualbd.net</p></a>
                           </div>

                  
                  
                        </div>
                     </div>
                  </section>



<div class="container-fluid" style="background-color: #29303B;">  
 <section class="py-5">
          <div class="container">
               
                 <div style="padding-top: 30px;
                 padding-bottom: 30px;">
                            
                           <div class="row">
                               <div class="col-md-12">
                    <div class="d-flex align-items-center col-lg-12 col-md-12">
                     
                             <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14604.313215276123!2d90.367231!3d23.7802258!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbe02e9ff1dce2dfd!2sVirtual%20Group!5e0!3m2!1sbn!2sbd!4v1594899709548!5m2!1sbn!2sbd" width="100%" height="400" frameborder="0" style="border:1;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
   
                      
             </div>
          </div>
     </div>
   </div>
</section>
</div>


 <!--link to skillfest-->
    <div class="container-fluid">
        <div class="container">
            <div class="row">
              
                <!--<h4 class="text-center">As We Commited</h4>-->
                <!--<div class="after-effet1"></div>-->
               <div class="col-md-6"><br>
                   <img src="<?php echo base_url();?>template/vps/img/brocheure_cover.jpg" class="img img-responsive" alt="">
               </div>
               <div class="col-md-6">
                   <a style="margin-top:70px;" target="_blank" href="<?php echo base_url();?>template/vps/img/vpsprofile.pdf" class="btn btn-danger">Download our Company Profile</a>
               </div>

            </div>
                
            </div>

        
    </div>
       
<?php include 'application/views/home/inc/footertwo.php';?>

    