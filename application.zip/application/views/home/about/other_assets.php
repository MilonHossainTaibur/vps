<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
  <div class="container">
    <div class="dt-sc-margin50"></div>
    <div class="hr-title dt-sc-hr-invisible-small">
      <h3> অন্যান্য সম্পদের বিবরন </h3>
      <div class="title-sep"> </div>
    </div>
<table class="table table-striped">
    <thead>
      <tr>
      <th>ক্রমিক নং</th>
        <th>বিবরন</th>
        <th>পরিমান/সংখ্যা</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>০১</td>
        <td>টেবিল</td>
        <td>৩৪ টি</td>
        
      </tr>
      <tr>
        <td>০১</td>
        <td>চেয়ার</td>
        <td>৪৮টি</td>
        
      </tr>
      <tr>
        <td>০২</td>
        <td>জোড়া বেঞ্চ</td>
        <td>২৫০টি</td>
        
      </tr>
      <tr>
        <td>০৩</td>
        <td>সোফাসেট</td>
        <td>০৩টি</td>
        
      </tr>
      <tr>
        <td>০৪</td>
        <td>দোকানঘর</td>
        <td>১১টি</td>
        
      </tr>
      <tr>
        <td>০৫</td>
        <td>জেনারেটর</td>
        <td>০১টি</td>
        
      </tr>
      <tr>
        <td>০৬</td>
        <td>আইপিএস</td>
        <td>০১টি</td>
        
      </tr>
      <tr>
        <td>০৭</td>
        <td>ইউপিএস</td>
        <td>০১টি</td>
        
      </tr>
      <tr>
        <td>০৮</td>
        <td>পানির ফিল্টার</td>
        <td>০১টি</td>
      </tr>
      <tr>
        <td>০৯</td>
        <td>গ্লোব</td>
        <td>০৫টি</td>
      </tr>
       <tr>
        <td>১০</td>
        <td>মানচিত্র</td>
        <td>১০টি</td>
      </tr>
       <tr>
        <td>১১</td>
        <td>জ্যামিতির সেট</td>
        <td>০৫টি</td>
      </tr>
  	 <tr>
        <td>১২</td>
        <td>বৈজ্ঞানিক যন্ত্রপাতি সেট</td>
        <td>০২টি</td>
      </tr>
      <tr>
        <td>১৩</td>
        <td>খেলার যন্ত্রপাতি সেট</td>
        <td>০৪টি</td>
      </tr>
       <tr>
        <td>১৪</td>
        <td>বৈদ্যুতিক পাখা</td>
        <td>৮২টি</td>
      </tr>
       <tr>
        <td>১৫</td>
        <td>টেলিভিশন সেট</td>
        <td>০১টি</td>
      </tr>
       <tr>
        <td>১৬</td>
        <td>টাইপ রাইটার</td>
        <td>০১টি</td>
      </tr>
       <tr>
        <td>১৭</td>
        <td>ঘড়ি</td>
        <td>৩২টি</td>
      </tr>
        <tr>
        <td>১৮</td>
        <td>বাদ্যযন্ত্রসেট</td>
        <td>০২াট</td>
      </tr>
        <tr>
        <td>১৯</td>
        <td>পানির পাম্প</td>
        <td>০৩টি</td>
      </tr>
    </tbody>
  </table>
  </div>
</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>