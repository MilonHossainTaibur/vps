<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
  <div class="container">
    <div class="dt-sc-margin50"></div>
    <div class="hr-title dt-sc-hr-invisible-small">
      <h3>কম্পিউটার ল্যাবের তথ্য </h3>
      <div class="title-sep"> </div>
    </div>
<table class="table table-striped">
    <thead>
      <tr>
      <th>ক্রমিক নং</th>
        <th>বিবরন</th>
        <th>পরিমান/সংখ্যা</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>০১</td>
        <td>ডেক্সটপ কম্পিউটার</td>
        <td>৬টি</td>
      </tr>
      <tr>
        <td>০২</td>
        <td>ল্যাপটপ কম্পিউটার</td>
        <td>৯টি</td>
      </tr>
       <tr>
        <td>০৩</td>
        <td>প্রজেক্টর</td>
        <td>২টি</td>
      </tr>
       <tr>
        <td>০৪</td>
        <td>স্পিকার</td>
        <td>৮টি</td>
      </tr>
    </tbody>
  </table>
  </div>
</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>