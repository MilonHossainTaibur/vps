<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="container-fluid">    
    
    <div class="row section-course-title add-padding" style="background-color: #29303B; color: #fff; padding-top: 20px;">
      <div class="container">
        <div class="col-md-12">
            <div class="course-head">
                <h1>About Virtual Pharma Solution</h1>
               
            </div>
        </div>
     

       

         </div>
        </div>

        <section class="py-5">
          <div class="container">
               
                 <div style="margin-bottom: 30px; padding-top: 30px;
                 padding-bottom: 30px;">
                            
                           <div class="row">
                               <div class="col-md-12">
                    <div class="d-flex align-items-center col-lg-12 col-md-12">
                     
                               <p class="text-lg text-gray-700 mb-4"> Virtual Pharma Solution is the laboratory scientific equipment and pharmaceutical instrument manufacturer and service and Support provider company in Bangladesh. The name Virtual brings feeling of spirituality in intangible. It was founded with a vision to provide various specialized pharmaceutical, hospital and textile manufacturing equipment from world renowned manufacturers whose equipment has a balance between equipment output and cost effectiveness. We also provide high end Services; logistics supports to Pharmaceuticals companies in Bangladesh under a team consist of renowned Scientists, Pharmacists, and Engineers to solve this prevailing crisis of the health sector. Virtual Pharma Solution also contribute to the country's health sectors with the equipment "Made in Bangladesh ". <br>
                                In recent we have assigned Applied Science & Technology Instruments (ASTi) and SS Engineering as our sister concern of Laboratory equipment Manufacturer where Virtual Pharma Solution is the Marketing partner under VMTC. The health sector of Bangladesh should provide quality service to safe patients. To confirm quality service, the best quality Laboratory scientific equipment and instrument are the only solutions.<br>
                                 Our equipment meets European standards but saves clients and users money. <br>
Our motto is to contribute the nation by introducing modern and new technologies in the Construction, Pharma, Medical & Laboratory industry of Bangladesh and to develop skill and unskilled manpower of this country. Moreover, we are trying to Developed a Corporate Company which will serve this Nation and Globe Generation by Generation.</p>
   
                      
             </div>
          </div>
     </div>
   </div>
</section>
</div>

<!-- Contributor section -->
<div class="container-fluid bg-section-gray" id="section-trainer">

    <div class="container">
        <div class="contributor text-center">
            <div class="effect_title">
                <div class="section_title" style="text-align:center">
                    <span class="title_two wow fadeInUp"><h3 style="color:#990158;">Management & Marketing Team</h3></span>
                    <div class="after-effet1"></div>
                </div>
            </div>



            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/21.png' class='contact' />
                    <span class='name'>Md. Khairul Islam</span>
                    <hr>
                    <span class='job'>CEO & Chairman Virtual Group</span>
                </div>
                <div class='back'>
                    <span>B.Sc. Engr Civil (KUET) & MBA (BU)</span>
                    <p>Mobile : 01614 099901</p>
          <p>Email: khairul@virtualbd.net</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                   
                </div>
            </div>

            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/22.png' class='contact' />
                    <span class='name'>Md. Mashiar Rahman</span>
                    <hr>
                    <span class='job'>Founder of ASTi & Scientist at VPS Applied Physics & Electronics</span>
                </div>
                <div class='back'>
                    <span>University of Rajshahi</span>
                    <p>Cell: 01631 845492; 01928 979953</p>
          <p>Email: applied.sti@gmail.com</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                    
                </div>
            </div>

            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/23.png' class='contact' alt="siju" />
                    <span class='name'>Engr. Hasan Shahriar Shawon</span>
                    <hr>
                    <span class='job'>Senior Executive Virtual Pharma Solution & Concrete Technology</span>
                </div>
                <div class='back'>
                    <span>B.Sc. In EEE</span>
                    <p>Cell: 01614 099910</p>
          <p>Email: shawon.vps@virtualbd.net,<br>shawon.vps@gmail.com</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                   
                </div>
            </div>

            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/24.png' class='contact' alt="m shahidul" />
                    <span class='name'>Engr. Abdur Rahaman</span>
                    <hr>
                    <span class='job'>Senior Executive Virtual Pharma Solution & Concrete Technology</span>
                </div>
                <div class='back'>
                    <span>B.Sc. In EEE</span>
                    <p>Email: rahaman.vps@virtualbd.net,<br>arahaman.vps@gmail.com</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                   
                </div>
            </div>



        </div>
    </div>



</div>
            


<!--END Contributor section -->
 <!--link to skillfest-->
    <div class="container-fluid">
        <div class="container">
            <div class="row">
              
                <!--<h4 class="text-center">As We Commited</h4>-->
                <!--<div class="after-effet1"></div>-->
               <div class="col-md-6"><br>
                   <img src="<?php echo base_url();?>template/vps/img/brocheure_cover.jpg" class="img img-responsive" alt="">
               </div>
               <div class="col-md-6">
                   <a style="margin-top:70px;" target="_blank" href="<?php echo base_url();?>template/vps/img/vpsprofile.pdf" class="btn btn-danger">Download our Company Profile</a>
               </div>

            </div>
                
            </div>

        
    </div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>

