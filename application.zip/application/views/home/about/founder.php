<?php include 'application/views/home/inc/header.php';?>
 <!-- **Full-width-section - Starts** -->       
            <div class="full-width-section grey1">
                <div class="container">
                <div class="dt-sc-margin50"></div> 
                <div class="row"><div class="col-md-12">
                    <div class="panel">
                    <div class="panel-heading " style="text-align:center"><h1 class="">প্রতিষ্ঠাতা ও জমি দাতা</h1>
                    <hr></div>      
                    <div class="panel-body">
                    <div class="" style="">
                            <img class="img-thumbnail center-block" src="<?= base_url() ?>template/assets/images/founder.jpg">
                            <br>
                            <div class="clearfix"></div>
                        </div>
                        
                   <div class="per_tec" style="text-align:center; margin-bottom:30px">
							<h3>মরহুম পিয়ার আলী মাদবর</h3>
							<h4>পিতাঃ মরহুম শহর আলী মাদবর</h4>
							<h4>মাতাঃ মরহুমা সাহাজান বিবি</h4>
							<h4>জন্মঃ ১৮৬৩ খ্রিস্টাব্দ</h4>
							<h4>মৃতঃ ২৬ আগষ্ট ১৯৭০খ্রিস্টাব্দ</h4>
						</div>
                   
                        

<table class="table table-condensed  ">

    <thead>
        <tr>
            <th>মরহুম পিয়ার আলী মাদবর কর্তৃক প্রতিষ্ঠিত শিক্ষা ও ধর্মীয় প্রতিষ্ঠানসমূহঃ</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>মাওনা বহমুখী উচ্চ বিদ্যালয়</td>
        </tr>
        <tr>
            <td>মাওনা জে.এম. সরকারী প্রাথমিক বিদ্যালয়</td>
        </tr>
        <tr>
            <td>মাওনা বাজার কেন্দ্রীয় জামে মসজিদ</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী সরাই খানা</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী ঈদগাহ ময়দান</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী সরাই খানা</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী বিশ্ব বিদ্যালয় কলেজ (তাঁর উত্তরসূরীগন কর্তৃক প্রতিষ্ঠিত)।</td>
        </tr>
    </tbody>
</table>




                    </div>
                </div>  
                </div>

               </div>
                               
                                             </div>
            </div> <!-- **Full-width-section - Ends** --> 
               


<?php include 'application/views/home/inc/footer.php';?>
    