<style type="text/css">
  /* set base drop cap styles */

 
/* mobile first media query */
@media only screen and (min-width: 800px) {
   
    /* set paragraph styles for larger screens */

   
    /* set drop cap styles for larger screens */
    p::first-letter {
        initial-letter: 3.0 2;
        font-size: 35px;
        margin: 1em .1em 0 0;
    }
   
}

</style>

<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
<div class="dt-sc-margin20"></div>
<div class="container" style="background:#FFF;">
   <div class="hr-title dt-sc-hr-invisible-small">
      <h3><//?= $messages['name'];?></h3>
      <div class="title-sep"> </div>
   </div>
   <!--<div class="entry-meta-data">
      <p><span class="fa fa-calendar"> </span>  &nbsp; প্রকাশের তারিখ:<//?= $messages['created_on'];?>&nbsp;|&nbsp;&nbsp;<span class="fa fa-comment"> </span>  <//?= $messages['name'];?>  </p>
      <p></p>
   </div>-->
   <!-- **column - Starts** -->
   <div class="column dt-sc-four-fifth first justify" style="margin-left: 81px;">
    <div class="dt-sc-margin30"></div>
      <div class="column dt-sc-full" style="margin-right: 40px;">
         <img class="img-thumbnail" src="<?= base_url();?>upload/message_image/<?= $messages['image'];?>">
      </div>
      
      <?= $messages['message'];?>
      <!-- **column - Ends** -->
      
      <b><span></span></b> 
      <p>
         &nbsp;
      </p>
      <div style="float:right;padding-right:0px">
         <h3>মোঃ আশরাফুল ইসলাম</h3>
         
         <h3>সভাপতি গর্ভনিংবডি</h3>
         <h4>ফুটকিবাড়ী ডিগ্রী কলেজ</h4>
      </div>
      <!-- **column - Starts** -->
   </div>
   <!-- **container - Ends** -->
   <div class="dt-sc-margin20"></div>
</div>
<!-- **Full-width-section - Ends** -->
<?php include 'application/views/home/inc/footer.php';?>

