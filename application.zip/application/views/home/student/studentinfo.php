<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
   <div class="full-width-section">
      <div class="dt-sc-margin30"></div>
      <div class="container">
         <!-- **col-1 - Starts** -->  
         <div class="hr-title dt-sc-hr-invisible-small">
            <h3>সকল শিক্ষার্থীদের তথ্য</h3>
            <div class="title-sep"> </div>
         </div>
        <div>
            <div id="order_review">
               <table  class="table table-condensed" >
                  <thead>
                     <tr>
                        <th>#SL</th>
                        <th class="">Class</th>
                        <th class="">Section</th>
                        <th class="">Session</th>
                        <th class="">Shift</th>
                        <th class="">Nomber Of Students</th>
                     </tr>
                  </thead>
                  <tbody>
				   <tr>
						<?php $i=1; foreach($student_count as $sc) { ?>
                        <td><?= $i ?></td>
                        <td><?= $sc['class_name'] ?></td>
                        <td><?= $sc['section_name'] ?></td>
                        <td><?= $sc['session_name'] ?></td>
                        <td><?= $sc['shift_name'] ?></td>
                        <td><?= $sc['ts'] ?></td>
                     </tr>
				   <?php $i++; } ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <div class="dt-sc-margin30"></div>
   </div>
</section>
<!-- **Footer** -->
<?php include 'application/views/home/inc/footer.php';?>

