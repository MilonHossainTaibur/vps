<?php include 'application/views/home/inc/header.php';?> 
<!-- **Full-width-section - Starts** -->

<div class="container-fluid">    
    
    <div class="row section-course-title add-padding" style="background-color: #29303B; color: #fff; padding-top: 20px;">
      <div class="container">
        <div class="col-md-12">
            <div class="course-head">
                <h1>Message</h1>
               
            </div>
        </div>
     

       

         </div>
        </div>
     
                <div class="container">

             
                <div class="row">

                     <div class="portfolio_slider_wrap col-md-3 content-softskill" style="padding-top: 30px">

                         <div class="single-new-products">
                            <img src="<?php echo base_url();?>template/vps/img/md.jpg" width="300px" height="300px" alt="course"/>
                            <h5 class="text-lg text-uppercase text-primary"><b style="color:#990158">— Md. Khairul Islam</b></h5>
                            <span>— CEO & Chairman Virtual Group</span></br>
                            <span>— B.Sc. Engr Civil (KUET) & MBA (BU)</span></br>
                            <span>— Mobile : 01614 099901</span></br>
                            <span>— Email: khairul@virtualbd.net</span></br>
                                                 
                         </div>

                    </div>
                   
                    <div class="portfolio_slider_wrap col-md-9 content-softskill" style="padding-top: 30px">

                           <p class="text-lg text-gray-700 mb-4">
                             To introduce modern Technology in the Construction Industry of Bangladesh we started our journey in the Name of Concrete Technology in the year 2003. It was our utmost try to provide honest service for Construction works and to the customer. With the spirit of modern construction works the company got the opportunity to work with so many Global construction companies namely Lersen and Toubro, SHIMUJI and OBAYSHI Corporation.<br> On the way of journey, we started work as an authorized dealer of Global Brand Schwing Stetter for marketing their Concrete Equipment in Bangladesh territory in the year 2009. In 2012 we got another Global Brand Soilmec dealership for marketing their products in Bangladesh. We formed VIRTUAL Construction Ltd. in 2010 to serve construction industry of the country. Concrete is a imperative material for construction, primarily we started Concrete manufacturing business in Dhaka city in the Brand namely VIRTUAL RMC to serve the customer in Dhaka and around Dhaka. To cover Eastern Zone of Dhaka city we formed a company namely Mollik Virtual RMC in the year 2011. We have extended our RMC Business to Chittagong city to serve the users by supplying quality concrete. In recent we have assigned Applied Science & Technology Instruments (ASTi) as our sister concern of Laboratory equipment Manufacturer where Virtual Pharma Solution is the Marketing partner under VMTC. The health sector of Bangladesh should provide quality service to safe patients. To confirm quality service, the best quality Laboratory scientific equipment and instrument are the only solutions.<br> During this COVID-19 pandemic health scientists, pharmacists, Pathological lab owners are feeling the acute necessity of quality lab equipment. <br>
                            We launched our new venture namely " Virtual Pharma solution " under a team consist of renowned Scientists, Pharmacists, and Engineers to solve this prevailing crisis of the health sector.<br>
                            Virtual Pharma Solution will contribute to the country's health sectors with the equipment "Made in Bangladesh ".
                            Our equipment meets European standards but saves clients and users money.<br>
                            Our motto is to contribute the nation by introducing modern and new technologies in the Construction, Pharma, Medical & Laboratory industry of Bangladesh and to develop skill and unskilled manpower of this country. Moreover, we are trying to Developed a Corporate Company which will serve this Nation and Globe Generation by Generation.

                             </p>

                    </div>

                   

                </div>
          </div>


      
     </div>

     <div class="container" style="padding-top: 70px;">
          </div>
 



<!-- **Full-width-section - Ends** -->
<?php include 'application/views/home/inc/footer.php';?>


    