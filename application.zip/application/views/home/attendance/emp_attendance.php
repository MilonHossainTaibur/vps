

<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
   <div class="container-fluid">
      <div class="container text-center" style="background:#FFF;">
         <div class="dt-sc-margin20"></div>
         <div class="dt-sc-margin30"></div>
         <!-- **col-1 - Starts** -->  
         <div class="hr-title dt-sc-hr-invisible-small">
            <h3>শিক্ষকদের উপস্থিতির তথ্য</h3>
            <div class="title-sep"> </div>
         </div>
         <div class="widget-content padding">
            <div class="daily">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-4 col-md-4">
                        <form class="dt-sc-search-form" method="post" action="">
                           <input class="date-picker" id="datepicker" type="text" name="input_date" placeholder="YY-MM-DD" />
                           <div class="dt-sc-margin10"></div>
                           <button style="color:#FFF;" class="button btn btn-info" value="Check available time" type="button"  onclick="teacher_att_report_json('d')">Search Teacher Attendance </button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <hr/>
         <div class="widget-content padding">
            <div id="display">
               <!---JSON Content will be displayed here--->
            </div>
         </div>
         <div class="dt-sc-margin30"></div>
      </div>
      <div class="dt-sc-margin50"></div>
   </div>
</section>
<!-- **Footer** -->
<?php include 'application/views/home/inc/footer.php';?>
<script>
   // get the student monthly report
   	function teacher_att_report_json(report_type)
   	{
   		var input_date = $('[name=input_date]').val();
   		var month_id = $('#month_id').val();
   		var teacher_id = $('#teacher_id').val();
   		var teacher_name = $( "#teacher_id option:selected" ).text();
   		var month_name = $( "#month_id option:selected" ).text();
   		//var teacher_name_json=<?= json_encode($teacher_list); ?>;
   		//alert(teacher_name_json);	
           $.ajax({ 
           url: baseUrl+'home/teacher_att_report_json',
           data:
               {                  
                   'att_date':input_date,
                   'month_id':month_id,
                   'teacher_id':teacher_id,
                   'teacher_name':teacher_name,
                   'month_name':month_name,
                   //'teacher_name_json':teacher_name_json,
   		'report_type':report_type
               }, 
               dataType: 'json',
               success: function(data)
               {
                   result                = ''+data['result']+'';
                   mainContent           = ''+data['mainContent']+'';
   
                   if(result == 'success')
                   {  //alert(mainContent);          
                       $('#display').html(mainContent);     
                   }                
               }
           });
           return false; // keeps the page from not refreshing     
       }
   	
   	//print all report
   	function printPageArea(areaID){
   		var printContent = document.getElementById(areaID);
   		var WinPrint = window.open('', '', 'width=900,height=650');
   		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />');
   		WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} .header-div-box{display:inline-block;} .header-div-box.box-left{float:left; margin-bottom:10px;} .header-div-box.box-right{float:right;}</style>');
   		WinPrint.document.write(printContent.innerHTML);
   		WinPrint.document.close();
   		WinPrint.focus();
   		WinPrint.print();
   		WinPrint.close();
   	}
</script>

