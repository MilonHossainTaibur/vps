<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
<div class="dt-sc-margin65"></div>
<div id="main">
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="dt-sc-margin20"></div>
   <div class="container">
      <div class="dt-sc-margin20"></div>
      
      <div class="hr-title">
                            <h3><i class="fa fa-list" aria-hidden="true"></i>
১৯৭১ সালে মাওনা বহুমূখী উচ্চ বিদ্যালয়ে অধ্যয়নরত মহান মুক্তিযুদ্ধে অংশগ্রহনকারী শিক্ষার্থীদের তালিকা</h3>
                            <div class="title-sep">
                            </div>
                        </div>
      <p style="font-size:28px; color:#000000;" class="aligncenter"></p>
    
      <div class="table-responsive">
         <table class="table table-bordered table-striped" width="100%">
            <thead>
               <tr>
                  <th colspan="2">এস.এস.সি পরীক্ষার্থী</th>
                  <th colspan="2">দশম শ্রেনী</th>
                  <th colspan="2">নবম শ্রেনী</th>
                  <th colspan="2">অষ্টম শ্রেনী</th>
               </tr>
               <tr>
                  <th>নাম</th>
                  <th>ঠিকানা</th>
                  <th>নাম</th>
                  <th>ঠিকানা</th>
                  <th>নাম</th>
                  <th>ঠিকানা</th>
                  <th>নাম</th>
                  <th>ঠিকানা</th>
               </tr>
            </thead>
            <tbody>
               <tr>
                  <td>মোঃ সিরাজুল হক</td>
                  <td>মাওনা</td>
                  <td>মোঃ নুরুল ইসলাম</td>
                  <td>কেওয়া পশ্চিম খন্ড</td>
                  <td>আ.জ.ম এনামূল হক</td>
                  <td>কেওয়া পশ্চিম খন্ড</td>
                  <td>মোঃ জালাল উদ্দিন</td>
                  <td>চকপাড়া</td>
               </tr>
               <tr>
                  <td>মোঃ তাজ উদ্দিন আহমেদ</td>
                  <td>কেওয়া পশ্চিম খন্ড</td>
                  <td>মোঃ আব্দুল হামিদ</td>
                  <td>টেপির বাড়ী</td>
                  <td>শেখ আতাহার আলী</td>
                  <td>কেওয়া পশ্চিম খন্ড</td>
                  <td>মোঃ আব্দুর রশিদ আজাদ</td>
                  <td>মাওনা</td>
               </tr>
               <tr>
                  <td>মোঃ আব্দুল কাদির</td>
                  <td>গোদার চালা</td>
                  <td>মোঃ মুক্তাদির হোসেন</td>
                  <td>মাওনা</td>
                  <td>মোঃ হেলাল উদ্দিন</td>
                  <td>জমিরা পাড়া</td>
                  <td>মোঃ সাহাব উদ্দিন</td>
                  <td>মুলাইদ</td>
               </tr>
               <tr>
                  <td>মোঃ হজরত আলী</td>
                  <td>মাওনা</td>
                  <td>মোঃ আলফাজ উদ্দিন</td>
                  <td>মাওনা</td>
                  <td>এবি সিদ্দিক</td>
                  <td>টেপির পাড়া</td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>মোঃ নজরুল ইসলাম আকন্দ</td>
                  <td>কেওয়া</td>
                  <td>মোঃ নুরুল হক</td>
                  <td>বেড়াইদের চালা</td>
                  <td>মোঃ মোস্তফা মৃধা</td>
                  <td>টেপির পাড়া</td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>মোঃ সামসুদ্দিন</td>
                  <td>মাওনা</td>
                  <td>তাজ উদ্দিন আহমেদ</td>
                  <td>গোসিংগা</td>
                  <td>মোঃ আহাদ আলী মৃধা</td>
                  <td>টেপির পাড়া</td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>মোঃ আবুল কাশেম</td>
                  <td>টেপির বাড়ী</td>
                  <td>মোঃ শফি উদ্দিন</td>
                  <td>বহেরার চালা</td>
                  <td>মোঃ আব্দুল মজিদ</td>
                  <td>যোগীর ছিট</td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>মোঃ মোসলেহ উদ্দিন</td>
                  <td>আবদার</td>
                  <td>মোঃ আফাজ উদ্দিন আকন্দ</td>
                  <td>বিদাই আবদার</td>
                  <td>মোঃ আব্দুর রশিদ ফকির</td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>মোঃ মফিজ উদ্দিন মৃধা</td>
                  <td>টেপির বাড়ী</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>মোঃ সামসুজ্জামান সুরুজ</td>
                  <td>টেপির বাড়ী</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>শহীদ মাজম আলী</td>
                  <td>ধনুয়া</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>মোঃ আঃ সাত্তার খান</td>
                  <td>কালিগঞ্জ</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
            </tbody>
         </table>
         <br>
      </div>
   </div>
   </div--> <!-- **Full-width-section - Ends** -->
</div>
<?php include 'application/views/home/inc/footer.php';?>

