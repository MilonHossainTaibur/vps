<div class="no-data container">
<a href="<?= base_url() ?>">
	<img class="img-responsive center-block" src="<?= base_url() ?>template/assets/images/images.jpg" alt=""></a>
</div>