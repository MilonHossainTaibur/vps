<footer id="colophon" class="site-footer " role="contentinfo">
              <div class="container-fluid">
                <div class="container text-md-left">
                <div class="row text-md-left mt-3 pb-3">
                      
                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 widget">
                           <div class="footer_area_three">
                              <section id="enlighten_info-3" class="widget widget_enlighten_info">
                                 <div class="footer_info_wrap">
                                    <div class="text-bold footer_widget_title text-uppercase font-weight-bold">
                                       <h3>Contact us</h3>
                                    </div>
                                    <hr>
                                    <div class="info_wrap">
                                       <ul class="contact-info">
                                          <li>
                                             <span class="fa_icon_info">
                                             <i class="fa fa-map-marker" aria-hidden="true"></i>
                                             </span>
                                             <span class="location">Darul Yusuf Apartment Bhaban,102/1, West Agargaon (7thFloor),  
                                             Dhaka 1207, Bangladesh</span>
                                          </li>
                                          <li>
                                             <span class="fa_icon_info">
                                             <i class="fa fa-phone" aria-hidden="true"></i>
                                             </span>
                                             <span class="phone">+88 01614 099901,+88 01614099908, +88 01614099910</span>
                                          </li>
                                          <li>
                                             <span class="fa_icon_info">
                                             <i class="fa fa-fax" aria-hidden="true"></i>
                                             </span>
                                             <span class="fax">+8802 9133685</span>
                                          </li>
                                          <li>
                                             <span class="fa_icon_info">
                                             <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                             </span>
                                             <span class="email">info.vps@virtualbd.net, rahaman.vps@virtualbd.net, shawon.vps@virtualbd.net</span>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                              </section>
                           </div>
                        </div>
                        
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 widget">

                        <div class="footer_area_two">
                            <section id="enlighten_recent_news-6" class="widget widget_enlighten_recent_news">
                                <div class="footer_RN_wrap">
                                    
                                       
                                       
                                    
                                    <div class="">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14604.313215276123!2d90.367231!3d23.7802258!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbe02e9ff1dce2dfd!2sVirtual%20Group!5e0!3m2!1sbn!2sbd!4v1594899709548!5m2!1sbn!2sbd" width="500" height="263" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                                               
                                            
                                    </div>
                                </div>
        
                            </section>                
                        </div>
                        </div>
                    
                     </div>
                    <div class="site-info text-center text-uppercase font-weight-bold">
                    Copyright &copy; Virtual Pharma Solution
                    </div><!-- .site-info -->
                  </div> 
                </div>
          </footer>

<!--Start of Zendesk Chat Script-->

    
        
    
        
            


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- End Footer -->

<!-- Scripts -->

<script src="<?= base_url();?>template/vps/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?= base_url();?>template/vps/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- jQuery.countdown -->

<script src="../cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<script src="<?= base_url();?>template/vps/js/jquery.counterup.min.js"></script>




<!-- Contact Form JavaScript -->
<script src="<?= base_url();?>template/vps/js/jqBootstrapValidation.js"></script>


<!-- Theme JavaScript -->
<script src="<?= base_url();?>template/vps/js/clean-blog.js"></script>

<!--smooth-scroll-->
<script src="<?= base_url();?>template/vps/vendor/smooth-scroll/smooth-scroll.js"></script>

<!-- owl slider js -->
<script src="<?= base_url();?>template/vps/vendor/OwlCarousel/owl.carousel.min.js"></script>
<script>


$(document).ready(function() {

$(".owl-carousel").owlCarousel({

autoPlay: 3000,
items : 4,
itemsDesktop : [1199,3],
itemsDesktopSmall : [979,3],
center: true,
nav:true,
loop:true,
responsive: {
600: {
items: 5
}
}

});

});



</script>


</body>

</html>
