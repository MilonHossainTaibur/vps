<div style="background-color: #0085A1; min-height: 140px; font-family: 'Open Sans', sans-serif" id="colophon" class="site-footer " role="contentinfo">
              <div class="container-fluid">
          
                    <div class="site-info text-center text-uppercase font-weight-bold">
                    Copyright &copy; Virtual Pharma Solution
                    </div><!-- .site-info -->
                  </div> 
              
          </div>

<!--Start of Zendesk Chat Script-->

    
        
    
        
            


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- End Footer -->

<!-- Scripts -->

<script src="<?= base_url();?>template/vps/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?= base_url();?>template/vps/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- jQuery.countdown -->

<script src="../cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<script src="<?= base_url();?>template/vps/js/jquery.counterup.min.js"></script>




<!-- Contact Form JavaScript -->
<script src="<?= base_url();?>template/vps/js/jqBootstrapValidation.js"></script>


<!-- Theme JavaScript -->
<script src="<?= base_url();?>template/vps/js/clean-blog.js"></script>

<!--smooth-scroll-->
<script src="<?= base_url();?>template/vps/vendor/smooth-scroll/smooth-scroll.js"></script>

<!-- owl slider js -->
<script src="<?= base_url();?>template/vps/vendor/OwlCarousel/owl.carousel.min.js"></script>
<script>


$(document).ready(function() {

$(".owl-carousel").owlCarousel({

autoPlay: 3000,
items : 4,
itemsDesktop : [1199,3],
itemsDesktopSmall : [979,3],
center: true,
nav:true,
loop:true,
responsive: {
600: {
items: 5
}
}

});

});



</script>


</body>

</html>
