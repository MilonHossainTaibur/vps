<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content="We Are Provide Profissional Development Course To Growth Your Soft & Fulctional Skills">
<meta name="keywords" content="pdc, Profissional, Course, Development, soft, skill, sotfskill, function, fulctional,functionalskill, sharpen, skilldevelopment, traning, corpurate">
<meta name="author" content="BSDI">

<title>Virtual-Group||Pharma-Solution</title>

<!--Favicon-->
<link rel="shortcut icon" href="<?php echo base_url();?>upload/institute_logo/<?= $school_info['logo'];?>" />

<!-- Bootstrap Core CSS -->
<link href="<?= base_url();?>template/vps/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Theme CSS -->
<link href="<?= base_url();?>template/vps/css/clean-blog.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?= base_url();?>template/vps/css/custom.css" rel="stylesheet">


<!-- owl slider -->
<link href="<?= base_url();?>template/vps/vendor/OwlCarousel/owl.carousel.min.css" rel="stylesheet">
<link href="<?= base_url();?>template/vps/vendor/OwlCarousel/owl.theme.default.min.css" rel="stylesheet">



<!-- jquery plugin -->
<script src="<?= base_url();?>template/vps/vendor/jquery/jquery.min.js"></script>

<!-- jQuery.countdown -->
<script src="<?= base_url();?>template/vps/vendor/jquery.countdown-2.0.4/jquery.countdown.min.js"></script>

<!-- Custom Fonts -->
<link href="<?= base_url();?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- SCripts -->
<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/vps/vendor/flip-countdown/jquery.flipcountdown.css"/>

<script src="<?= base_url();?>template/vps/vendor/flip-countdown/jquery.flipcountdown.js"></script>

<!-- content -->    
 <link rel="stylesheet" href="<?= base_url();?>template/vps/vendor/animatecss/animate.css">
 <link rel="stylesheet" href="<?= base_url();?>template/vps/css/style.css">

    <!-- autocomplete test -->
 <link rel="stylesheet" href="../code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
 <script src="../code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <!-- autocomplete test -->

 <link rel="stylesheet" href="<?= base_url();?>template/vps/css/course-master.css">
    
     <!--Preloader-->
 <link rel="stylesheet" href="<?= base_url();?>template/vps/css/preloader.css">
    <!--Preloader-->
<style>
    @font-face {
        font-family:bebasneue;
        src:https://pdc.bsdi-bd.org/front-end/fonts/roboto.light.ttf;
    }
</style>


<!--Preloader-->

<script>
    jQuery(document).ready(function($) {
        $(".preload-tags" ).autocomplete({
            source:"https://pdc.bsdi-bd.org/gt"
        });

    });
</script>
<!-- End Navigation -->
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.pCounter').counterUp({
            delay: 20,
            time: 2000
        });

    });

</script>



    <!--Image Hover-->



    <script>
        jQuery(document).ready(function($) {
            $(".preload-tags" ).autocomplete({
                source:"https://virtualbd.net/vps/"
            });

            $('.pCounter').counterUp({
                delay: 40,
                time: 4000
            });

        });
        
        // preload tags
        $(window).on('load', function() { // makes sure the whole site is loaded 
                $('#status').fadeOut(); // will first fade out the loading animation 
                $('#preloader').delay(450).fadeOut('slow'); // will fade out the white DIV that covers the website. 
                $('body').delay(450).css({'overflow':'visible'});
            })
        
    </script>

<!--Preloader-->

<!--font-face-->

<!-- Global site tag (gtag.js) - Google Analytics -->









</head>

<body>
    

<header>

<!-- Navigation -->

    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header page-scroll">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                Menu <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="<?php echo base_url();?>">
                <img class="img img-responsive nav-logo" src="<?php echo base_url();?>upload/institute_logo/<?= $school_info['logo'];?>" alt=""/>
            </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
         
                <li>
                    <a href="<?php echo base_url();?>">Home</a>
                </li>
               
                <li><a data-easing="linear" href="<?php echo base_url();?>home/about">About</a></li>
                <li><a data-easing="linear" href="<?= base_url()?>home/all_produacts">Product</a></li>
                <li><a data-easing="linear" href="<?php echo base_url();?>home/contact_us">Contact</a></li>
                <li>
                    <div class="navBtn"><button type="button" class="btn btn-danger">Dial  +88 01614099910</button>
                    </div>
                </li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>


    <!-- Preloader -->

    <!-- Page Header -->
<!-- Set your background image for this header on the line below. -->
