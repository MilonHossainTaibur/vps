<?php include 'application/views/home/inc/header.php';?>
  
      <!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="dt-sc-margin20"></div>
   <div class="dt-sc-margin20"></div>
   <div class="container">
      <div class="hr-title dt-sc-hr-invisible-small curl">
         <h3><i class="fa fa-camera" aria-hidden="true"></i>
 College Rejulation</h3>
         <div class="title-sep">
         <table class="MsoTableGrid" style="border-collapse: collapse; border: none; mso-border-alt: solid windowtext .5pt; mso-yfti-tbllook: 1184; mso-padding-alt: 0in 5.4pt 0in 5.4pt;" border="1" cellspacing="0" cellpadding="0">
<tbody>


 <?php foreach($rejulation_viewimage as $tl){ ?>
 <tr>
<td style="width: 202.5pt; border: solid windowtext 1.0pt; border-left: none; mso-border-left-alt: solid windowtext .5pt; mso-border-alt: solid windowtext .5pt; padding: 0in 5.4pt 0in 5.4pt; text-align: center;">
<img src="<?php echo base_url();?>upload/institute_logo/<?php echo $tl['rejulation_image'];?>" width="650px" height="650px">
</td>
</tr>
 <?php } ?>





</tbody>
</table>



         </div>
      </div>
       
      <!-- **portfolio-container - Starts** -->
      <div class="portfolio-container with-space">
          
      </div>
   </div>
</div>

<?php include 'application/views/home/inc/footer.php';?>