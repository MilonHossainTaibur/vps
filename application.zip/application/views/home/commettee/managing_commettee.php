<?php include 'application/views/home/inc/header.php';?> 
<!-- **Full-width-section - Starts** -->

<div class="container-fluid">    
    
    <div class="row section-course-title add-padding" style="background-color: #29303B; color: #fff; padding-top: 20px;">
      <div class="container">
        <div class="col-md-12">
            <div class="course-head">
                <h1><?= $products_list[0]['member_name']?></h1>
               
            </div>
        </div>
     

       

         </div>
        </div>
               <div class="row">
                <div class="container">
                    <div class="col-md-12">
                        <div class="well">
                            
                           <div class="row">
                               <div class="col-md-12">
                                 <img src="<?= base_url()?>upload/managing_committee/<?= $products_list[0]['member_image'];?>" width="260px" height="260px" alt="<?= $products_list[0]['member_name'];?>"//>   
                               </div>
                              </div>
                              <div class="row">
                               <div class="col-md-12">
                                <div style="color:#000000!important; font-family: Arial, Helvetica, sans-serif!important; padding: 20px!important; font-size: 13px20px!important;">
                                 <?= $products_list[0]['member_desig']?> 
                               </div>
                          
                              </div>
                           </div>
                    </div>
             </div>

     </div>
   </div>
</div>


<!-- **Full-width-section - Ends** -->
<?php include 'application/views/home/inc/footer.php';?>

