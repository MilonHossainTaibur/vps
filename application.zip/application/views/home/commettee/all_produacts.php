<?php include 'application/views/home/inc/header.php';?> 
<!-- **Full-width-section - Starts** -->

<div class="container-fluid">    
    
    <div class="row section-course-title add-padding" style="background-color: #29303B; color: #fff; padding-top: 20px;">
      <div class="container">
        <div class="col-md-12">
            <div class="course-head">
                <h1>All Product</h1>
               
            </div>
        </div>
     

       

         </div>
        </div>
               <div class="row">
                <div class="container">

             
                <div class="row">
                   
                    <div class="portfolio_slider_wrap col-md-12 content-softskill" style="padding-top: 30px">

                          <?php foreach($products_list as $sl){ ?>
                        
                        <a class="course-each-item" href="courses/fresh-executive.html">
                                <div class="col-md-3">
                                    <div class="single-new-product">
                                         <img src="<?= base_url()?>upload/managing_committee/<?= $sl['member_image'];?>" width="60px" height="60px" alt="course"/>
                                        <div class="title_content_wrap">
                                            <div class="anchor_title_wrap">
                                              <span class="port_title wow fadeInUp">
                                                  <a class="course-inner-title" href="<?= base_url()?>home/managing_commettee"><?= $sl['member_name'];?></a>
                                              </span>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </a>
                        
                      <?php   } ?>
                    
                     </div>
          </div>
      
     </div>
   </div>
</div>


<!-- **Full-width-section - Ends** -->
<?php include 'application/views/home/inc/footer.php';?>

