<?php include 'application/views/home/inc/header.php';?>
<!-- Primary Starts -->
<section id="primary" class="content-full-width grey1">
   <div class="dt-sc-margin20"></div>
   <h2 class="aligncenter">নোটিশ বোর্ড</h2>
   <div class="container">
   <div class="row">
       <div class="col-md-8">
       <table class="table table-bordered" >
      <tr>
          <th>নোটিশ</th>
          <th>প্রকাশকাল</th>
      </tr>
	  <?php foreach($notice_list as $ntl) { ?>
         <tr>
            <td>
               <a href="<?= base_url()?>home/single_notice/<?= $ntl['notice_id'] ?>"><?= $ntl['notice_heading'] ?></a>      
            </td>
            <td><?= date('d M, Y',strtotime($ntl['publish_date'])) ?> </td>
         </tr>
	  <?php } ?>
      </table>
      </div>
      <div class="col-md-4"></div>
   </div>
      
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>

