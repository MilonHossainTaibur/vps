<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
	<div class="container" style="background:#FFF;">
		<div class="dt-sc-margin30"></div>
		<!-- **Blog-post - Starts** -->
		<!-- **entry-detail - Starts** -->
                        <div class="entry-detail">
                            <div class="entry-title">
                              
                            </div>
                            <!-- **entry-meta-data - Starts** -->
                            <div class="entry-meta-data left-align bangla">                               
                                <p><span class="fa fa-tag"> <?= $notice_info['notice_heading']; ?> </span> <span class="pull-right"> তারিখঃ <?= $notice_info['publish_date']; ?></span></p>
                            </div> <!-- **entry-meta-data - Ends** -->
                            <div class="entry-body justify">
							<?= $notice_info['notice_details'] ?>
                                                     </div>
                            
                        </div> <!-- **entry-detail - Ends** -->
                           
                    
                     <div class="dt-sc-margin30"></div> 
	</div>              
</section>
<?php include 'application/views/home/inc/footer.php';?>