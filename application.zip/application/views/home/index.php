<?php include 'application/views/home/inc/headertwo.php';?>

<div class="container-fluid main">
  <div id="myCarousel" class="carousel carousel-fade slide" data-ride="carousel" data-interval="4000">
    <div class="carousel-inner" role="listbox">
          <div class="item active background a">
              <br><br> <br><br> <br><br><br><br>
              <div class="col-md-6 home-fly-image">
                  <img class="img img-responsive fly-image" src="<?php echo base_url();?>template/vps/img/textslider.png" alt="fly text 1" style="">
              </div>
          </div>
          <div class="item background b">
                <br><br> <br><br> <br><br><br><br>
               <div class="col-md-6 home-fly-image">
                   <img class="img img-responsive fly-image" src="<?php echo base_url();?>template/vps/img/textslider.png" alt="fly text 2" style="">
               </div>
          </div>
          <div class="item background c">
                <br><br> <br><br> <br><br><br><br>
               <div class="col-md-6 home-fly-image">
                   <img class="img img-responsive fly-image" src="<?php echo base_url();?>template/vps/img/textslider.png" alt="fly text 3" style="">
               </div>
          </div>
          <div class="item background d">
            <br><br> <br><br> <br><br><br><br>
               <div class="col-md-6 home-fly-image">
                   <img class="img img-responsive fly-image" src="<?php echo base_url();?>template/vps/img/textslider.png" alt="fly text 3" style="">
               </div>
          </div>
    </div>
  </div>

  <div class="covertext">
      <form method="GET" action="<?php echo base_url();?>" accept-charset="UTF-8">
          <div class="section-home-search col-md-5 col-md-offset-7">
              <div class="input-group">
                      <input type="text" name="name"  class="preload-tags form-control input-lg btn-home-search"
                             placeholder="What do you want to Product?">
                      <div class="input-group-btn">
                          <button class="form-control input-lg btn btn-info" type="submit"><i class="fa fa-search"
                                                                            aria-hidden="true"></i></button>
                      </div>
              </div>
          </div>
      </form>

  </div>
  
</div>

</header>
     
     
 <section class="py-5">
   <div class="bg-gray-100 py-5 px-3 px-lg-5 rounded-lg shadow-sm container">
      <div class="row">
         <div class="col-lg-4 col-md-4">
            <div class="p-5"><img src="<?php echo base_url();?>template/vps/img/2_photo.jpg" alt="CEO & Chairman Virtual Group" class="img-fluid rounded-circle shadow-sm"></div>
      <h5 class="text-lg text-uppercase text-primary"><b style="color:#990158">— Md. Khairul Islam</b></h5>
        <h6 class="text-lg text-uppercase text-primary"><I style="color: #495057">— CEO & Chairman Virtual Group</I></h6>
         </div>
         <div class="d-flex align-items-center col-lg-8 col-md-8">
            <div>
               <blockquote class="blockquote-icon">
                  <p class="text-lg text-gray-700 mb-4">To introduce modern Technology in the Construction Industry of Bangladesh we started our journey in the Name of Concrete Technology in the year 2003. It was our utmost try to provide honest service for Construction works and to the customer. With the spirit of modern construction works the company got the opportunity to work with so many Global construction companies 
</p>
                  <h5 class="text-lg text-uppercase text-primary"><a style="margin-top:70px;" target="_blank" href="<?= base_url()?>home/mdMessage" class="btn btn-danger">— Read more —</a></h5>
          
               </blockquote>
            </div>
         </div>
      </div>
   </div>
</section>








<!-- Main Content -->

    <!-- course soft skill section -->
    <div class="container-fluid bg-section-gray">

        <div class="container">
            
            <section class="home_section  bg-section-gray" id="section-soft-skill">
                <div class="row">
                    <div class="section_title">
                        <span class="title_two wow fadeInUp text-center"><h3 style="color:#990158;">Our Products</h3></span>
                        <div class="after-effet1"></div>
                    </div>

                    <div class="portfolio_slider_wrap col-md-12 content-softskill">


                      <?php foreach($products_list as $sl){ ?>
                        
                        <a class="course-each-item" href="<?= base_url()?>home/managing_commettee/<?= $sl['member_id'];?>">
                                <div class="col-md-3">
                                    <div class="single-new-product">
                                         <img src="<?= base_url()?>upload/managing_committee/<?= $sl['member_image'];?>" width="60px" height="60px" alt="<?= $sl['member_name'];?>"/>
                                        <div class="title_content_wrap">
                                            <div class="anchor_title_wrap">
                                              <span class="port_title wow fadeInUp">
                                                  <a class="course-inner-title" href="<?= base_url()?>home/managing_commettee/<?= $sl['member_id'];?>"><?= $sl['member_name'];?></a>
                                              </span>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </a>
                        
                      <?php   } ?>

                        
                        <div class="softskill-extend hide"></div>

                        <div class="col-md-12">
                            <div class="more-course text-center">
                              <h5 class="text-lg text-uppercase text-primary"><a style="margin-top:70px;" target="_blank" href="<?= base_url()?>home/all_produacts" class="btn btn-danger">— View All Product —</a></h5>
                               
                            </div>
                        </div>

                    </div>
                </div>
                
            </section>
        </div>


    </div>


  <div class="container-fluid">
    <div class="container">
      
       <div class="section_title" style="text-align:center">
                    <span class="title_two wow fadeInUp"><h3 style="color:#990158;">We worked with awesome clients</h3></span>
                    <div class="after-effet1"></div>
                </div>
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div id="owl-demo" class="owl-carousel">
            <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/1.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/2.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/3.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/4.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/5.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/6.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/7.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/8.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/9.jpg" alt="">
            </div>
      <div class="item">
              <img src="<?php echo base_url();?>template/vps/img/client/10.jpg" alt="">
            </div>
           
          </div>
        </div>
      </div>
    </div>
  </div> 


<!-- Contributor section -->
<div class="container-fluid bg-section-gray" id="section-trainer">

    <div class="container">
        <div class="contributor text-center">
            <div class="effect_title">
                <div class="section_title" style="text-align:center">
                    <span class="title_two wow fadeInUp"><h3 style="color:#990158;">Management & Marketing Team</h3></span>
                    <div class="after-effet1"></div>
                </div>
            </div>



            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/21.png' class='contact' />
                    <span class='name'>Md. Khairul Islam</span>
                    <hr>
                    <span class='job'>CEO & Chairman Virtual Group</span>
                </div>
                <div class='back'>
                    <span>B.Sc. Engr Civil (KUET) & MBA (BU)</span>
                    <p>Mobile : 01614 099901</p>
          <p>Email: khairul@virtualbd.net</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                   
                </div>
            </div>

            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/22.png' class='contact' />
                    <span class='name'>Md. Mashiar Rahman</span>
                    <hr>
                    <span class='job'>Founder of ASTi & Scientist at VPS Applied Physics & Electronics</span>
                </div>
                <div class='back'>
                    <span>University of Rajshahi</span>
                    <p>Cell: 01631 845492; 01928 979953</p>
          <p>Email: applied.sti@gmail.com</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                    
                </div>
            </div>

            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/23.png' class='contact' alt="siju" />
                    <span class='name'>Engr. Hasan Shahriar Shawon</span>
                    <hr>
                    <span class='job'>Senior Executive Virtual Pharma Solution & Concrete Technology</span>
                </div>
                <div class='back'>
                    <span>B.Sc. In EEE</span>
                    <p>Cell: 01614 099910</p>
          <p>Email: shawon.vps@virtualbd.net,<br>shawon.vps@gmail.com</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                   
                </div>
            </div>

            <div class='col-md-3 con-body'>
                <div class='front'>
                    <img src='<?php echo base_url();?>template/vps/img/trainer/24.png' class='contact' alt="m shahidul" />
                    <span class='name'>Engr. Abdur Rahaman</span>
                    <hr>
                    <span class='job'>Senior Executive Virtual Pharma Solution & Concrete Technology</span>
                </div>
                <div class='back'>
                    <span>B.Sc. In EEE</span>
                    <p>Email: rahaman.vps@virtualbd.net,<br>arahaman.vps@gmail.com</p>
                    <span>Social media </span>
                    <div class='icons'>
                        <a href="#" class="author-sm">
                            <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        </a>
                        <a href="#" class="author-sm">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </div>
                   
                </div>
            </div>



        </div>
    </div>



</div>
            


<!--END Contributor section -->
 <!--link to skillfest-->
    <div class="container-fluid">
        <div class="container">
            <div class="row">
              
                <!--<h4 class="text-center">As We Commited</h4>-->
                <!--<div class="after-effet1"></div>-->
               <div class="col-md-6"><br>
                   <img src="<?php echo base_url();?>template/vps/img/brocheure_cover.jpg" class="img img-responsive" alt="">
               </div>
               <div class="col-md-6">
                   <a style="margin-top:70px;" target="_blank" href="<?php echo base_url();?>template/vps/img/vpsprofile.pdf" class="btn btn-danger">Download our Company Profile</a>
               </div>

            </div>
                
            </div>

        
    </div>

    <!--link to skillfest-->



<script src="<?= base_url();?>template/vps/js/javascript.js"></script>


<!-- End content -->




<!-- Footer -->

  <link rel="stylesheet" href="css/style.css">
<!-- **Main - Ends** --> <!-- **Main - Ends** --> 
<!-- **dt-sc-team - Starts** -->
<?php include 'application/views/home/inc/footer.php';?>

