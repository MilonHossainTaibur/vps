<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="dt-sc-margin65"></div>
 <div id="main">
            <!-- **Full-width-section - Starts** -->
            <div class="full-width-section grey1"> 
            <div class="dt-sc-margin20"></div>
                <div class="container">
                    <p style="font-size:28px; color:#000000;" class="aligncenter"><i class="fa fa-list" aria-hidden="true"></i> ১৯৭১ সালে অত্র বিদ্যালয়ে অধ্যয়নরত মহান মুক্তিযুদ্ধে অংশগ্রহনকারী শিক্ষার্থীদের তালিকা</p>
                    <div class="title-sep">
                            </div>
                    <div class="dt-sc-hr-invisible-small"></div>
                    <!-- **portfolio-container - Starts** -->
                    <div class="portfolio-container with-space  class="gallery clearfix"">
                         <?php foreach($freedom_fighter as $fl){ ?>
                        <div class="portfolio dt-sc-one-fifth with-space column all-sort <?= $images['catagory_id']?>">
                            <!-- **portfolio-thumb - Starts** -->
                            <div class="portfolio-thumb">
                                <img class="lazy" data-original="<?= base_url()?>upload/freedom_fighter/<?= $fl->f_photo ;?>" src="<?= base_url()?>upload/freedom_fighter/<?= $fl->f_photo ;?>" alt="<?= $fl->f_name;?>"/>
                                <div class="image-overlay">
                                    <a class="zoom" href="<?= base_url()?>upload/freedom_fighter/<?= $fl->f_photo ;?>" data-gal="prettyPhoto[gallery]" title="<?= $fl->f_name;?>"><span class="fa fa-search-plus"></span></a>
                                </div>
                            </div> <!-- **portfolio-thumb - Ends** -->
                            <!-- **portfolio-detail - Starts** -->
                            <div class="portfolio-detail">
                               
                                <div class="portfolio-title">
                                    <p><?= $fl->f_name;?></p>
                     <p><?= $fl->f_address;?></p>
                                </div>
                            </div> <!-- **portfolio-detail - Ends** -->
                        </div>
                         <?php } ?>
                    </div><!-- **portfolio-container - Ends** -->
                    <div class="dt-sc-hr-invisible-small"></div>    
                </div>
            </div--> <!-- **Full-width-section - Ends** -->
            
       </div>  
<?php include 'application/views/home/inc/footer.php';?>

