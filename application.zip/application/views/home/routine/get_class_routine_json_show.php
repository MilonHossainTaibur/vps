
<table id="" class="table table-bordered" width="100%" cellspacing="0" border="1">
	<thead>
        <tr>
        	<th>Class Time</th>
            <?php foreach($class_time as $ct){?>
            <th id="classDuration"><?php echo $ct['start_time'].'-'.$ct['close_time'];?></th>  
            <?php }?>
        </tr>
    </thead>
    <tbody>
    	<tr>
            <td>Class Period</td>
            <?php foreach($class_time as $ct){ ?>
            <td id='clperiod'><?php echo $ct['period'];?></td>  
            <?php }?>
        </tr>
        <?php foreach($week as $wk){ ?>
        <tr>
        	<td id='wkday'><?php echo $wk['day'];?></td>
            <?php for($i=0; $i<count($class_time); $i++){ ?>
            <td id="<?php echo $wk['day'];?>">
                <div class="<?= 'div'.$i.$wk['day'];?>">
					<span class="form-control" style="border:none;" name="teachers_name" id="<?= 'tid'.$i;?>" >
						<!---Teacher name will be display here--->
					</span>
                
                    <span class="form-control subject_name" style="border:none;" name="subject_name" id="<?= 'cid'.$i;?>">
                     <!---Subject name will be display here--->
                    </span>
                </div>
			</td>  
            <?php }?>
        </tr>  
        <?php }?>
    </tbody>
</table>

<div class="print_button" style="padding-left:20px;">
	<input type="submit" class="button" value="প্রিন্ট করুন" name="searchBtnclass_result" onclick="printPageArea('display')"/>
</div>
<script>
function new_box_old_routine(i,wk,id)
	{
		$('div.div'+i+wk).append('<span id="classtid'+id+'" class="form-control" style="border:none;"></span><span class="form-control subject_name" style="border:none;" id="classcid'+id+'"></span>');
	}
</script>