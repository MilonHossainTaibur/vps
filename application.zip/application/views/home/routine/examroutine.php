<?php include 'application/views/home/inc/header.php';?>
<!-- Primary Starts -->
<section id="primary" class="content-full-width grey1">
   <div class="dt-sc-margin20"></div>
   <h2 class="aligncenter">পরীক্ষার রুটিন</h2>
   <div class="container">
   <div class="dt-sc-margin50"></div>\
		<div class="panel-body dt-sc-reservation-form">
			<div class="form-group">
				<div class="row">
                                    	<div class="col-sm-4" >
                                        	<label>পরীক্ষা <span style="color:red;">*</span></label>
                      						<select class="form-control" name="term_id" id="term_id">
                                            	<option value="">----পরীক্ষা----</option>
                                                <?php foreach($term_list as $tl){ ?>
                                                <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>   
                                                <?php    } ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-4" >
                                        	<label>শ্রেণী  <span style="color:red;">*</span></label>
                      						<select class="form-control" name="class_id" id="class_id">
                                            	<option value="">----শ্রেণী----</option>
                                                <?php foreach($class_list as $cl){ ?>
                                                <option value="<?= $cl['class_id'];?>"><?= $cl['class_name'];?></option>   
                                                <?php    } ?>
                                            </select>
                                        </div>
                                    </div>
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-sm-4">
									<button type="button" class="button btn btn-info" onclick="exam_routine_json()">রুটিন দেখুন</button>
								</div>
							</div>
						</div>
					</div> 
					
					<div class="dt-sc-margin20"></div>
					<div id="display" style="padding-bottom:70px;">
						<!-- content will display here -->
					</div>
					
					<div class="dt-sc-margin20"></div>
	</div>
	
	
</section>
<?php include 'application/views/home/inc/footer.php';?>
<script type="text/javascript">
function get_day(exam_date,id)
{
	 var dayNames = new Array( 'Sunday' , 'Monday' , 'Tuesday' , 'Wednesday' , 'Thursday' , 'Friday' , 'Saturday' );
     var nData = new Date (exam_date);
	 
	 $('.date'+id).next('td').html(dayNames[nData.getDay()]);
	
}

function exam_routine_json()
{
	var term_id=$('#term_id').val();
	var class_id=$('#class_id').val();
	$.ajax({ 
        url: baseUrl+'home/exam_routine_json',
        data:
            {                  
                'term_id':term_id,
				'class_id':class_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {
                    $('#display').html(mainContent);
					// call the routine if created before
					get_old_exam_routine_by_term_show(term_id,class_id);
                }                
            }
        });
        return false; // keeps the page from not refreshing     
}
</script>
<script>

function get_old_exam_routine_by_term_show(term_id,class_id)
{//1
	
	 $.getJSON(//6
				baseUrl + 'home/get_old_exam_routine_by_term_show',
				{ 
					'exam_term_id':term_id,
					'class_id':class_id
				},
				function(jd) {
						
				for(i=0; i<jd.length; i++)
				{
					$("td[id='d"+jd[i].row_no+"'] .timerange").text(jd[i].exam_date);
					$("td[id='wkday"+jd[i].row_no+"']").html(jd[i].exam_day);
					$("td[id='"+jd[i].row_no+jd[i].column_no+"'] span").text(jd[i].subject_name);
				}
									
			});////6					
}////1

function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>