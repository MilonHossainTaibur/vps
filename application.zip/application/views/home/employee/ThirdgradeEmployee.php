

<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="dt-sc-margin65"></div>
   <div class="container">
      <div class="per_staf">
         <h2>স্থায়ী কর্মচারি</h2>
         <div class="row" style="text-align:center">
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/per_office asst/saiz_uddin.jpg">
                  <div class="desc_info">
                     <h3>সাইজউদ্দিন</h3>
                     <h4>অফিস সহকারী</h4>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/per_office asst/anwara_begum.jpg">
                  <div class="desc_info">
                     <h3>আনোয়ারা বেগম</h3>
                     <h4>অফিস পিয়ন</h4>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/per_office asst/fakrul_islam.jpg">
                  <div class="desc_info">
                     <h3>ফখরুল ইসলাম</h3>
                     <h4>অফিস পিয়ন</h4>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="clearfix"></div>
      <div class="tem_staf">
         <h2>অস্থায়ী কর্মচারি</h2>
         <div class="row" style="text-align:center">
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/temo_ffice_asst/asma_akter.jpg">
                  <div class="desc_info">
                     <h3>আসমা আক্তার</h3>
                     <h4>অফিস সহকারী</h4>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/temo_ffice_asst/jutsna_dattua.jpg">
                  <div class="desc_info">
                     <h3>জ্যোৎস্না দত্ত</h3>
                     <h4>অফিস সহকারী</h4>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/tem_peon/arfan_ali.jpg">
                  <div class="desc_info">
                     <h3>আরফান আলী</h3>
                     <h4>অফিস পিয়ন</h4>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/tem_peon/manik_khan.jpg">
                  <div class="desc_info">
                     <h3>মানিক মিয়া</h3>
                     <h4>অফিস পিয়ন</h4>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/tem_peon/masum.jpg">
                  <div class="desc_info">
                     <h3>মাসুদ রানা মাসুম</h3>
                     <h4>অফিস পিয়ন</h4>
                  </div>
               </div>
            </div>
            <div class="col-md-3">
               <div class="single_info">
                  <img class="img-thumbnail img-responsive" src="<?= base_url() ?>template/assets/images/tem_peon/rojina_akter.jpg">
                  <div class="desc_info">
                     <h3>রোজিনা আক্তার</h3>
                     <h4>অফিস পিয়ন</h4>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/home/inc/footer.php';?>

