<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   
   <div class="container">
            <div class="col-sm-12">
                <div class="widget">
                    <div class="widget-content padding">
                        <div class="row">          
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-content">
                                 <h1>Gypsum Decoration</h1>
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>SLNO</th>
                                                        <th>Name</th>
                                                        <th>Discription</th>
                                                      
                                                        <th>Picture</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i=1; foreach($teacher_list as $tl){ ?>
                                                    <tr>
                                                        <td><?php echo $i;?></td>
                                                        <td><?php echo $tl['teacher_name'];?></td>
                                                        <td><?php echo $tl['department_id'];?></td>
                                                        
                                                        <td>
                        <img src="<?php echo base_url();?>upload/teacher_image/<?php echo $tl['teacher_image'];?>" height="100" width="100"/>
                                                            <input type="hidden" class="form-control" name="sms_contact[]" id="sms_contact" value="<?php echo $tl['present_contact'];?>">
                                                            <input type="hidden" class="form-control" name="teacher_name[]" id="teacher_name" value="<?php echo $tl['teacher_name'];?>">
                                                        </td>
                                                     
                                                    </tr>
                                                    <?php $i++; } ?>
                                                   
                                                </tbody>
                                            </table>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
   </div>
</div>
<?php include 'application/views/home/inc/footer.php';?>

