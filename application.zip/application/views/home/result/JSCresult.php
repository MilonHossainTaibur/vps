<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
<div class="dt-sc-margin65"></div>
<div id="main">
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="dt-sc-margin20"></div>
   <div class="container">
      <div class="dt-sc-margin20"></div>
      
      <div class="hr-title">
                            <h3><i class="fa fa-list" aria-hidden="true"></i>জুনিয়র বৃত্তি ও জেএসসি পরীক্ষা সংক্রান্ত তথ্য
</h3>
                            <div class="title-sep">
                            </div>
                        </div>
      <p style="font-size:28px; color:#000000;" class="aligncenter"></p>
    
      <div class="table-responsive">
         <table class="table table-bordered table-striped" width="100%">
            <thead>
               <tr>
                  <th colspan="7"></th>
                  <th colspan="5">বৃত্তি প্রাপ্ত সংখ্যা</th>
                  
                  
               </tr>
               <tr>
                  <th rowspan="2">সন</th>
                  <th colspan="2"> জেএসসি পরীক্ষার্থী</th>
                  <th colspan="2"> উত্তীর্ন</th>
                  <th>মোট</th>
                  <th>পাসের হার</th>
                  <th colspan="2">ট্যালেন্টপুল</th>
                  <th colspan="2">সাধারন</th>
                  <th>মোট</th>
               </tr>
            </thead>
            <tbody>
               <tr>
                 <td></td>
                  <td>বালক</td>
                  <td>বালিকা</td>
                  <td>বালক</td>
                  <td>বালিকা</td>
                  <td></td><td></td>
                  
                  <!--td colspan="2"></td-->
                  <td>বালক</td>
                  <td>বালিকা</td>
                  <td>বালক</td>
                  <td>বালিকা</td>
                  <td></td>
               </tr>
               <tr>
                  <td>২০১৬</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
                <tr>
                  <td>২০১৫</td>
                  <td>১৬৪</td>
                  <td>১৪৫</td>
                  <td>১৬১</td>
                  <td>১৪২</td>
                  <td>৩০৩</td>
                  <td>৯৮.০৫%</td>
                  <td>০১</td>
                  <td>০৩</td>
                  <td>০৮</td>
                  <td>০৬</td>
                  <td>১৮</td>
               </tr>
                <tr>
                  <td>২০১৪</td>
                  <td>১৯৭</td>
                  <td>১৯০</td>
                  <td>১৭১</td>
                  <td>১৮০</td>
                  <td>৩৫১</td>
                  <td>৯৯.০৭%</td>
                  <td>০২</td>
                  <td>০৮</td>
                  <td>০৩</td>
                  <td>০৪</td>
                  <td>১৭</td>
               </tr>
               <tr>
                  <td>২০১৩</td>
                  <td>১৯৫</td>
                  <td>১৬৩</td>
                  <td>১৮৮</td>
                  <td>১৫৫</td>
                  <td>৩৪৩</td>
                  <td>৯৫.৮১%</td>
                  <td>০১</td>
                  <td>০২</td>
                  <td>০৮</td>
                  <td>০৮</td>
                  <td>১৯</td>
               </tr>
               <tr>
               <tr>
                  <td>২০১২</td>
                  <td>১৩৫</td>
                  <td>১২৮</td>
                  <td>১৩৩</td>
                  <td>১২৪</td>
                  <td>২৫৭</td>
                  <td>৯৮%</td>
                  <td>০২</td>
                  <td>১২</td>
                  <td>০১</td>
                  <td>০৪</td>
                  <td>০৯</td>
               </tr>
               <tr>
                  <td>২০১১</td>
                  <td>১১৫</td>
                  <td>১২৫</td>
                  <td>১১৫</td>
                  <td>১২৫</td>
                  <td>২৪০</td>
                  <td>১০০%</td>
                  <td>০৫</td>
                  <td>১৪</td>
                  <td>১৪</td>
                  <td>০৭</td>
                  <td>৪০</td>
               </tr>
               <tr>
                  <td>২০১০</td>
                  <td>৯১</td>
                  <td>১০৩</td>
                  <td>৯১</td>
                  <td>৮১</td>
                  <td>১৭২</td>
                  <td>৮৯.১১%</td>
                  <td>০৫</td>
                  <td>০৪</td>
                  <td>০৩</td>
                  <td>১০</td>
                  <td>২২</td>
               </tr>
            </tbody>
         </table>
         <br>
      </div>
   </div>
   </div--> <!-- **Full-width-section - Ends** -->
</div>
<?php include 'application/views/home/inc/footer.php';?>

