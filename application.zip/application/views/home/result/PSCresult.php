<?php include 'application/views/home/inc/header.php';?>
<?php include 'application/views/home/pending.php';?>
    <?php include 'application/views/home/inc/footer.php';?>