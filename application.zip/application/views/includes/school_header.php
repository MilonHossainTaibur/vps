<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <title>Copotronic Institute Management System</title>   
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="description" content="">
        <meta name="keywords" content="online school management, school management, educational institute management, institute management, college management, student management, teacher management, result management">
        <meta name="author" content="Huban Creative">

        <?php include 'application/views/includes/includes.php';?>
    </head>
    <body class="fixed-left">
       
	<div id="wrapper">
		
<!-- Top Bar Start -->
<div class="topbar">
    <div class="topbar-left">
        <div class="logo">
            <h1><a href="#"><img src="<?php echo base_url();?>template/img/logo.png" alt="Logo"></a></h1>
        </div>
        <button class="button-menu-mobile open-left">
        <i class="fa fa-bars"></i>
        </button>
    </div>
    <!-- Button mobile view to collapse sidebar menu -->
    <div class="navbar navbar-default" role="navigation">
        <div class="container">
            <div class="navbar-collapse2">               
                <ul class="nav navbar-nav navbar-right top-navbar">
                    <li class="dropdown topbar-profile">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="rounded-image topbar-profile-image"><img src="<?php echo base_url();?>template/images/users/user-35.jpg"></span><strong> User </strong><i class="fa fa-caret-down"></i></a> 
                        <ul class="dropdown-menu">                            
                            <li><a href="#">Change Password</a></li>
                            <li><a href="<?php echo base_url();?>login/logout"><i class="icon-logout-1"></i> Logout</a></li>
                        </ul>
                    </li>
                   
                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
    </div>
</div>