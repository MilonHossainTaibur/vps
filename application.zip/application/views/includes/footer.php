			<footer> <!-- Footer Start -->
            	<center>
                    <img src="<?php echo base_url();?>template/images/logo.png" height="50" width="100" style="margin-bottom: -35px;;"/> 
                    <p style="display: block;margin-bottom: -30px;margin-top: 35px;">
                        Technical Support - <a href="http://www.weblinkltd.com/dev">Weblink Communication LTD</a>
                    </p>                   
                </center>
            </footer>
            <!-- Footer End  ©-->			
            </div>
			<!-- ============================================================== -->
			<!-- End content here -->
			<!-- ============================================================== -->

        </div>
		<!-- End right content -->

	</div>
	<div id="contextMenu" class="dropdown clearfix">
		    <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
		        <li><a tabindex="-1" href="javascript:;" data-priority="high"><i class="fa fa-circle-o text-red-1"></i> High Priority</a></li>
		        <li><a tabindex="-1" href="javascript:;" data-priority="medium"><i class="fa fa-circle-o text-orange-3"></i> Medium Priority</a></li>
		        <li><a tabindex="-1" href="javascript:;" data-priority="low"><i class="fa fa-circle-o text-yellow-1"></i> Low Priority</a></li>
		        <li><a tabindex="-1" href="javascript:;" data-priority="none"><i class="fa fa-circle-o text-lightblue-1"></i> None</a></li>
		    </ul>
		</div>
	<!-- End of page -->
		<!-- the overlay modal element -->
	<div class="md-overlay"></div>
	<!-- End of eoverlay modal -->
	<script>
		var resizefunc = [];
	</script>
	<!-- jQuery (necessary for Bootstraps JavaScript plugins) -->
	<script src="<?= base_url();?>template/libs/jquery/custom.js"></script>
       <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
	<script src="<?= base_url();?>template/libs/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?= base_url();?>template/libs/jqueryui/jquery-ui-1.10.4.custom.min.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-ui-touch/jquery.ui.touch-punch.min.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-detectmobile/detect.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-animate-numbers/jquery.animateNumbers.js"></script>
	<script src="<?= base_url();?>template/libs/ios7-switch/ios7.switch.js"></script>
	<script src="<?= base_url();?>template/libs/fastclick/fastclick.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-blockui/jquery.blockUI.js"></script>
	<script src="<?= base_url();?>template/libs/bootstrap-bootbox/bootbox.min.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-slimscroll/jquery.slimscroll.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-sparkline/jquery-sparkline.js"></script>
	<script src="<?= base_url();?>template/libs/nifty-modal/js/classie.js"></script>
	<script src="<?= base_url();?>template/libs/nifty-modal/js/modalEffects.js"></script>
	<script src="<?= base_url();?>template/libs/sortable/sortable.min.js"></script>
	<!--<script src="<?//php echo base_url();?>template/libs/bootstrap-fileinput/bootstrap.file-input.js"></script>
	<script src="<?//php echo base_url();?>template/libs/bootstrap-select/bootstrap-select.min.js"></script>-->
	
	<script src="<?= base_url();?>template/libs/bootstrap-select2/select2.min.js"></script>
	
	<script src="<?= base_url();?>template/libs/magnific-popup/jquery.magnific-popup.min.js"></script> 
	<script src="<?= base_url();?>template/libs/pace/pace.min.js"></script>
	<script src="<?= base_url();?>template/libs/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-icheck/icheck.min.js"></script>
	
	<!--
	<script src="<?= base_url();?>template/libs/jquery-datatables/js/jquery.dataTables.min.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-datatables/js/dataTables.bootstrap.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-datatables/extensions/TableTools/js/dataTables.tableTools.min.js"></script>-->

   

	<!-- Demo Specific JS Libraries -->
	<script src="<?= base_url();?>template/libs/prettify/prettify.js"></script>

	<script src="<?= base_url();?>template/js/init.js"></script>
	<!-- Page Specific JS Libraries -->
	<script src="<?= base_url();?>template/libs/d3/d3.v3.js"></script>
	<script src="<?= base_url();?>template/libs/rickshaw/rickshaw.min.js"></script>
	<script src="<?= base_url();?>template/libs/raphael/raphael-min.js"></script>
	<script src="<?= base_url();?>template/libs/morrischart/morris.min.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-knob/jquery.knob.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-jvectormap/js/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-jvectormap/js/jquery-jvectormap-us-aea-en.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-clock/clock.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-easypiechart/jquery.easypiechart.min.js"></script>
	<script src="<?= base_url();?>template/libs/jquery-weather/jquery.simpleWeather-2.6.min.js"></script>
	<script src="<?= base_url();?>template/libs/bootstrap-xeditable/js/bootstrap-editable.min.js"></script>
	<script src="<?= base_url();?>template/libs/bootstrap-calendar/js/bic_calendar.min.js"></script><!-- need attention -->
	<script src="<?= base_url();?>template/js/apps/calculator.js"></script><!-- need attention -->
	<script src="<?= base_url();?>template/js/apps/todo.js"></script>
	<script src="<?= base_url();?>template/js/apps/notes.js"></script>
	<script src="<?= base_url();?>template/js/pages/index.js"></script>
	
	<script src="<?= base_url();?>template/libs/bootstrap-inputmask/inputmask.js"></script><!-- need attention -->
	<script src="<?= base_url();?>template/libs/summernote/summernote.js"></script><!-- need attention -->
	<script src="<?= base_url();?>template/js/pages/forms.js"></script>
	
	<!-- Added for accounts -->
	<script src="<?= base_url();?>template/js/pages/valid-functions.js"></script>
	<!-- Added for accounts -->  
	
	<!--- add for date time picker -->
    
    <script src="<?= base_url();?>template/libs/bootstrap-daterangepicker/moment.min.js"></script>
    <script src="<?= base_url();?>template/libs/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!--- /add date time picker -->
	
    <!--- <script src="<?php echo base_url();?>template/libs/jqxJs/jqxcore.js"></script>
   	<script src="<?php echo base_url();?>template/libs/jqxJs/jqxdatetimeinput.js"></script>
   	<script src="<?php echo base_url();?>template/libs/jqxJs/jqxcalendar.js"></script>
   	<script src="<?php echo base_url();?>template/libs/jqxJs/jqxtooltip.js"></script>
   	<script src="<?php echo base_url();?>template/libs/jqxJs/globalize.js"></script>-->
	  
      
      <!-- /add by Sharif for web -->
      
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?= base_url();?>template/datatable/js/jquery.dataTables.min.js"></script>
	<script src="<?= base_url();?>template/datatable/js/dataTables.buttons.min.js"></script>
	<script src="<?= base_url();?>template/datatable/js/jszip.min.js"></script>
	<script src="<?= base_url();?>template/datatable/js/pdfmake.min.js"></script>
	<script src="<?= base_url();?>template/datatable/js/vfs_fonts.js"></script>
	<script src="<?= base_url();?>template/datatable/js/buttons.html5.min.js"></script>
	<script src="<?= base_url();?>template/js/pages/datatables.js"></script>
<script src="<?= base_url();?>template/plugins/justified-gallery/jquery.justifiedgallery.min.js"></script>
<script src="<?= base_url();?>template/plugins/tinymce/tinymce.min.js"></script>
<script src="<?= base_url();?>template/plugins/tinymce/jquery.tinymce.min.js"></script>
<script src="<?= base_url();?>template/js/devoops.js"></script>

<?php 
$all_array=array('message','notice','information_list','slide','about','photos','tea_reg','tea_list','tea_asign','tea_salery','atten','stu_reg','stu_list','stu_assign','att','fee_man','fee_gen_edit','fee_gen','fee_coll_edit','fee_coll','stu_wise_fee_edit','stu_wise_fee','fees_rep','res_man','marks','res_report','stu_entro','ac_man','nav_head_view','debit_vou','credit_vou','library','add_book','book_list','book_issue','lib_fin','mov_log','re_book','ser_book','sms','routin','sett','gen_sett','class','sec','group','sess_set','shift_set','subject','exam','exam_stt','ad_card','exam_set','fees','holi','aca_cal','tea_staff','auth');

$user_array=explode(',',$_SESSION['user_access']);
if($_SESSION['is_superadmin']!=1)
	$not_allowed=array_diff($all_array,$user_array);
else
	$not_allowed=array('fee_gen','fee_coll','stu_wise_fee');
?>
<script>
function my_code(){ 
	var not_allowed=<?php print_r(json_encode($not_allowed)); ?>;
	if(not_allowed){
		for(i=0; i<58; i++ )
		{
			if(not_allowed[i])
			{
				if($('li').hasClass(not_allowed[i]))
				{
					$('.'+not_allowed[i]).hide();
				}
			}
		}
	}
	
	$('.menu_active_class').show();
}
$('.datepicker-input').datepicker();
window.onload=my_code();
</script>

</body>
</html>