
    <div class="left side-menu">
        <div class="sidebar-inner slimscrollleft" style="background:#35363A;">
            <div id="sidebar-menu">
                <ul class="menu_active_class" style="display:none;">
                    <li class="web_db"><a href='<?= base_url();?>admin'><i class='fa fa-dashboard animated-hover fa-slow'></i><span>Dashboard</span></a>
                    </li>
                    <li><a href='http://virtualbd.net/vps/' target="_blank"><i class='icon-home-3'></i><span>Visit Site</span> <span class="pull-right"></span></a>
                    </li>
              <!--        <li class="notice">
                        <a href="<?= base_url();?>web/slide" title="Message">
                            <i class="fa fa-picture-o"></i>
                            <span class="hidden-xs">Slider</span>
                        </a>
                    </li> -->
                      <!-- <li class="notice">
                        <a href="<?= base_url();?>web/message" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">CEO Massage</span>
                        </a>
                    </li> -->
                      <li class="notice">
                        <a href="<?= base_url();?>web/vpsproduct_create" title="Message">
                            <i class="fa fa-product-hunt" aria-hidden="true"></i>
                            <span class="hidden-xs">Products</span>
                        </a>
                    </li>
                  <!--     <li class="notice">
                        <a href="<?= base_url();?>web/rejulation_view" title="Message">
                            <i class="fa fa-user-o" aria-hidden="true"></i>
                            <span class="hidden-xs">Clients</span>
                        </a>
                    </li> -->
                  <!--     <li class="notice">
                        <a href="<?= base_url();?>web/managing_committee" title="Message">
                            <i class="fa fa-user-circle" aria-hidden="true"></i>
                            <span class="hidden-xs">Our Team</span>
                        </a>
                    </li> -->

                    <li class="notice">
                        <a href="<?= base_url();?>web/institute_information" title="Message">
                            <i class="fa fa-list"></i>
                            <span class="hidden-xs">General Information</span>
                        </a>
                    </li>
                   <!--  <li class=''><a href='javascript:void(0);'><i class="fa fa-list"></i><span>Information</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>
                     <li class="message">
                        <a href="<?= base_url();?>web/institute_information" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">General Information</span>
                        </a>
                    </li>
                     <li class="message">
                        <a href="<?= base_url();?>web/message" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Message</span>
                        </a>
                    </li>
                    <li class="message">
                        <a href="<?= base_url();?>web/rejulation_view" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Rejulation</span>
                        </a>
                    </li>
                  
                  
                
            
                    <li class="about">
                            <a href="<?= base_url();?>web/about" title="About">
                                <i class="fa fa-file-text-o"></i>
                                <span class="hidden-xs">About</span>
                            </a>
                        </li>
                    </ul>
                    </li>
                    <li class=''><a href='javascript:void(0);'><i class="fa fa-align-justify" aria-hidden="true"></i>
<span>Committee/Donor</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li><a href="<?= base_url();?>web/managing_committee">Managing Committee</a></li>
                           <!--  <li>
                                <a href="<?= base_url();?>web/donor" title="Donor">
                                    <span class="hidden-xs">Donor</span>
                                </a>
                            </li> -->
                   <!--      </ul>
                    </li>
                    <li class='has_sub photos'><a href='javascript:void(0);'><i class="fa fa-picture-o"></i><span>Gallery</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li><a href="<?= base_url();?>web/picture_gallery">Photo Gallery</a></li>
                            <li><a href="<?= base_url();?>web/catagory_list">Photo Catagory</a></li>
                            <li class="slide">
                                <a href="<?= base_url();?>web/slide" title="Slide">
                                    <i class="fa fa-picture-o"></i>
                                    <span class="hidden-xs">Slide</span>
                                </a>
                            </li> -->
<!-- <li>
                                <a href="<?= base_url();?>web/freedom_fighter" title="freedom_fighter">
                                    <span class="hidden-xs">Freedom Fighter</span>
                                </a>
                            </li> -->

                 <!--        </ul>
                    </li>
                    <li class='has_sub teacher'><a href='javascript:void(0);'><i class='fa fa-user'></i><span>Teacher/Staff Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class="tea_reg"><a href="<?= base_url();?>admin/teacher_registration"><span>Teachers Registration</span></a></li>
                            <li class="tea_list"><a href="<?= base_url();?>admin/teacher_list"><span>Teacher List</span></a></li>
                            -->
                          <!--   <li class='has_sub tea_salery'>
                                <a href='javascript:void(0);'><span>Teacher Salary</span> <span class="pull-right"><i class="fa fa-angle-down"></i> </span> </a>
                                <ul>
                                    <li><a href="<?= base_url();?>admin/salary_cat"><span>Teacher Salary Catagory</span></a></li>
                                    <li><a href="<?= base_url();?>admin/teacher_salary_structure"><span>Teacher Salary Structure</span></a></li>
                                </ul>
                            </li> -->
                            <!--<li><a href="#"><span>Teachers Class Schedule</span></a></li>
						<li><a href="#"><span>Leave Application</span></a></li>-->
                          <!--   <li class='has_sub atten'>
                                <a href='javascript:void(0);'><span>Attendance</span> <span class="pull-right"><i class="fa fa-angle-down"></i> </span> </a>
                                <ul>
                                    <li><a href="<?= base_url();?>attendance/teacher_attendance"><span>Attendance</span></a></li>
                                    <li><a href="<?= base_url();?>attendance/teacher_attendance_report"><span>Report</span></a></li>
                                </ul>
                            </li> -->
                 <!--        </ul>

                    </li> -->
                

                   
                   




                  

                   <!-- <li class='has_sub sett'><a href='javascript:void(0);'><i class='fa fa-wrench'></i><span>Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class='has_sub gen_sett'>
                                <a href='javascript:void(0);'><span>General Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>admin/institute_information"><span>Institute Information</span></a></li>
                                </ul>
                            </li>

                            
                        </ul>
                    </li>--> -->
                </ul>

                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
            <div class="clearfix"></div>
            <br>
            <br>
            <br>
        </div>