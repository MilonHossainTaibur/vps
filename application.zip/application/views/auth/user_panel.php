<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
<style>
.tree li ul{
	margin-left:25px;
}
.tree li {
	font-weight:bold;
}
</style>
</div>
<div class="content-page">
	<!-- Start Content here -->
	<div class="content">
		<div class="page-heading">
        	<h1><i class='fa fa-table'></i> User Authentication</h1>
		</div>
		<?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?> 
		<div class="row">
        	<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content padding">
						<form method="POST" action="<?= base_url(); ?>auth/save_user_auth">
							<div class="row">
								<div class="col-sm-12 col-md-4 col-lg-2">
									<div class="form-group">
										<label>User Name <span style="color:red;">*</span></label>
										<select class="selectpicker" name="login_id" onchange="old_user_access()">
											<option value="">----Select User----</option>
											<?php foreach($user_list as $ul){ ?>
											<option value="<?= $ul->login_id;?>" id="<?= $ul->user_access;?>"><?= $ul->teacher_name;?></option>
											<?php } ?>
										</select>
									</div>
								</div>
								<div class="col-sm-12 col-md-8 col-lg-10">
									<div class="Admin">
									
										<div class="panel panel-info">
											<div class="panel-heading">
												<span class="pull-right">User Access Management</span>&nbsp;
												<span class="pull-left"><p><label><input type="checkbox" id="checkAll"/> Select all</label></p></span>
											</div>
											<div class="panel-body">
												<div class="row">
													<div class="col-sm-4">
														<ul class="tree nested" id="nested">
															<li><input type="checkbox" name="user_access[]" value="message"/> Message </li>
															<li><input type="checkbox" name="user_access[]" value="notice"/> Notice</li>
															<li><input type="checkbox" name="user_access[]" value="information_list"/> Other Information</li>
															<li><input type="checkbox" name="user_access[]" value="slide"/> Slides</li>
															<li><input type="checkbox" name="user_access[]" value="about"/> About</li>
															<li><input type="checkbox" name="user_access[]" value="photos"/> Photos</li>
														</ul>
													</div>
													<div class="col-sm-4">
														<ul class="tree nested" id="nested">
															<li>
																<input type="checkbox" name="user_access[]" value="teacher"/> Teacher/Staff Management
																<ul>
																   <li><input type="checkbox" name="user_access[]" value="tea_reg"/> Teachers Registration</li>
																   <li><input type="checkbox" name="user_access[]" value="tea_list"/> Teachers List</li>
																   <li><input type="checkbox" name="user_access[]" value="tea_asign"/> Class Teacher Assign</li>
																   <li><input type="checkbox" name="user_access[]" value="tea_salery"/> Teachers Salery Structure</li>
																   <li><input type="checkbox" name="user_access[]" value="atten"/> Attendance</li>
																</ul>
															</li>
															<li>
																<input type="checkbox" name="user_access[]" value="stu_man"/> Student Management
																<ul>
																	<li><input type="checkbox" name="user_access[]" value="stu_reg"/> Student Registration</li>
																	<li><input type="checkbox" name="user_access[]" value="stu_list"/> Student list</li>
																	<li><input type="checkbox" name="user_access[]" value="stu_assign"/> Student Subject Assign</li>
																	<li><input type="checkbox" name="user_access[]" value="att"/> Attendence</li>
																</ul>
															</li>
															<li>
																<input type="checkbox" name="user_access[]" value="fee_man"/> Fees Management
																<ul>
																	<li><input type="checkbox" name="user_access[]" value="fee_gen_edit"/> Fee Generate With Edit</li>
																	<li><input type="checkbox" name="user_access[]" value="fee_gen"/> Fee Generate</li>
																	
																	<li><input type="checkbox" name="user_access[]" value="fee_coll_edit"/> Fees Collect With Edit</li>
																	<li><input type="checkbox" name="user_access[]" value="fee_coll"/> Fees Collect</li>
																	
																	<li><input type="checkbox" name="user_access[]" value="stu_wise_fee_edit"/>Student Wise Fees With Edit</li>
																	<li><input type="checkbox" name="user_access[]" value="stu_wise_fee"/>Student Wise Fees</li>
																	
																	<li><input type="checkbox" name="user_access[]" value="fees_rep"/>Report</li>
																</ul>
															</li>
															<li>
																<input type="checkbox" name="user_access[]" value="res_man"/>Result Management
																<ul>
																	<li><input type="checkbox" name="user_access[]" value="marks"/> Marks</li>
																	<li><input type="checkbox" name="user_access[]" value="res_report"/> Reports</li>
																	<li><input type="checkbox" name="user_access[]" value="stu_entro"/> Entrolment </li>
																</ul>
															</li>
															<li>
																<input type="checkbox" name="user_access[]" value="ac_man"/>Account Management
																<ul>
																	<li><input  type="checkbox" name="user_access[]" value="nav_head_view"/> Account Head</li>
																	<li><input  type="checkbox" name="user_access[]" value="debit_vou"/> Debit Voucher</li>
																	<li><input  type="checkbox" name="user_access[]" value="credit_vou"/> Credit Voucher</li>
																</ul>
															</li>
															<li>
																<input type="checkbox" name="user_access[]" value="library"/> Library Management
																<ul>
																	<li><input type="checkbox" name="user_access[]" value="add_book"/> Add Book Category</li>
																	<li><input type="checkbox" name="user_access[]" value="book_list"/> List Of Books</li>
																	<li><input type="checkbox" name="user_access[]" value="book_issue"/> Issue Books</li>
																	<li><input type="checkbox" name="user_access[]" value="lib_fin"/> Library Fines</li>
																	<li><input type="checkbox" name="user_access[]" value="mov_log"/> Movement Logs</li>
																	<li><input type="checkbox" name="user_access[]" value="re_book"/> Returns Books</li>
																	<li><input type="checkbox" name="user_access[]" value="ser_book"/> Search Books</li>
																</ul>
															</li>
															<li><input  type="checkbox" name="user_access[]" value="routin"/> Routines</li>
														</ul>
													</div>
													<div class="col-sm-4">
														<ul class="tree nested">
															<li>
																<input type="checkbox" name="user_access[]" value="sett"/> Settings 
																<ul>
																	<li><input type="checkbox" name="user_access[]" value="gen_sett"/> General Settings</li>
																	<li><input type="checkbox" name="user_access[]" value="class"/> Class</li>
																	<li><input type="checkbox" name="user_access[]" value="sec"/> Section </li>
																	<li><input type="checkbox" name="user_access[]" value="group"/>Group</li>
																	<li><input type="checkbox" name="user_access[]" value="sess_set"/> Session Setup</li>
																	<li><input type="checkbox" name="user_access[]" value="shift_set"/> Shift Setup</li>
																	<li><input type="checkbox" name="user_access[]" value="subject"/> Subject Students Category</li>
																	<li>
																		<input type="checkbox" name="user_access[]" value="exam"/> Exam
																		<ul>
																			<li><input type="checkbox" name="user_access[]" value="exam_stt"/> Exam Setting</li>
																			<li><input type="checkbox" name="user_access[]" value="ad_card"/> Admit Cards</li>
																			<li>
																				<input type="checkbox" name="user_access[]" value="exam_set"/> Set Exam
																			</li>
																		</ul>
																	</li>
																	<li><input type="checkbox" name="user_access[]" value="fees"/> Fees </li>
																	<li>
																		<input type="checkbox" name="user_access[]" value="holi"/> Holidays
																	</li>
																	<li><input type="checkbox" name="user_access[]" value="aca_cal"/> Academic Calender</li>
																	<li>
																		<input type="checkbox" name="user_access[]" value="tea_staff"/> Teacher/Staff
																	</li>
																</ul>
															</li>
														</ul>
													</div>
												</div>
											</div>
											<div class="panel-footer"><button type="submit" class="btn btn-primary">Save</button></div>
										</div>
									</div><!-- daily section -->
								</div>
							</div><!-- row end -->
						</form>
					</div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>

<script>
window.onload = function () {
		// check parent li
		$('.tree li ul li').click(function(){
			$(this).parent('ul').siblings('input:checkbox').prop("checked",true);
		})
		// check all checkbox
		$("#checkAll").change(function () {
			$("input:checkbox").prop('checked', $(this).prop("checked"));
		});
		// check uncheck sub check box
		$('.nested input[type=checkbox]').click(function () {
			$(this).parent().find('li input[type=checkbox]').prop('checked', $(this).is(':checked'));
			var sibs = false;
			$(this).closest('ul').children('li').each(function () {
				if($('input[type=checkbox]', this).is(':checked')) sibs=true;
			})
			$(this).parents('ul').prev().prop('checked', sibs);
		});
	};
function old_user_access()
{
	var access=$('select[name="login_id"] option:selected').attr('id');
		access_arr=access.split(',');
		for(i=0; i<access_arr.length;i++)
		{
			$("input:checkbox[value="+access_arr[i]+"]").attr("checked", true);
		}
}	
</script>