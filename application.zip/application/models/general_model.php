<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class General_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    
    
    function get_message_by_school_id()
    {           
        $sql = "SELECT * FROM tbl_message";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }

    function virtual_pharma_get_product($member_id){
        $sql = "SELECT * FROM tbl_managing_committee where member_id = '$member_id'";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function total_student_count()
    {           
        $sql = "SELECT count(tsc.`student_class_id`) as ts,tbl_shift.shift_name,tbl_class.class_name,tbl_section.section_name,tbl_session.session_name FROM `tbl_student_class` tsc 
		join tbl_shift on tbl_shift.shift_id=tsc.shift_id
		join tbl_class on tbl_class.class_id=tsc.class_id
		join tbl_section on tbl_section.section_id=tsc.section_id
		join tbl_session on tbl_session.session_id=tsc.session_id
		group by tsc.shift_id,tsc.class_id,tsc.section_id,tsc.session_id
		order by tsc.session_id,tsc.shift_id,tsc.class_id,tsc.section_id ";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    function get_message_by_id($type)
     {           
        $sql = "SELECT * FROM tbl_message where type = '$type'";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    function get_all_slide_image()
    {           
        $sql = "SELECT * FROM tbl_slide_image order by slide_image_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    
    function get_about_by_school_id()
    {           
        $sql = "SELECT * FROM tbl_about limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    
    
    function get_photo_gallery()
    {           
        $sql = "SELECT * FROM tbl_photo_gallery order by photo_gallery_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    
    function get_all_class()
    {           
        $sql = "SELECT * FROM tbl_class order by class_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_class_assign_list()
    {           
        $sql = "SELECT * FROM tbl_class_assign group by class_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_teacher_list()
    {           
        $sql = "SELECT * FROM tbl_teacher_registration inner join tbl_department on tbl_teacher_registration.department_id = tbl_department.department_id where archive='0'order by tbl_teacher_registration.teacher_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_all_catagory_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_photo_catagory where school_id = $school_id order by catagory_id desc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_all_teacher_archive_list()
    {           
        $sql = "SELECT * FROM tbl_teacher inner join tbl_department on tbl_teacher.department = tbl_department.department_id where tbl_teacher.`archive`='1' order by tbl_teacher.id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_student_list_by_class_department_id($class_id, $department_id)
    {           
        $sql = "SELECT * FROM tbl_student inner join `tbl_student_class` on `tbl_student_class`.student_id =`tbl_student`.student_id WHERE tbl_student_class.class_id=$class_id and tbl_student_class.group_id = $department_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_department()
    {           
        $sql = "SELECT * FROM tbl_department order by department_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_session()
    {           
        $sql = "SELECT * FROM tbl_session order by session_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_exam()
    {           
        $sql = "SELECT * FROM tbl_exam order by exam_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_latest_notice($school_id)
    {           
        $sql = "SELECT * FROM tbl_notice where school_id=$school_id order by notice_id desc LIMIT 4";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_latest_notice_last()
    {           
        $sql = "SELECT * FROM tbl_notice order by notice_id desc limit 3,3";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_notice_info_by_id($notice_id)
    {           
        $sql = "SELECT * FROM tbl_notice where notice_id = $notice_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    function get_all_general_notice()
    {           
        $sql = "SELECT * FROM tbl_notice where notice_type = 1 order by notice_id desc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	  function get_all_form_data()
    {           
        $sql = "SELECT * FROM tbl_form order by notice_id desc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_admission_notice()
    {           
        $sql = "SELECT * FROM tbl_notice order by notice_id desc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
  
	/**Fetching data through ajax for result view**/
    function get_department_list_by_class_id($class_id)
    {           
        $sql = "SELECT * FROM tbl_class_assign where class_id =$class_id order by class_assign_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	
    function get_department_info_by_id($department_id)
    {           
        $sql = "SELECT * FROM tbl_department where department_id= $department_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
    function get_session_list_by_class_id($class_id)
    {           
        $sql = "SELECT * FROM tbl_session_assign where class_id =$class_id order by session_assign_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_session_info_by_id($session_id)
    {           
        $sql = "SELECT * FROM tbl_session where session_id= $session_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
    function get_exam_list_by_class_id($class_id)
    {           
        $sql = "SELECT * FROM tbl_exam_assign where class_id =$class_id order by exam_assign_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_exam_info_by_id($exam_id)
    {           
        $sql = "SELECT * FROM tbl_exam where exam_id= $exam_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    function get_result_info_by_student_id($class_id, $department_id, $session_id, $exam_id, $student_id)
    {           
        $sql = "SELECT * FROM tbl_result where class_id = $class_id AND department_id = $department_id AND session_id = $session_id AND exam_id= $exam_id AND student_id = $student_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    
    function get_result_type_by_class_id($class_id)
    {           
        $sql = "SELECT * FROM tbl_class where class_id= $class_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    function get_student_info_by_student_id($student_id)
    {           
        $sql = "SELECT * FROM tbl_student where student_id= $student_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
    function get_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id)
    {           
        $sql = "SELECT student_id, count(subject_id) as subject, sum(gpa) as gpa FROM tbl_result where class_id = $class_id AND department_id = $department_id AND session_id = $session_id AND exam_id = $exam_id AND student_id NOT IN (select student_id from tbl_result where gpa=0 and class_id = $class_id AND department_id = $department_id AND session_id = $session_id AND exam_id = $exam_id) group by student_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id)
    {           
        $sql = "SELECT * FROM tbl_result where class_id = $class_id AND department_id = $department_id AND session_id = $session_id AND exam_id = $exam_id and gpa<=0 group by student_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_degree_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id)
    {           
        $sql = "SELECT student_id, count(subject_id) as subject, sum(total_marks) as marks FROM tbl_result where class_id = $class_id AND department_id = $department_id AND session_id = $session_id AND exam_id = $exam_id AND student_id NOT IN (select student_id from tbl_result where total_marks<33 and class_id = $class_id AND department_id = $department_id AND session_id = $session_id AND exam_id = $exam_id) group by student_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_degree_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id)
    {           
        $sql = "SELECT * FROM tbl_result where class_id = $class_id AND department_id = $department_id AND session_id = $session_id AND exam_id = $exam_id and total_marks<33 group by student_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    
    /**Routine Portion**/
    function get_all_class_routine_list()
    {           
        $sql = "SELECT * FROM tbl_class_routine inner join tbl_class on tbl_class_routine.class_id = tbl_class.class_id inner join tbl_department on tbl_class_routine.department_id = tbl_department.department_id inner join tbl_session on tbl_class_routine.session_id = tbl_session.session_id order by tbl_class_routine.class_routine_id desc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_class_routine_by_id($class_routine_id)
    {           
        $sql = "SELECT * FROM tbl_class_routine inner join tbl_class on tbl_class_routine.class_id = tbl_class.class_id inner join tbl_department on tbl_class_routine.department_id = tbl_department.department_id inner join tbl_session on tbl_class_routine.session_id = tbl_session.session_id where tbl_class_routine.class_routine_id=$class_routine_id LIMIT 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    
    function get_central_routine()
    {           
        $sql = "SELECT * FROM tbl_central_routine WHERE school_id = 1 LIMIT 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    function get_all_exam_routine_list()
    {           
        $sql = "SELECT * FROM tbl_exam_routine inner join tbl_class on tbl_exam_routine.class_id = tbl_class.class_id inner join tbl_department on tbl_exam_routine.department_id = tbl_department.department_id inner join tbl_session on tbl_exam_routine.session_id = tbl_session.session_id inner join tbl_exam on tbl_exam_routine.exam_id = tbl_exam.exam_id order by tbl_exam_routine.exam_routine_id desc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_all_exam_routine_by_id($exam_routine_id)
    {           
        $sql = "SELECT * FROM tbl_exam_routine inner join tbl_class on tbl_exam_routine.class_id = tbl_class.class_id inner join tbl_department on tbl_exam_routine.department_id = tbl_department.department_id inner join tbl_session on tbl_exam_routine.session_id = tbl_session.session_id inner join tbl_exam on tbl_exam_routine.exam_id = tbl_exam.exam_id where tbl_exam_routine.exam_routine_id=$exam_routine_id LIMIT 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    
    function get_information_list_by_id($information_type)
    {           
        $sql = "SELECT * FROM tbl_important_information where information_type = $information_type limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    
    
    function get_all_department_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_department where school_id = $school_id order by department_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_teacher_list_by_department($school_id, $department_id)
    {           

        $sql = "SELECT * FROM tbl_teacher where school_id= $school_id AND department= $department_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    function get_department_name($department_id){
    $sql = "SELECT * FROM tbl_department where department_id= $department_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
    
    function get_photo_list_by_catagory($school_id, $catagory_id)
    {           

        $sql = "SELECT * FROM tbl_photo_gallery where school_id= $school_id AND catagory_id= $catagory_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_catagory_name($catagory_id){
    $sql = "SELECT * FROM tbl_photo_catagory where catagory_id= $catagory_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
	
	function get_all_book_list($school_id)
	{
		$sql = "SELECT * FROM tbl_book_library where school_id = $school_id order by book_id asc";
    	$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
	
	function get_book_category_name($category_id)
    {           
        $sql = "SELECT * FROM tbl_book_category where category_id = $category_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_all_book_category_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_book_category where school_id = $school_id order by category_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_book_list_by_category($school_id, $category_id)
    {           

        $sql = "SELECT * FROM tbl_book_library where school_id= $school_id AND category_id= $category_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
}
?>