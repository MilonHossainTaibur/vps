<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auth_model extends CI_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
	public function slelect_user()
	{
		$this->db->select('tbl_login.login_id,tbl_login.user_access,tbl_teacher_registration.teacher_name');
		$this->db->from('tbl_teacher_registration');
		$this->db->join('tbl_login', 'tbl_teacher_registration.teacher_id=tbl_login.admin_id');
		$this->db->where('tbl_login.user_type !=',1);
		$this->db->order_by('tbl_teacher_registration.teacher_name', "ASC");
		
		$query = $this->db->get();
		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row)
			{
				$data[] = $row;
			}

			return $data;
		}
		else
		{
			return FALSE;
		}
    }
}
?>