<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Academic_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

public function get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id)
    {           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id 
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.shift_id = $shift_id 
				order by tbl_student_class.roll_no asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
function get_group_list_by_id($class_id, $school_id)
	{
		$sql = "SELECT cg.group_id, g.group_name FROM `tbl_class_group` as cg INNER JOIN `tbl_group` as g on cg.group_id=g.group_id WHERE cg.school_id=$school_id AND cg.class_id=$class_id order by g.group_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res; 
	}
function get_sub_list_by_id($class_id, $school_id,$group_id)
    {  
        $sql = "SELECT * FROM `tbl_class_subject` as cs INNER JOIN `tbl_subject` as s ON cs.subject_id = s.subject_id WHERE cs.school_id=$school_id AND cs.class_id=$class_id AND cs.group_id=$group_id order by s.subject_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
function get_sub_list_by_id_ct($class_id, $school_id,$group_id)
    {  
        $sql = "SELECT distinct(md.subject_id ) as `subject_id`, s.subject_name as `subject_name` FROM `tbl_class_subject` as cs INNER JOIN `tbl_subject` as s ON cs.subject_id = s.subject_id INNER JOIN `tbl_mark_distribution` as md ON cs.subject_id = md.subject_id WHERE cs.school_id=$school_id AND md.class_id=$class_id AND md.group_id=$group_id AND md.exam_type=4 order by s.subject_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }

function get_class_wise_student_list_project_marks($school_id, $class_id,$section_id,$ct_id)
    {           
        $sql = "SELECT * FROM tbl_project_marks inner join tbl_student_class on tbl_project_marks.student_id = tbl_student_class.student_id inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id where tbl_project_marks.school_id = $school_id and tbl_student_class.class_id = $class_id and tbl_student_class.section_id = $section_id order by tbl_project_marks.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }

    	/********** / project ************/
		
		/********** ct ****************/
		    
   
	function get_class_wise_student_list_ct($school_id, $class_id,$section_id)
    {           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
		
	function delete_ct_marks_info($school_id,$class_id,$section_id,$group_id,$shift_id,$term_id,$exam_year,$subject_id)
	{
		$sql = "DELETE FROM `tbl_ct_marks` WHERE `school_id` = '$school_id' AND `class_id` = '$class_id' AND `section_id` = '$section_id' AND `group_id` = '$group_id' AND `shift_id` = '$shift_id' AND `term_id` = '$term_id' AND `exam_year` = '$exam_year' AND `subject_id` = '$subject_id'";
        $this->db->query($sql);
        return true;
	}

		/********** / ct ****************/

		
	
		/********** term ****************/
		
		function get_term_list($school_id){
      $sql = "SELECT * FROM `tbl_term` ORDER BY term_id asc";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;
	}
function get_term_list_by_id($id,$school_id){
      $sql = "SELECT * FROM `tbl_term` WHERE `term_id` = $id";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;


	}

		function delete_term_marks( $school_id,$class_id,$section_id,$group_id,$term_id,$sub_id,$exam_year,$shift_id)
    {           
        $sql = "delete FROM tbl_term_marks WHERE school_id = $school_id and class_id='$class_id' and section_id='$section_id' and group_id='$group_id' and shift_id='$shift_id' and term_id='$term_id' and sub_id='$sub_id' and exam_year='$exam_year'";
        $query = $this->db->query($sql);
        return true;
    }
	
	function get_class_wise_student_list_term_marks($school_id, $class_id,$section_id,$term_id)
    {           
        $sql = "SELECT * FROM tbl_term_marks inner join tbl_student_class on tbl_term_marks.student_id = tbl_student_class.student_id inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id where tbl_term_marks.school_id = $school_id and tbl_student_class.class_id = $class_id and tbl_student_class.section_id = $section_id order by tbl_term_marks.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	 function get_term_info_by_id($school_id, $term_id)
    {           
        $sql = "SELECT * FROM tbl_term WHERE school_id = $school_id and term_id = $term_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }

	/********** /term ****************/	
	
	 /**** /Class Routine model (sharif) ****/
	 
	  function get_class_wise_subject_list($class_id, $school_id)
    {            
        $sql = "select distinct(a.subject_id) as `subject_id`, b.subject_name as `subject_name` from tbl_class_subject as a inner join tbl_subject as b on a.subject_id=b.subject_id WHERE a.school_id=$school_id AND a.class_id=$class_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
   
	
    function get_class_time($school_id)
    {           
        $sql = "SELECT * FROM tbl_class_time_input where school_id = $school_id order by row_no asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	 function get_class_time_count($school_id)
    {           
        $sql = "SELECT * from tbl_class_time_input where school_id = $school_id";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	function get_weekdays($school_id)
    {           
        $sql = "SELECT * FROM tbl_weekdays where school_id = $school_id and status!=0 order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_class_wise_teacher_list_routine($school_id, $class_id, $section_id)
    {           
        $this->db->select('tbl_class_teacher_assign.* , tbl_teacher_registration.teacher_id, tbl_teacher_registration.teacher_name');
		$this->db->from('tbl_class_teacher_assign');
		$this->db->join('tbl_teacher_registration', 'tbl_class_teacher_assign.teacher_id = tbl_teacher_registration.teacher_id');
		$this->db->where('tbl_class_teacher_assign.school_id', $school_id);
		$this->db->where('tbl_class_teacher_assign.class_id', $class_id);
		$this->db->where('tbl_class_teacher_assign.section_id', $section_id); 
		
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;   
    }
	
    function get_class_routine_info_by_id($school_id, $class_id)
    {           
        $sql = "SELECT * FROM tbl_class where school_id = $school_id and class_id = $class_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	function delete_class_wise_routine($school_id,$class_id,$section_id)
    {      
		if($this->db->delete('tbl_class_routine', array('school_id' => $school_id ,'class_id' => $class_id,'section_id'=>$section_id)))
			{
				return TRUE;
			}
		else
			{
				return FALSE;
			}    
    }
	function save_class_routine($data)
    {           
        if($this->db->insert('tbl_class_routine', $data))
        	{
				return TRUE;
			}
		else
			{
				return FALSE;
			}   
    }
	
	function get_id_per_class_section($class_id, $school_id,$section_id,$group_id,$shift_id)
    {            
        $sql = "select distinct id from tbl_class_routine WHERE school_id=$school_id AND class_id=$class_id AND section_id=$section_id AND group_id=$group_id AND shift_id=$shift_id order by column_no, row_no";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	function get_old_routine_by_section_class($class_id, $school_id,$section_id,$group_id,$shift_id)
	{
		$sql="select GROUP_CONCAT(teacher_id) as teacher_id, GROUP_CONCAT(subject_id) as subject_id, GROUP_CONCAT(column_no) as column_no, GROUP_CONCAT(row_no) as row_no, day from tbl_class_routine WHERE school_id=$school_id AND class_id=$class_id AND section_id=$section_id AND group_id=$group_id AND shift_id=$shift_id GROUP by column_no, row_no order by column_no, row_no";
		
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	
	function get_old_routine_by_section_class_show($class_id, $school_id,$section_id,$group_id,$shift_id)
	{
		$sql="SELECT GROUP_CONCAT(tbl_class_routine.column_no) as column_no,
		GROUP_CONCAT(tbl_class_routine.row_no) as row_no,
		GROUP_CONCAT(tbl_class_routine.teacher_id) as teacher_id,
        GROUP_CONCAT(tbl_class_routine.subject_id) as subject_id,
        GROUP_CONCAT(tbl_subject.subject_name) as subject_name,
        GROUP_CONCAT(tbl_teacher_registration.teacher_name) as teacher_name,
        tbl_class_routine.day FROM `tbl_class_routine` 
        inner join tbl_subject on tbl_class_routine.subject_id = tbl_subject.subject_id
        inner join tbl_teacher_registration on tbl_class_routine.teacher_id = tbl_teacher_registration.teacher_id 
		WHERE tbl_class_routine.school_id=$school_id AND tbl_class_routine.class_id=$class_id AND tbl_class_routine.section_id=$section_id AND tbl_class_routine.group_id=$group_id AND tbl_class_routine.shift_id=$shift_id
		GROUP BY tbl_class_routine.column_no, tbl_class_routine.row_no
		order by tbl_class_routine.column_no, tbl_class_routine.row_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	
	
	function get_old_routine_by_section_class_download($school_id, $class_id, $section_id)
	{
		$sql="SELECT tbl_class_routine.row_no, tbl_class_routine.class_period, tbl_class_routine.column_no, tbl_teacher_registration.teacher_name, tbl_subject.subject_name FROM `tbl_class_routine` inner join tbl_subject on tbl_class_routine.subject_id = tbl_subject.subject_id inner join tbl_teacher_registration on tbl_class_routine.teacher_id = tbl_teacher_registration.teacher_id WHERE tbl_class_routine.school_id=$school_id AND tbl_class_routine.class_id=$class_id AND tbl_class_routine.section_id=$section_id order by tbl_class_routine.row_no , tbl_class_routine.column_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
    /*******************  /Class Routine  ******************/
	
		/******************* exam routine ******************/
	function exam_get_class_count($school_id)
    {           
        $sql = "SELECT * from tbl_class where school_id = $school_id";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	
	function exam_get_subject_count($school_id)
    {           
        $sql = "SELECT * from tbl_subject where school_id = $school_id";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	

	function get_old_exam_routine_by_term($class_id,$exam_term_id)
	{
		$sql="select * from tbl_exam_routine where class_id=$class_id and exam_term_id=$exam_term_id";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	
	 function exam_show_get_class_count($school_id,$exam_term_id)
    {           
        $sql = "SELECT distinct column_no from tbl_exam_routine where school_id = $school_id AND exam_term_id = $exam_term_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function exam_show_get_day_count($school_id,$exam_term_id)
    {           
        $sql = "SELECT distinct row_no from tbl_exam_routine where school_id = $school_id AND exam_term_id = $exam_term_id order by row_no";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	
	function get_old_exam_routine_by_term_show($class_id,$exam_term_id)
	{
		$sql="SELECT * FROM `tbl_exam_routine` inner join tbl_subject on tbl_exam_routine.exam_subject_id = tbl_subject.subject_id where class_id=$class_id and exam_term_id=$exam_term_id";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	
	function get_old_exam_routine_by_term_download($school_id,$term_id)
	{
		$sql="SELECT * FROM `tbl_exam_routine` inner join tbl_subject on tbl_exam_routine.exam_subject_id = tbl_subject.subject_id inner join tbl_class on tbl_exam_routine.class_id = tbl_class.class_id WHERE tbl_exam_routine.school_id=$school_id AND tbl_exam_routine.exam_term_id=$term_id order by tbl_exam_routine.row_no, tbl_exam_routine.column_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	
	function get_old_exam_routine_by_term_download_class($school_id,$term_id)
	{
		$sql="SELECT distinct tbl_exam_routine.column_no, tbl_exam_routine.exam_time , tbl_exam_routine.class_id, tbl_class.class_name  FROM `tbl_exam_routine` inner join tbl_class on tbl_exam_routine.class_id = tbl_class.class_id WHERE tbl_exam_routine.school_id=$school_id AND tbl_exam_routine.exam_term_id=$term_id order by tbl_exam_routine.column_no, tbl_exam_routine.row_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	function get_old_exam_routine_by_term_download_day_date($school_id,$term_id)
	{
		$sql="SELECT distinct tbl_exam_routine.row_no, tbl_exam_routine.exam_day , tbl_exam_routine.exam_date FROM `tbl_exam_routine` WHERE tbl_exam_routine.school_id=$school_id AND tbl_exam_routine.exam_term_id=$term_id order by tbl_exam_routine.column_no, tbl_exam_routine.row_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	/********************* / exam routine ************************/

	
	/****************** result *******************/
	
	function get_class_wise_student_info_marksheet($school_id, $class_id,$section_id,$student_id,$shift_id,$group_id)
	{           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id  
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.shift_id = $shift_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.student_id = $student_id 
				order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	function get_merk_distribution($school_id,$class_id,$group_id)
    {           
       $sql = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = '$school_id' and A.class_id = '$class_id' and A.group_id='$group_id' and A.exam_type!=0 order by A.exam_type";
        $query = $this->db->query($sql);
         $row= $query->result_array();
        return $row;
    }
	
	function delete_tabulation_marks($school_id,$class_id,$section_id,$group_id,$term_id,$exam_year,$shift_id)
    {
		if($this->db->delete('tbl_tabulation_marks', array('school_id' => $school_id,'class_id' => $class_id, 'section_id' => $section_id, 'group_id' => $group_id,'shift_id' => $shift_id, 'term_id' => $term_id, 'exam_year'=>$exam_year)))
			{
				return TRUE;
			}
		else
			{
				return FALSE;
			}             
      
    }
	
	/****************** / result *******************/
	

	
	function subject_wise_total_marks_class_wise($school_id,$sub_id,$class_id)
	{
		$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A WHERE A.school_id = '$school_id' and A.subject_id= '$sub_id' and A.class_id= '$class_id' limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
	}
	/*function subject_wise_total_marks_class_wise_result($school_id,$class_id)
	{
		$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A WHERE A.school_id = '$school_id' and A.class_id= '$class_id' order by subject_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}*/
	/****************** / subject wise marks *******************/
	
	/****************** term subject *******************/
	
	function get_term_subject_list($school_id)
    {           
        $sql = "SELECT * FROM `tbl_term_subject` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_group ON A.group_id= tbl_group.group_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.subject_id INNER JOIN tbl_term ON tbl_term.term_id = A.term_id WHERE A.school_id = $school_id ORDER BY A.class_id ASC, tbl_subject.subject_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	 function get_term_subject_info_by_id($school_id, $ts_id)
    {           
        $sql = "SELECT * FROM `tbl_term_subject` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_group ON A.group_id = tbl_group.group_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.subject_id INNER JOIN tbl_term ON tbl_term.term_id = A.term_id WHERE A.school_id = $school_id  and A.id = $ts_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	/****************** / term subject *******************/
	
	function get_mark_dis_info($school_id, $class_id,$group_id)
    {           
        $sql = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = $school_id and A.class_id = $class_id and A.group_id = $group_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
		function get_mark_dis_info_subject_wise($school_id, $class_id,$group_id,$subject_id)
    {           
        $sql = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = $school_id and A.class_id = $class_id and A.group_id = $group_id and A.subject_id = $subject_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }

	
	function get_shift_list($school_id){
      $sql = "SELECT * FROM `tbl_shift` ORDER BY shift_id asc";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;
	}
	
	

	 function get_group_info_by_id($school_id, $group_id)
    {           
        $sql = "SELECT * FROM tbl_group where school_id = $school_id and group_id = $group_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	
	
	function get_ct_mark_status($school_id,$class_id,$section_id,$group_id,$shift_id,$term_id,$exam_year,$subject_id)
	{
		$sql = "SELECT status as status FROM tbl_ct_marks where WHERE `school_id` = '$school_id' AND `class_id` = '$class_id' AND `section_id` = '$section_id' AND `group_id` = '$group_id' AND `shift_id` = '$shift_id' AND `term_id` = '$term_id' AND `exam_year` = '$exam_year' AND `subject_id` = '$subject_id' limit 1";
	    $query = $this->db->query($sql);
        $row= $query->row_array();
	    return $row;
	}
	
	
}