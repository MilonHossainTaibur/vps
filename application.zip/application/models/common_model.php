<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_model extends CI_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function common_insert($data,$table_name)
    {
        $this->db->insert($table_name, $data);
        return $this->db->insert_id();
    }
	function common_insert_batch($data,$table_name)
    {
        $this->db->insert_batch($table_name, $data);
        return $this->db->insert_id();
    }
   function common_delete($data,$table_name)
    {
        $this->db->delete($table_name, $data);
		$return = $this->db->affected_rows();

		return $return; 
    }
    
   /*
    function condition_delete($data,$condition_id_value,$condition_id,$table_name)
    {
        $this->db->where($condition_id, $condition_id_value);
        $this->db->delete($table_name, $data);
		$return = $this->db->affected_rows();

		return $return;
    }
    
	
    function delete_condition($tableName,$tableId,$value)
    {
        //delete employee record
        $this->db->where("$tableId", $value);
        $this->db->delete("$tableName");
		$return = $this->db->affected_rows();

		return $return;
    }
*/
    
    function common_update($data,$condition_id_value,$condition_id,$table_name)
    {
        $this->db->where($condition_id, $condition_id_value);
        $this->db->update($table_name, $data);
		$return = $this->db->affected_rows();
		return $return;
    }
	
	/*
		*Generates an update string based on the data you supply, and runs the query. You can either pass an array or an object to the function.
	*/
	function common_batch_update($table_name,$data,$condition_id)
    {
        $this->db->trans_start();
		$this->db->update_batch($table_name, $data, $condition_id);
		$this->db->trans_complete();        
    	return ($this->db->trans_status() === FALSE)? FALSE:TRUE;
    }
	
	function common_update_bulk($data,$condition_id_value,$condition_id,$table_name)
    {
        $this->db->where_in($condition_id, $condition_id_value);
        $this->db->update($table_name, $data);
		$return = $this->db->affected_rows();
		return $return;
    }
	
    function common_row_array($table_name)
    {
        $sql="SELECT * FROM $table_name WHERE status = 1";
        $query = $this->db->query($sql);
        $result = $query->row_array();
        return $result;   
    }
    function common_result_array($table_name)
    {
        $sql="SELECT * FROM $table_name";
        $query = $this->db->query($sql);
        $result = $query->result_array();
        return $result;   
    }
    function common_row_by_condition($condition_id_value,$condition_id,$table_name)
    {
        $sql="SELECT * FROM $table_name WHERE $condition_id = $condition_id_value";
        $query = $this->db->query($sql);
        $result = $query->row_array();
        return $result;   
    }
	function common_select_by_condition($condition_id_value,$condition_id,$table_name)
    {
		$this->db->where($condition_id, $condition_id_value);
		$this->db->from($table_name);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;   
    }
	function common_select_by_multycondition($data,$table_name)
    {
		$this->db->from($table_name);
        $this->db->where($data);
		//$this->db->order_by($order_field, $order_condition);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;   
    }
	
	public function common_select_field($table,$order_field,$sort,$select_field)
	{
		$this->db->select($select_field);
		$this->db->order_by($order_field,$sort);
		$query = $this->db->get($table);
		if($query->num_rows() > 0)
			{
				foreach($query->result() as $row)
				{
					$data[] = $row;
				}
				return $data;
			}
			else
			{
				return 0;
			}
    }
}
?>