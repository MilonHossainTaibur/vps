<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends CI_Controller {

    public function __construct()
        {            
            session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
            $this->load->library('form_validation');
            if(!is_loggedin())
            {
                redirect('login');
                exit;
            }
        }
        public function index()
        {
			//$n_data['school_id']=1;
			//$data['notices'] = $this->Common_model->common_select_by_multycondition($n_data,'tbl_notice');
            //$data['holiday'] = $this->Admin_model->get_class_list('1');
			$this->load->view('admin/index',$data);
        }
        
        /* Digital Attendance */
         public function attendance(){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $this->load->view('admin/attendance');
        }
        /* /Digital Attendance */
        
        
       /**Teacher Management Portion**/ 
        
        public function teacher_registration(){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['department_list'] = $this->Admin_model->get_department_list($school_id);
            $data['designation_list'] = $this->Admin_model->get_designation_list($school_id);
            $this->load->view('admin/teacher_registration', $data);
        }
		
		function teacher_image_upload($file_data,$teacher_id){
			
			$config['upload_path']   =   "upload/teacher_image";
            $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
            #$config['encrypt_name']  = true;
            $config['max_size']      =   "720";
            $config['max_width']     =   "1500";
            $config['max_height']    =   "1500";
			$config['overwrite']     =   true;				
            $config['file_name']    =   $teacher_id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('teacher_image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
					   $data['teacher_image']=$spinfo['file_name'];
					   $this->Common_model->common_update($data, $teacher_id,'teacher_id','tbl_teacher_registration');
                    }
					unset($config);
			
		}
		function teacher_certificate_upload($file_data,$teacher_id){
			
			$config['upload_path']   =   "upload/teacher_certificate";
            $config['allowed_types'] =   "*"; 
            #$config['encrypt_name']  = true;
            $config['max_size']      =   "7020";
			$config['overwrite']     =   true;				
            $config['file_name']    =   $teacher_id."_certificate";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('teacher_certificate')){
                    echo $this->upload->display_errors();
                }
                else{
                    $spinfo=$this->upload->data();
					$data['teacher_certificate']=$spinfo['file_name'];
					$this->Common_model->common_update($data, $teacher_id,'teacher_id','tbl_teacher_registration');
                }
			unset($config);
		}
        function teacher_registration_save(){
            if(isPostBack()){
                #$data['school_id'] = $_SESSION['school_id'];
                $data['school_id'] = 1;
                $data['status'] = 1;
                $data['created_on'] = date('Y-m-d H:i:s',time());
                $data['teacher_name'] = $_POST['teacher_name'];
                $data['teacher_name_bn'] = $_POST['teacher_name_bn'];
                $data['father_name'] = $_POST['father_name'];
                $data['mother_name'] = $_POST['mother_name'];
                $data['spouse_name'] = $_POST['spouse_name'];
                $data['birth_date'] = $_POST['birth_date'];
                $data['gender'] = $_POST['gender'];
                $data['religion'] = $_POST['religion'];
                $data['marital_status'] = $_POST['marital_status'];
                $data['permanent_address'] = $_POST['permanent_address'];
                $data['permanent_district'] = $_POST['permanent_district'];
                $data['permanent_thana'] = $_POST['permanent_thana'];
                #$data['permanent_contact'] = $_POST['permanent_contact'];
                $data['present_address'] = $_POST['present_address'];
                $data['present_district'] = $_POST['present_district'];
                $data['present_thana'] = $_POST['present_thana'];
                $data['account_number'] = $_POST['account_number'];
		$data['bank_name'] = $_POST['bank_name'];
		$data['branch_name'] = $_POST['branch_name'];
                $data['blood_group'] = $_POST['blood_group'];
                $data['nationality'] = $_POST['nationality'];
                $data['national_id_card_no'] = $_POST['national_id_card_no'];
                $data['email'] = $_POST['email'];
                $data['present_contact'] = $_POST['present_contact'];
                $data['department_id'] = $_POST['department_id'];
                $data['designation_id'] = $_POST['designation_id'];
                $data['joining_date'] = $_POST['joining_date'];
                $data['mpo_date'] = $_POST['mpo_date'];
                $data['index_no'] = $_POST['index_no'];
                $data['teacher_image'] = '';
                $data['teacher_certificate'] = '';
                $insert=$this->Common_model->common_insert($data,'tbl_teacher_registration');
                if($insert)
				{
					//data save for teacher auth
					if($_POST['user_name'] && $_POST['password'])
					{
						$datau['school_id'] = 1;
						$datau['admin_id'] = $insert;
						$datau['user_name'] = $_POST['user_name'];
						$datau['password'] = md5($_POST['password']);
						$datau['user_type'] = 2;
						$datau['status'] = 1;
						$datau['created_on'] = date('Y-m-d H:i:s',time());
						$this->Common_model->common_insert($datau,'tbl_login');
					}
					// teacher certificate
					$teacher_image=$_FILES['teacher_image']['name'];
					if($teacher_image){
						$this->teacher_image_upload($_FILES['teacher_image'],$insert);
					}
					// teacher certificate
					$teacher_certificate=$_FILES['teacher_certificate']['name'];
					if($teacher_certificate){
						$this->teacher_certificate_upload($_FILES['teacher_certificate'],$insert);
					}
					// data for teacher education
					for($i=0; $i < count($_POST['degree']); $i++)
					{
						$data_edu[] = array(
										'school_id' => 1,
										'teacher_id' => $insert,
										'degree' => $_POST['degree'][$i],
										'institute' => $_POST['institute'][$i],
										'result' => $_POST['result'][$i],
										'passing_year' => $_POST['passing_year'][$i]
										);
					}
					
					if($this->Common_model->common_insert_batch($data_edu,'tbl_teacher_education'))
						{
							$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
						}
					else
						{
							$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
						}
					
				}
				else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');}
				
                redirect('admin/teacher_list');exit;                
            }
        }
        public function teacher_list(){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['teacher_list'] = $this->Admin_model->get_teacher_list_list($school_id);
	    $data['appoint_list'] = $this->Admin_model->get_teacher_dept_short_name($school_id);
      
            $this->load->view('admin/teacher_list', $data);
        }
        
        public function teacher_view($teacher_id){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;           
            $data['teacher_info'] = $this->Admin_model->get_teacher_info($school_id, $teacher_id);
            $data['department_list'] = $this->Admin_model->get_department_list($school_id);
            $data['designation_list'] = $this->Admin_model->get_designation_list($school_id);
            $this->load->view('admin/teacher_view', $data);
        }
        
        public function teacher_edit($teacher_id){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;           
			$condition['school_id']=$school_id;
			$condition['teacher_id']=$teacher_id;
			$data['teacher_info'] = $this->Admin_model->get_teacher_info($school_id, $teacher_id);
			$data['teacher_edu'] = $this->Common_model->common_select_by_multycondition($condition,'tbl_teacher_education');
            $data['department_list'] = $this->Admin_model->get_department_list($school_id);
            $data['designation_list'] = $this->Admin_model->get_designation_list($school_id);
            $this->load->view('admin/teacher_edit', $data);
        }
        
        function teacher_edit_save(){
            if(isPostBack()){
                #$school_id = $_SESSION['school_id'];
                $school_id = 1;
                $teacher_id = $_POST['teacher_id'];
                $data['teacher_name'] = $_POST['teacher_name'];
                $data['teacher_name_bn'] = $_POST['teacher_name_bn'];
                $data['father_name'] = $_POST['father_name'];
                $data['mother_name'] = $_POST['mother_name'];
                $data['spouse_name'] = $_POST['spouse_name'];
                $data['birth_date'] = $_POST['birth_date'];
                $data['gender'] = $_POST['gender'];
                $data['religion'] = $_POST['religion'];
                $data['marital_status'] = $_POST['marital_status'];
                $data['permanent_address'] = $_POST['permanent_address'];
                $data['permanent_district'] = $_POST['permanent_district'];
                $data['permanent_thana'] = $_POST['permanent_thana'];
                #$data['permanent_contact'] = $_POST['permanent_contact'];
                $data['present_address'] = $_POST['present_address'];
                $data['present_district'] = $_POST['present_district'];
                $data['present_thana'] = $_POST['present_thana'];
                $data['account_number'] = $_POST['account_number'];
		$data['bank_name'] = $_POST['bank_name'];
		$data['branch_name'] = $_POST['branch_name'];
                $data['blood_group'] = $_POST['blood_group'];
                $data['nationality'] = $_POST['nationality'];
                $data['national_id_card_no'] = $_POST['national_id_card_no'];
                $data['email'] = $_POST['email'];
                $data['present_contact'] = $_POST['present_contact'];
                $data['department_id'] = $_POST['department_id'];
                $data['designation_id'] = $_POST['designation_id'];
                $data['joining_date'] = $_POST['joining_date'];
                $data['mpo_date'] = $_POST['mpo_date'];
                $data['index_no'] = $_POST['index_no'];
				
                $this->Common_model->common_update($data, $teacher_id,'teacher_id','tbl_teacher_registration');
				// teacher certificate
					$teacher_image=$_FILES['teacher_image']['name'];
					if($teacher_image){
						$this->teacher_image_upload($_FILES['teacher_image'],$teacher_id);
					}
					// teacher certificate
					$teacher_certificate=$_FILES['teacher_certificate']['name'];
					if($teacher_certificate){
						$this->teacher_certificate_upload($_FILES['teacher_certificate'],$teacher_id);
					}
					for($i=0; $i < count($_POST['degree']); $i++)
					{
						$data_edu[] = array(
										'school_id' => 1,
										'teacher_id' => $teacher_id,
										'degree' => $_POST['degree'][$i],
										'institute' => $_POST['institute'][$i],
										'result' => $_POST['result'][$i],
										'passing_year' => $_POST['passing_year'][$i]
										);
					}
					$d_data['school_id']=1;
					$d_data['teacher_id']=$teacher_id;
					$this->Common_model->common_delete($d_data,'tbl_teacher_education');
					if($this->Common_model->common_insert_batch($data_edu,'tbl_teacher_education'))
						{
							$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
						}
					else
						{
							$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved1. Please try again.</div>');
						}
				
                redirect('admin/teacher_list');exit;
            }
        }
        
    function teacher_delete($teacher_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $this->Admin_model->delete_teacher_by_id($teacher_id, $school_id);
		$this->session->set_flashdata('message', " Teacher's data has been Deleted successfully "); 
        redirect('admin/teacher_list');exit;
    }
        
    public function teacher_appointment(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['teacher_list'] = $this->Admin_model->get_teacher_list($school_id);
        $data['appoint_list'] = $this->Admin_model->get_appoint_list($school_id);
        $this->load->view('admin/teacher_appointment', $data);
    }
    
    function teacher_appointment_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['school_id'] = $school_id;
            $data['teacher_id'] = $_POST['teacher_id'];
            $data['salary'] = $_POST['salary'];
            $data['status'] = 1; 
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_appointment');
			$this->session->set_flashdata('message', " Teacher's appointment has been saved successfully "); 
            redirect('admin/teacher_appointment');exit;         
        }
    }
    
    public function appointment_view($appointment_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['appoint_list'] = $this->Admin_model->get_appoint_list_by_id($school_id, $appointment_id);
        $this->load->view('admin/appointment_view', $data);
    }
    /***Teacher salary category***/
    
    public function salary_cat(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['salary_cat'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_salary_cat');
        $this->load->view('admin/salary_cat', $data);
    }
    
    function salary_cat_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['school_id'] = $school_id;
            $data['salary_particulars'] = $_POST['salary_particulars'];
            $data['effect'] = $_POST['effect'];
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            if($this->Common_model->common_insert($data,'tbl_salary_cat'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
            redirect('admin/salary_cat');exit;
            
        }
    }
    
    
	public function salary_cat_edit($id){
		$data['salary_cat'] = $this->Common_model->common_row_by_condition($id,'id','tbl_salary_cat');
        $this->load->view('admin/salary_cat_edit', $data);
    }
    
    public function salary_cat_edit_save(){
        if(isPostBack()){
            $id = $_POST['id'];
            $data['salary_particulars'] = $_POST['salary_particulars'];
            $data['effect'] = $_POST['effect'];
            if($this->Common_model->common_update($data, $id,'id','tbl_salary_cat'))     
            {
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
            redirect('admin/salary_cat');exit;              
        }
    }
    
	function salary_cat_delete($id){
			$d_data['id'] = $id;
			if($this->Common_model->common_delete($d_data,'tbl_salary_cat'))
            {
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
			}
            redirect('admin/salary_cat');exit;
    }
	
	
    /*** /Teacher salary category***/
	
	public function teacher_salary_structure(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['teacher_list'] = $this->Admin_model->get_teacher_list($school_id);
		$data['salary_cat'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_salary_cat');
        $data['salary_list'] = $this->Admin_model->get_teacher_salary_stucture_list($school_id);
        $this->load->view('admin/teacher_salary_structure', $data);
    }
    
    public function teacher_salary_structure_save(){
		 if(isPostBack()){
           $school_id = 1; 
            for ($u = 0; $u < count($_POST['salary_particulars']); $u++) {
                $data[] = array(
                    'school_id' => $school_id,
                    'teacher_id' => $_POST['teacher_id'],
                    'salary_particulars' => $_POST['salary_particulars'][$u],
                    'effect' => $_POST['effect'][$u],
                    'amount' => $_POST['amount'][$u],
                    'status' => 1,
                    'created_on' => date('Y-m-d H:i:s',time())
                );
            }
            if($this->Common_model->common_insert_batch($data,'tbl_teacher_salary')){
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
            else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
			}
            redirect('admin/teacher_salary_structure','refresh');
            
        }
    }

 public function salary_structure_view($teacher_id){
		$school_id = 1; 
		$data['teacher_list'] = $this->Admin_model->get_teacher_salary_stucture_list($school_id);
		$data['teacher_details']=array('teacher_id'=>$teacher_id);
        $data['salary_list']=$this->Admin_model->get_teacher_salary_stucture_by_id($teacher_id);
        $this->load->view('admin/salary_structure_view', $data);
    }
    
    public function salary_structure_edit($teacher_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1; 
		$data['teacher_id']=$teacher_id;
        $data['teacher_list'] = $this->Admin_model->get_teacher_list($school_id);
        $data['salary_list'] = $this->Admin_model->get_teacher_salary_stucture_by_id($teacher_id);
        $this->load->view('admin/salary_structure_edit', $data);
    }
    
    function salary_structure_edit_save(){
       if(isPostBack()){
           $school_id = 1; 
            for ($u = 0; $u < count($_POST['salary_particulars']); $u++) {
                $data[] = array(
                    'teacher_salary_id' => $_POST['teacher_salary_id'][$u],
                    'school_id' => $school_id,
                    'teacher_id' => $_POST['teacher_id'],
                    'salary_particulars' => $_POST['salary_particulars'][$u],
                    'effect' => $_POST['effect'][$u],
                    'amount' => $_POST['amount'][$u],
                    'status' => 1,
                    'created_on' => date('Y-m-d H:i:s',time())
                );
            }
            if($this->Common_model->common_batch_update('tbl_teacher_salary',$data,'teacher_salary_id')){
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
            else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
			}
            redirect('admin/teacher_salary_structure','refresh');
        }
    }
    
    function salary_structure_delete($teacher_id){
		$d_data['teacher_id'] = $teacher_id;
		if($this->Common_model->common_delete($d_data,'tbl_teacher_salary')){
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
		}
		else{
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
		}
    redirect('admin/teacher_salary_structure');exit;
    }
    
    
        
       /**Student Management Portion**/ 
    public function student_registration(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['session_list'] = $this->Admin_model->get_session_list($school_id);
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['fees_list'] = $this->Common_model->common_result_array('tbl_fees_category');
		$data['division_list'] = $this->Common_model->common_result_array('tbl_divisions');
        $this->load->view('admin/student_registration', $data);
    }
    
	/*
	 public function bkash(){
    $xml = simplexml_load_file('http://www.bkashcluster.com:9080/dreamwave/merchant/trxcheck/sendmsg?user=BID71&pass=B13Id71247&msisdn=01682335577&trxid=9807678');
//$status = $xml->data->trxid;
$status = $xml->data->status;
echo $status;
if($status == 'SUCCESS'){
    echo "success";
}
else{
    echo "failed";
}
    }*/
	
	function subject_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Admin_model->get_sub_list_by_id($class_id, $school_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
    function section_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['section_id']."'>".$sInfo['section_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	function district_list_ajax()
    {
        $div_id = $_POST['div_id'];
        $distInfo = $this->Common_model->common_select_by_condition($div_id,'division_id','tbl_districts'); 
        $str = '<option value="">----Select District----</option>';
        if($distInfo)
        {
           foreach($distInfo as $disInfo)
           {
              $str .= "<option value='".$disInfo['id']."'>".$disInfo['d_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	function upazila_list_ajax()
    {
        $dis_id = $_POST['dis_id'];
        $upInfo = $this->Common_model->common_select_by_condition($dis_id,'district_id','tbl_upazilas');
        $str = '<option value="">----Select Section----</option>';
        if($upInfo)
        {
           foreach($upInfo as $uInfo)
           {
              $str .= "<option value='".$uInfo['id']."'>".$uInfo['u_name']."</option>";
           }
        }
        echo $str;exit;
    }
    
    
    function student_registration_save(){
    
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            
            $year = date('y');
            $class_id = $_POST['class_id'];
           
            
            $latest = $this->Admin_model->get_latest_id_number($school_id);
            $latest_id = $latest['id']+1;
            $id = strlen($latest_id);
            
            $class_short = $this->Admin_model->get_class_no_by_id($school_id, $class_id);
            $class_no = $class_short['class_short_form'];
            
            if($id==1){
                $student_id = $school_id."00000".$latest_id;
            }
            else if($id==2){
                $student_id = $school_id."0000".$latest_id;
            }
            else if($id==3){
                $student_id = $school_id."000".$latest_id;
            }
            
            else if($id==4){
                $student_id = $school_id."00".$latest_id;
            }
            else if($id==5){
                $student_id = $school_id."0".$latest_id;
            }
            else{
                $student_id = $school_id.$latest_id;
            }
            
            if ( $_FILES AND $_FILES['student_image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/student_image";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "720";
                    $config['max_width']     =   "1500";
                    $config['max_height']    =   "1500";
		    $config['overwrite']     =   true;				
                    $config['file_name']    =   $student_id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('student_image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
					   $student_photo = $spinfo['file_name'];
                    }
					unset($config);
				}
			else{
				$student_photo = '';
			}
            
                        
            $data['student_id'] = $student_id;
            $data['password'] = $_POST['password'];
            $data['school_id'] = $school_id;
            $data['student_name'] = $_POST['student_name'];
            $data['birth_date'] = $_POST['birth_date'];
            $data['age'] = $_POST['age'];
            $data['birth_cert_no'] = $_POST['birth_cert_no'];
            $data['cur_date'] = $_POST['cur_date'];
            $data['nationality'] = $_POST['nationality'];
            $data['religion'] = $_POST['religion'];
            $data['gender'] = $_POST['gender'];
            $data['student_image'] = $student_photo;
			
            $data['present_address'] = $_POST['present_address'];
            $data['present_division'] = $_POST['present_division'];
            $data['present_district'] = $_POST['present_district'];
            $data['present_upazila'] = $_POST['present_upazila'];
            $data['present_po'] = $_POST['present_po'];
            $data['present_pc'] = $_POST['present_pc'];
			
			if($_POST['check_address']==1){
				$data['permanent_address'] = $_POST['present_address'];
				$data['permanent_division'] = $_POST['present_division'];
				$data['permanent_district'] = $_POST['present_district'];
				$data['permanent_upazila'] =  $_POST['present_upazila'];
				$data['permanent_po'] =  $_POST['present_po'];
				$data['permanent_pc'] = $_POST['present_pc'];
			}
			else{
				$data['permanent_address'] = $_POST['permanent_address'];
				$data['permanent_division'] = $_POST['permanent_division'];
				$data['permanent_district'] = $_POST['permanent_district'];
				$data['permanent_upazila'] = $_POST['permanent_upazila'];
				$data['permanent_po'] = $_POST['permanent_po'];
				$data['permanent_pc'] = $_POST['permanent_pc'];
			}
            $data['father_name'] = $_POST['father_name'];
            $data['mother_name'] = $_POST['mother_name'];
            $data['father_nid'] = $_POST['father_nid'];
            $data['mother_nid'] = $_POST['mother_nid'];
            $data['father_occupation'] = $_POST['father_occupation'];
            $data['mother_occupation'] = $_POST['mother_occupation'];
            $data['father_education'] = $_POST['father_education'];
            $data['mother_education'] = $_POST['mother_education'];
            $data['father_home_contact'] = $_POST['father_home_contact'];
            $data['mobile_contact'] = $_POST['mobile_contact'];
            $data['father_email'] = $_POST['father_email'];
            $data['mother_home_contact'] = $_POST['mother_home_contact'];
            $data['mother_email'] = $_POST['mother_email'];
			$data['guardian_1_name'] = $_POST['guardian_1_name'];
			$data['guardian_1_relation'] = $_POST['guardian_1_relation'];
			$data['guardian_1_occupation'] = $_POST['guardian_1_occupation'];
			$data['guardian_1_yearly_income'] = $_POST['guardian_1_yearly_income'];
			$data['guardian_1_mobile'] = $_POST['guardian_1_mobile'];
			$data['guardian_1_email'] = $_POST['guardian_1_email'];
	    $data['siblings_1_id'] = $_POST['siblings_1_id'];
            $data['siblings_2_id'] = $_POST['siblings_2_id'];
            $data['siblings_3_id'] = $_POST['siblings_3_id'];
            $data['siblings_4_id'] = $_POST['siblings_4_id'];
            $data['previous_school_name'] = $_POST['previous_school_name'];
            $data['previous_start_date'] = $_POST['previous_start_date'];
            $data['previous_finish_date'] = $_POST['previous_finish_date'];
            $data['previous_finish_class'] = $_POST['previous_finish_class'];
            $data['blood_group'] = $_POST['blood_group'];
            $data['financial_aid'] = $_POST['financial_aid'];
            $data['fees_aid'] = $_POST['fees_aid'];
            $data['aid_amount'] = $_POST['aid_amount'];
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            //print_r($data);exit();        
            if($this->Common_model->common_insert($data,'tbl_student')){
				$dataClass['student_id'] = $student_id;
				$dataClass['roll_no'] = $_POST['roll_no'];
				$dataClass['session_id'] = $_POST['session_id'];
				$dataClass['section_id'] = $_POST['section_id'];
				$dataClass['school_id'] = $school_id;        
				$dataClass['class_id'] = $_POST['class_id'];
				$dataClass['group_id'] = $_POST['group_id']; 
				$dataClass['shift_id'] = $_POST['shift_id'];
				$dataClass['status'] = 1;
				if($this->Common_model->common_insert($dataClass,'tbl_student_class')){
					if($_POST['exam_name']){
						for ($u = 0; $u < count($_POST['exam_name']); $u++) {
							if($_POST['exam_name'][$u]){
								$data_exam[] = array(
									'student_id' => $student_id,
									'exam_name' => $_POST['exam_name'][$u],
									'exam_regi' => $_POST['exam_regi'][$u],
									'exam_roll' => $_POST['exam_roll'][$u],
									'exam_gpa' => $_POST['exam_gpa'][$u],
									'status' => 1
								);
							}
						}
						$this->Common_model->common_insert_batch($data_exam,'tbl_student_board_exam');
					}
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a> Data has been saved successfully</div>');
				}
				else{
					$d_data['school_id'] = 1;
					$d_data['student_id'] = $student_id;
					$this->Common_model->common_delete($d_data,'tbl_student');
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a> Data has not been saved successfully. Please Try again.</div>');
				}
			}
			else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a> Data has not been saved successfully. Please Try again.</div>');
			}
            redirect('admin/student_registration');exit;
        }
    }
    
    public function student_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['group_list'] = $this->Admin_model->get_group_list($school_id);
$c_data['school_id']=$school_id;
		$c_data['session_name']=date('Y');
		$stusession_id=$this->Common_model->common_select_by_multycondition($c_data,'tbl_session');
		$where='';
		if($_POST['class_id']){
			if($_POST['class_id']!="all"){
				$this->session->set_userdata('class_id', $_POST['class_id']);
			}
			elseif($_POST['class_id']=="all"){
				$this->session->unset_userdata('class_id');
				$this->session->unset_userdata('section_id');
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['section_id']){
			
			if($_POST['section_id']!="all"){
				$this->session->set_userdata('section_id', $_POST['section_id']);
			}
			elseif($_POST['section_id']=="all"){
				$this->session->unset_userdata('section_id');
			}
		}
		if($_POST['group_id']){
			
			if($_POST['group_id']!="all"){
				$this->session->set_userdata('group_id', $_POST['group_id']);
			}
			elseif($_POST['group_id']=="all"){
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['shift_id']){
			
			if($_POST['shift_id']!="all"){
				$this->session->set_userdata('shift_id', $_POST['shift_id']);
			}
			elseif($_POST['shift_id']=="all"){
				$this->session->unset_userdata('shift_id');
			}
		}
		if($_POST['gender_id']){
			
			if($_POST['gender_id']!="all"){
				$this->session->set_userdata('gender_id', $_POST['gender_id']);
			}
			elseif($_POST['gender_id']=="all"){
				$this->session->unset_userdata('gender_id');
			}
		}
		
		if($this->session->userdata('class_id'))
			$where.=' and tbl_student_class.class_id='.$this->session->userdata('class_id').' ';

		if($stusession_id[0]['session_id'])
			$where.=' and tbl_student_class.session_id='.$stusession_id[0]['session_id'].' ';

		if($this->session->userdata('section_id'))
			$where.=' and tbl_student_class.section_id='.$this->session->userdata('section_id').' ';
		
		if($this->session->userdata('group_id'))
			$where.=' and tbl_student_class.group_id='.$this->session->userdata('group_id').' ';

		if($this->session->userdata('shift_id'))
			$where.=' and tbl_student_class.shift_id='.$this->session->userdata('shift_id').' ';

		if($this->session->userdata('gender_id'))
			$where.=' and tbl_student.gender="'.$this->session->userdata('gender_id').'" ';
			
	$data['division_list'] = $this->Common_model->common_result_array('tbl_divisions');
		$data['district_list'] = $this->Common_model->common_result_array('tbl_districts');
		$data['upazila_list'] = $this->Common_model->common_result_array('tbl_upazilas');	
        $data['student_list'] = $this->Admin_model->get_all_student_list($school_id,$where);
        $this->load->view('admin/student_list', $data);
    }
        
    public function student_information_view($student_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['school_info'] = $this->Admin_model->get_school_information($school_id);
        $data['student_info'] = $this->Admin_model->get_student_info_by_id($school_id, $student_id);
		$data['student_exam_info'] = $this->Common_model->common_select_by_condition($student_id,'student_id','tbl_student_board_exam');
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['group_list'] = $this->Admin_model->get_group_list($school_id);
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['division_list'] = $this->Common_model->common_result_array('tbl_divisions');
		$data['district_list'] = $this->Common_model->common_result_array('tbl_districts');
		$data['upazila_list'] = $this->Common_model->common_result_array('tbl_upazilas');
		$data['fees_list'] = $this->Common_model->common_result_array('tbl_fees_category');
        $this->load->view('admin/student_information_view', $data);
    }
    
    public function student_information_edit($student_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['school_info'] = $this->Admin_model->get_school_information($school_id);
        $data['student_info'] = $this->Admin_model->get_student_info_by_id($school_id, $student_id);
        $data['student_exam_info'] = $this->Common_model->common_select_by_condition($student_id,'student_id','tbl_student_board_exam');
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['session_list'] = $this->Admin_model->get_session_list($school_id);
        $data['group_list'] = $this->Admin_model->get_group_list($school_id);
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['division_list'] = $this->Common_model->common_result_array('tbl_divisions');
		$data['district_list'] = $this->Common_model->common_result_array('tbl_districts');
		$data['upazila_list'] = $this->Common_model->common_result_array('tbl_upazilas');
		$data['fees_list'] = $this->Common_model->common_result_array('tbl_fees_category');
        $this->load->view('admin/student_information_edit', $data);
    }
    
    function student_information_edit_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $student_id = $_POST['student_id'];
            if ( $_FILES AND $_FILES['student_image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/student_image";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
					$config['overwrite']     =   true;				
                    $config['file_name']    =   $student_id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('student_image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
					   $data['student_image'] = $spinfo['file_name'];
                    }
				} 
		if($_POST['password']!=''){
			$data['password'] = $_POST['password'];
		}
                $data['student_name'] = $_POST['student_name'];
				$data['birth_date'] = $_POST['birth_date'];
				$data['age'] = $_POST['age'];
				$data['birth_cert_no'] = $_POST['birth_cert_no'];
				$data['cur_date'] = $_POST['cur_date'];
				$data['nationality'] = $_POST['nationality'];
				$data['religion'] = $_POST['religion'];
				$data['gender'] = $_POST['gender'];
				
				$data['present_address'] = $_POST['present_address'];
				$data['present_division'] = $_POST['present_division'];
				$data['present_district'] = $_POST['present_district'];
				$data['present_upazila'] = $_POST['present_upazila'];
				$data['present_po'] = $_POST['present_po'];
				$data['present_pc'] = $_POST['present_pc'];
				
				if($_POST['check_address']==1){
					$data['permanent_address'] = $_POST['present_address'];
					$data['permanent_division'] = $_POST['present_division'];
					$data['permanent_district'] = $_POST['present_district'];
					$data['permanent_upazila'] =  $_POST['present_upazila'];
					$data['permanent_po'] =  $_POST['present_po'];
					$data['permanent_pc'] = $_POST['present_pc'];
				}
				else{
					$data['permanent_address'] = $_POST['permanent_address'];
					$data['permanent_division'] = $_POST['permanent_division'];
					$data['permanent_district'] = $_POST['permanent_district'];
					$data['permanent_upazila'] = $_POST['permanent_upazila'];
					$data['permanent_po'] = $_POST['permanent_po'];
					$data['permanent_pc'] = $_POST['permanent_pc'];
				}
			
				$data['father_name'] = $_POST['father_name'];
				$data['mother_name'] = $_POST['mother_name'];
				$data['father_nid'] = $_POST['father_nid'];
				$data['mother_nid'] = $_POST['mother_nid'];
				$data['father_occupation'] = $_POST['father_occupation'];
				$data['mother_occupation'] = $_POST['mother_occupation'];
				$data['father_education'] = $_POST['father_education'];
				$data['mother_education'] = $_POST['mother_education'];
				$data['father_home_contact'] = $_POST['father_home_contact'];
				$data['mobile_contact'] = $_POST['mobile_contact'];
				$data['father_email'] = $_POST['father_email'];
				$data['mother_home_contact'] = $_POST['mother_home_contact'];
				$data['mother_email'] = $_POST['mother_email'];
				$data['guardian_1_name'] = $_POST['guardian_1_name'];
				$data['guardian_1_relation'] = $_POST['guardian_1_relation'];
				$data['guardian_1_occupation'] = $_POST['guardian_1_occupation'];
				$data['guardian_1_yearly_income'] = $_POST['guardian_1_yearly_income'];
				$data['guardian_1_mobile'] = $_POST['guardian_1_mobile'];
				$data['guardian_1_email'] = $_POST['guardian_1_email'];
				$data['siblings_1_id'] = $_POST['siblings_1_id'];
				$data['siblings_2_id'] = $_POST['siblings_2_id'];
				$data['siblings_3_id'] = $_POST['siblings_3_id'];
				$data['siblings_4_id'] = $_POST['siblings_4_id'];
				$data['previous_school_name'] = $_POST['previous_school_name'];
				$data['previous_start_date'] = $_POST['previous_start_date'];
				$data['previous_finish_date'] = $_POST['previous_finish_date'];
				$data['previous_finish_class'] = $_POST['previous_finish_class'];
				$data['blood_group'] = $_POST['blood_group'];
				$data['financial_aid'] = $_POST['financial_aid'];
				$data['fees_aid'] = $_POST['fees_aid'];
				$data['aid_amount'] = $_POST['aid_amount'];
                
			$this->Common_model->common_update($data, $student_id,'student_id','tbl_student');
				// update student class information
                    $dataClass['roll_no'] = $_POST['roll_no'];
                    $dataClass['session_id'] = $_POST['session_id'];
                    $dataClass['section_id'] = $_POST['section_id'];
                    $dataClass['school_id'] = $school_id;        
                    $dataClass['class_id'] = $_POST['class_id'];
                    $dataClass['group_id'] = $_POST['group_id'];
					$dataClass['shift_id'] = $_POST['shift_id'];        
				$this->Common_model->common_update($dataClass, $student_id,'student_id','tbl_student_class');
				
					if($_POST['exam_name']){
						for ($u = 0; $u < count($_POST['exam_name']); $u++) {
							if($_POST['id'][$u]){
								$data_examu[] = array(
									'id' =>  $_POST['id'][$u],
									'exam_name' => $_POST['exam_name'][$u],
									'exam_regi' => $_POST['exam_regi'][$u],
									'exam_roll' => $_POST['exam_roll'][$u],
									'exam_gpa' => $_POST['exam_gpa'][$u]
								);
							}
							elseif($_POST['exam_name'][$u]){
								$data_exam[] = array(
									'student_id' =>  $student_id,
									'exam_name' => $_POST['exam_name'][$u],
									'exam_regi' => $_POST['exam_regi'][$u],
									'exam_roll' => $_POST['exam_roll'][$u],
									'exam_gpa' => $_POST['exam_gpa'][$u],
									'status' => 1
								);
							}
							
						}
						if($data_examu)
						$this->Common_model->common_batch_update('tbl_student_board_exam',$data_examu,'id');
						
						if($data_exam)
						$this->Common_model->common_insert_batch($data_exam,'tbl_student_board_exam');
					}
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
          redirect('admin/student_list');exit;                    
		}
	}
    function student_information_delete($student_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['student_id'] = $student_id;
		$this->Common_model->common_delete($d_data,'tbl_student');
		$this->Common_model->common_delete($d_data,'tbl_student_class');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('admin/student_list');exit;
    }   
        
        
        
    public function class_wise_student_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $this->load->view('admin/class_wise_student_list', $data);
    }
    
    public function get_class_wise_student_list_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        
        $data['student_list'] = $this->Admin_model->get_class_wise_student_list($school_id, $class_id);
        $count = $this->Admin_model->get_class_wise_student_count($school_id, $class_id);
        $c = $count['count'];
        
        if($c>0){
            $mainContent=$this->load->view('admin/get_class_wise_student_list_json', $data, true);
        }
        else{
            $mainContent="No Record Found!";
        }       
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	
    /* fees management */

    public function class_wise_fees_management(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $this->load->view('admin/class_wise_fees', $data);
    }
    
    public function get_class_wise_fees_management_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		
		$data['fee_management_entry'] = $this->Admin_model->get_class_wise_fees_management_entry($school_id, $class_id);
		$data['fee_management'] = $this->Admin_model->get_class_wise_fees_management($school_id, $class_id);
        
        
		$count = $this->Admin_model->get_class_wise_fees_management_count($school_id, $class_id);
        $c = $count['count'];
        
        if($c>0){
            $mainContent=$this->load->view('admin/get_class_wise_fees_management_json', $data, true);
            //$mainContent= "hello";
        }
        else{
            //$mainContent="No Record Found!";
            $mainContent=$this->load->view('admin/get_class_wise_fees_management_entry_json', $data, true);
        }       
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	/* /fees management */
    
    
    /* Students sms notice */
    
    public function student_sms_notice(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $this->load->view('admin/student_sms_notice', $data);
    }
    
    public function get_class_wise_student_list_for_sms_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        
        if($class_id == 0){
          $data['student_list'] = $this->Admin_model->get_all_student_list($school_id,'');
          //$mainContent=$this->load->view('admin/student_list', $data);
          $mainContent=$this->load->view('admin/get_class_wise_student_list_sms_json', $data, true);
          //$mainContent="Imon";
        }
        else{
        
        $data['student_list'] = $this->Admin_model->get_class_wise_student_list($school_id, $class_id);
        $count = $this->Admin_model->get_class_wise_student_count($school_id, $class_id);
        $c = $count['count'];
        
        if($c>0){
            $mainContent=$this->load->view('admin/get_class_wise_student_list_sms_json', $data, true);
            //$mainContent=$class_id;
        }
        else{
            $mainContent="No record found";
        }
        
        }
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
    
    public function send_classwise_sms_notice(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        
        for ($i = 0; $i < count($_POST['student_name']); $i++) {                
                $this->send_sms_notice_all($_POST['student_name'][$i], $_POST['sms_contact'][$i], $_POST['msg']);
            //echo $_POST['student_name'][$i], $_POST['sms_contact'][$i], $_POST['msg']."<br/>";
        }
        //echo $i."<br/>". $_POST['msg'];
        //exit;
        
        //$this->load->view('admin/student_sms_notice', $data);
        
		 $this->session->set_flashdata('message', " SMS send successfully ");
       
               redirect('admin/student_sms_notice', 'refresh');
            exit;  
    }
    
    public function send_sms_to_teacher(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        
        for ($i = 0; $i < count($_POST['sms_contact']); $i++) {                
                $this->send_sms_notice_all($_POST['teacher_name'][$i], $_POST['sms_contact'][$i], $_POST['msg']);
        }
        
       $this->session->set_flashdata('message', " SMS send successfully ");
               redirect('admin/teacher_list', 'refresh');
            exit;  
    }
    
    /* send all student same notice */
	public function send_sms_notice_to_student(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $student_list=$this->Common_model->common_select_field('tbl_student','student_id','ASC','mobile_contact');
		
        for ($i = 0; $i < count($student_list); $i++) {                
                if($student_list[$i]->mobile_contact){
                	$this->send_sms_notice_all($student_list[$i]->mobile_contact);
                }
            echo $student_list[$i]->mobile_contact."<br/>";
        }
        //echo $i."<br/>". $_POST['msg'];
        //exit;
        
        //$this->load->view('admin/student_sms_notice', $data);
        
		/* $this->session->set_flashdata('message', " SMS send successfully ");
       
               redirect('admin/student_sms_notice', 'refresh');
            exit;  */
    }
    
      public function send_sms_notice_all($number) {
    //public function send_sms_notice_all() {
        $phone = "88". $number;
        $msg_text = "";
        $encode = urlencode($msg_text);
		//http://107.20.199.106/api/v3/sendsms/plain?user=test&password=test&SMSText=text heare&GSM=8801687295469&datacoding=8
       // $url = 'http://107.20.199.106/api/v3/sendsms/plain?user=weblink1&password=link5566&sender=SHARIF&SMSText='.$encode.'&GSM='.$phone.'&datacoding=8';
        //$url = 'http://api.infobip.com/api/v3/sendsms/plain?user=bisectg&password=leWU7EXj&sender=AHIS&SMSText=' .$encode. '&GSM='.$phone;

        $datas = file_get_contents($url);
		
       
        $data = array(
                    'msg' => $msg_text,
                    'mobile' => $phone,
			'sms_datas'=>$datas,
			'created_on'=>date('Y-m-d H:i:s')
                     );
        
        $this->db->insert('tbl_notice_sms', $data);
        
		//$this->session->set_flashdata('message', " SMS send successfully ");
        //redirect('admin/student_sms_notice', 'refresh');
		//exit;  
    }
   
    /*public function send_sms_notice_all($name, $number, $msg) {
        $phone = "88" . $number;
        $msg_text = "Dear $name, $msg";
        $encode = urlencode($msg_text);
        $url = 'http://api.infobip.com/api/v3/sendsms/plain?user=bisectg&password=leWU7EXj&sender=AHIS&SMSText=' .$encode. '&GSM='.$phone;

        $datas = file_get_contents($url);
        
        $data = array(
                    'msg' => $msg_text,
                    'mobile' => $number
                     );
        
        $this->db->insert('tbl_notice_sms', $data);
        
		$this->session->set_flashdata('message', " SMS send successfully ");
        redirect('admin/student_sms_notice', 'refresh');
		exit;    
    }*/
    
    /* /Students sms notice */
    
    
    public function section_wise_student_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['section_list'] = $this->Admin_model->get_section_list($school_id);        
        $this->load->view('admin/section_wise_student_list', $data);
    }
    
    
    public function get_section_wise_student_list_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        $section_id = $_GET['section_id'];
        
        $data['student_list'] = $this->Admin_model->get_section_wise_student_list($school_id, $class_id, $section_id);
        $count = $this->Admin_model->get_section_wise_student_count($school_id, $class_id, $section_id);
        $c = $count['count'];
        
        if($c>0){
            $mainContent=$this->load->view('admin/get_class_wise_student_list_json', $data, true);
        }
        else{
            $mainContent="No Record Found!";
        }       
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
    
    /**For Student Subject Assign**/
    public function student_subject_assign(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list_sub_assign($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $this->load->view('admin/student_subject_assign', $data);
    }
    
    public function get_student_list_for_subject_assign_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        $group_id = $_GET['group_id'];
		$session_id = $_GET['session_id'];
        
        $data['student_list'] = $this->Admin_model->get_student_list_for_subject_assign_json($school_id, $class_id, $group_id, $session_id);
        $data['subject_list'] = $this->Admin_model->get_class_wise_subject_for_subect_assign($school_id, $class_id, $group_id);
       // $data['optional_subject_list'] = $this->Admin_model->get_class_wise_optional_subject_subject_list($school_id, $class_id, $group_id);
        //$count = $this->Admin_model->get_section_wise_student_count($school_id, $class_id, $section_id);
        $c = count($data['student_list']);
        
        if($c>0){
            $mainContent=$this->load->view('admin/get_student_list_for_subject_assign_json', $data, true);
        }
        else{
            $mainContent="No Record Found!";
        }       
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
    
    
    function student_subject_assign_save(){
        if(isPostBack()){

            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $class_id = $_POST['class_id'];
            $group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];           
            $subject_op = $_POST['subject_op'];  
            $subject_com = $_POST['subject_com'];
            #dumpVar($_POST);
            
			foreach($subject_op as $k => $v)
                {
					$sso=explode(',',$v);
					$data[] = array(
								'school_id' => $school_id,
								'class_id' => $class_id,
								'group_id' => $group_id,
								'session_id' => $session_id,
								'student_id' => $sso[0],
								'subject_id' => $sso[1],
								'optional_id' => $sso[2],
								'status' => 1,
								'created_on' => date('Y-m-d H:i:s',time())
								);
				}
					
            foreach($subject_com as $s => $i)
                {
                 	$ssc=explode(',',$i);
					$data[] = array(
								'school_id' => $school_id,
								'class_id' => $class_id,
								'group_id' => $group_id,
								'session_id' => $session_id,
								'student_id' => $ssc[0],
								'subject_id' => $ssc[1],
								'optional_id' => $ssc[2],
								'status' => 1,
								'created_on' => date('Y-m-d H:i:s',time())
								);
                                
                }
                      
				$d_data['school_id']= $school_id;
				$d_data['class_id']=$class_id;
				$d_data['group_id']=$group_id;
				$d_data['session_id']=$session_id;
				
				$this->Common_model->common_delete($d_data,'tbl_student_subject');
					if($this->Common_model->common_insert_batch($data,'tbl_student_subject'))
						{
							$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
						}
					else
						{
							$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
						}
					
            redirect('admin/student_subject_assign'); exit; 
            
        }
    }
    
    
    public function student_subject_view(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list_sub_assign($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $this->load->view('admin/student_subject_view', $data);
    }
    
    
    public function get_section_wise_student_for_dropdown_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        $section_id = $_GET['section_id'];
        
        $student_list = $this->Admin_model->get_section_wise_student_list($school_id, $class_id, $section_id);                
        if($student_list){
            $mainContent ="<option value='0'>---Select Student---</option>";
            foreach($student_list as $sl){
                $mainContent .="<option value='".$sl['student_id']."'>".$sl['student_name']."</option>";
            }            
            #$mainContent=$this->load->view('admin/get_class_wise_student_list_json', $data, true);
        }
        else{
            $mainContent .="<option>No Student Found!</option>";
        }       
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
    
    
    public function get_student_subject_view(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        $group_id = $_GET['group_id'];
        $session_id = $_GET['session_id'];
        
        $data['subject_list'] = $this->Admin_model->get_student_subject_view($school_id, $class_id, $group_id, $session_id); 
        $data['data']=array('class_id'=>$class_id,'group_id'=>$group_id,'session_id'=>$session_id);
		
            $mainContent=$this->load->view('admin/get_student_subject_view', $data, true);
             
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
    
    
    public function student_subject_edit($student_id,$class_id,$group_id,$session_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;        
        $data['subject_info'] = $this->Admin_model->get_subject_info_by_student_id($school_id,$student_id,$class_id,$group_id,$session_id);
		$data['data']=array('class_id'=>$class_id,'group_id'=>$group_id,'session_id'=>$session_id);
		$data['subject_list'] = $this->Admin_model->get_class_wise_subject_for_subect_assign($school_id, $class_id, $group_id);     
        $this->load->view('admin/student_subject_edit', $data);
    }
    function student_subject_edit_save(){
         if(isPostBack()){

            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $class_id = $_POST['class_id'];
            $group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];           
            $subject_op = $_POST['subject_op'];  
            $subject_com = $_POST['subject_com'];
            #dumpVar($_POST);
            
			foreach($subject_op as $k => $v)
                {
					$sso=explode(',',$v);
					$data[] = array(
								'school_id' => $school_id,
								'class_id' => $class_id,
								'group_id' => $group_id,
								'session_id' => $session_id,
								'student_id' => $sso[0],
								'subject_id' => $sso[1],
								'optional_id' => $sso[2],
								'status' => 1,
								'created_on' => date('Y-m-d H:i:s',time())
								);
				}
					
            foreach($subject_com as $s => $i)
                {
                 	$ssc=explode(',',$i);
					$data[] = array(
								'school_id' => $school_id,
								'class_id' => $class_id,
								'group_id' => $group_id,
								'session_id' => $session_id,
								'student_id' => $ssc[0],
								'subject_id' => $ssc[1],
								'optional_id' => $ssc[2],
								'status' => 1,
								'created_on' => date('Y-m-d H:i:s',time())
								);
                                
                }
                      
				$d_data['school_id']=$school_id;
				$d_data['class_id']=$class_id;
				$d_data['group_id']=$group_id;
				$d_data['session_id']=$session_id;
				$d_data['student_id']=$_POST['student_id'];
				
				$this->Common_model->common_delete($d_data,'tbl_student_subject');
					if($this->Common_model->common_insert_batch($data,'tbl_student_subject'))
						{
							$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
						}
					else
						{
							$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
						}
					
            redirect('admin/student_subject_view'); exit; 
            
        }
    }
    
    
        
      /**Setings Portion**/
        
    public function class_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $this->load->view('admin/class_list', $data);
    }
    
    function class_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['class_name'] = $_POST['class_name'];
            $data['class_short_form'] = $_POST['class_short_form'];
            $data['status'] = 1;
            $data['school_id'] = $school_id;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_class');
			 $this->session->set_flashdata('message','<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            redirect('admin/class_list');exit;
            
        }
    }
    
    
    public function class_edit($class_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_info_by_id($school_id, $class_id);
        $this->load->view('admin/class_edit', $data);
    }
    
    public function class_edit_save(){
        if(isPostBack()){
            $class_id = $_POST['class_id'];
            $data['class_name'] = $_POST['class_name'];
            $data['class_short_form'] = $_POST['class_short_form'];
            $this->Common_model->common_update($data, $class_id,'class_id','tbl_class');        
             $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            redirect('admin/class_list');exit;                    
        }
    }
    
    public function class_delete($class_id){
            #$school_id = $_SESSION['school_id'];
            $d_data['school_id'] = 1;
			$d_data['class_id'] = $class_id;
			$this->Common_model->common_delete($d_data,'tbl_class');
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
            redirect('admin/class_list');exit;
    }
  
    
    
    public function section_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['section_list'] = $this->Admin_model->get_section_list($school_id);
        $this->load->view('admin/section_list', $data);
    }
    
    function section_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['section_name'] = $_POST['section_name'];
            $data['status'] = 1;
            $data['school_id'] = $school_id;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_section');
			$this->session->set_flashdata('message', " Section has been saved successfully ");
            redirect('admin/section_list');exit;
            
        }
    }
        
    public function section_edit($section_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['section_list'] = $this->Admin_model->get_section_info_by_id($school_id, $section_id);
        $this->load->view('admin/section_edit', $data);
    }
    
    function section_edit_save(){
        if(isPostBack()){
            $section_id = $_POST['section_id'];
            $data['section_name'] = $_POST['section_name'];
            $this->Common_model->common_update($data, $section_id,'section_id','tbl_section');        
            $this->session->set_flashdata('message', " Section has been updated successfully ");
            redirect('admin/section_list');exit;                    
        }
    }
    
    function section_delete($section_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['section_id'] = $section_id;
		$this->Common_model->common_delete($d_data,'tbl_section');
		$this->session->set_flashdata('message', " Section has been deleted successfully ");
        redirect('admin/section_list');exit;
    }
    
    public function section_assign(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $this->load->view('admin/section_assign', $data);
    }
    
    function get_section_list_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id  = $_GET['class_id'];
        $data['class_id'] = $class_id;
        $data['section_list'] = $this->Admin_model->get_section_list($school_id);
        $mainContent= $this->load->view('admin/get_section_list_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }
        
        
        
    function save_class_section(){
        if(isPostBack())
        {
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $class_id = $_POST['class_id'];
            $sectionArr = $_POST['section_name'];             
            if($class_id)
            {
                $this->Admin_model->delete_record($class_id,$school_id);
                if($sectionArr)
                {
                    foreach($sectionArr as $k => $v)
                    {
                        $data['school_id'] = $school_id;
                        $data['class_id'] = $class_id;
                        $data['section_id'] = $v;
                        $data['status'] = 1;
                        $this->Common_model->common_insert($data,'tbl_class_section');
                    }
                    $this->session->set_flashdata('message', " Class section has been updated successfully ");
                    redirect('admin/section_assign'); exit;
                }
                redirect('admin/section_assign'); exit;
            }
            redirect('admin/section_assign'); exit; 
        }
    }
    
    /**Session Setup**/
    public function session_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['session_list'] = $this->Admin_model->get_session_list($school_id);
        $this->load->view('admin/session_list', $data);
    }
    
    function session_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['school_id'] = $school_id;
            $data['session_name'] = $_POST['session_name'];
            $data['status'] = 1;            
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_session');
			 $this->session->set_flashdata('message', " Session has been saved successfully ");
            redirect('admin/session_list');exit;
            
        }
    }
    
    
    public function session_edit($session_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['session_list'] = $this->Admin_model->get_session_info_by_id($school_id, $session_id);
        $this->load->view('admin/session_edit', $data);
    }
    
    function session_edit_save(){
        if(isPostBack()){
            $session_id = $_POST['session_id'];
            $data['session_name'] = $_POST['session_name'];
            $this->Common_model->common_update($data, $session_id,'session_id','tbl_session');        
           $this->session->set_flashdata('message', " Session has been updated successfully ");
            redirect('admin/session_list');exit;                    
        }
    }
    
    function session_delete($session_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['session_id'] = $session_id;
		$this->Common_model->common_delete($d_data,'tbl_session');
        $this->session->set_flashdata('message', " Session has been deleted successfully ");
        redirect('admin/session_list');exit;
    }
    
    
    /**Shift Management**/
    public function shift_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
        $this->load->view('admin/shift_list', $data);
    }
    
    function shift_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['shift_name'] = $_POST['shift_name'];            
            $data['school_id'] = $school_id;
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_shift');
			$this->session->set_flashdata('message', " Shift has been saved successfully ");
            redirect('admin/shift_list');exit;
            
        }
    }
    
    public function shift_edit($shift_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['shift_list'] = $this->Admin_model->get_shift_info_by_id($school_id, $shift_id);
        $this->load->view('admin/shift_edit', $data);
    }
    
    function shift_edit_save(){
        if(isPostBack()){
            $shift_id = $_POST['shift_id'];
            $data['shift_name'] = $_POST['shift_name'];
            $this->Common_model->common_update($data, $shift_id,'shift_id','tbl_shift');        
            $this->session->set_flashdata('message', " Shift has been updated successfully ");
            redirect('admin/shift_list');exit;                    
        }
    }
    
    function shift_delete($shift_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['shift_id'] = $shift_id;
		$this->Common_model->common_delete($d_data,'tbl_shift');
       $this->session->set_flashdata('message', " Shift has been deleted successfully ");
        redirect('admin/shift_list');exit;
    }
    
    
    
    
    /**Teacher Management Settings**/
    public function department_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['department_list'] = $this->Admin_model->get_department_list($school_id);
        $this->load->view('admin/department_list', $data);
    }
    
    function department_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['department_name'] = $_POST['department_name'];            
            $data['bn_department_name'] = $_POST['bn_department_name'];            
            $data['school_id'] = $school_id;
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            if($this->Common_model->common_insert($data,'tbl_department'))
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
			
            redirect('admin/department_list');exit;
        }
    }    
    
    public function department_edit($department_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['department_list'] = $this->Admin_model->get_department_info_by_id($school_id, $department_id);
        $this->load->view('admin/department_edit', $data);
    }
    
    function department_edit_save(){
        if(isPostBack()){
            $department_id = $_POST['department_id'];
            $data['department_name'] = $_POST['department_name'];
            $data['bn_department_name'] = $_POST['bn_department_name'];
            if($this->Common_model->common_update($data, $department_id,'department_id','tbl_department'))      
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('admin/department_list');exit;                    
        }
    }
    
    
    function department_delete($department_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['department_id'] = $department_id;
		if($this->Common_model->common_delete($d_data,'tbl_department'))
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted.</div>');
        redirect('admin/department_list');exit;
    }
    
    /**Subject Portion**/
    public function subject_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['subject_list'] = $this->Admin_model->get_subject_list($school_id);
        $this->load->view('admin/subject_list', $data);
    }
       
    
      function subject_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['school_id'] = $school_id;
            $data['subject_name'] = $_POST['subject_name'];
            $data['subject_bn'] = $_POST['subject_bn'];
            $data['subject_code'] = $_POST['subject_code'];            
            $data['is_optional'] = $_POST['is_optional'];            
            $data['marks_type'] = $_POST['marks_type'];            
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_subject');
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            redirect('admin/subject_list');exit;
        }
    }  
    
    public function subject_edit($subject_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['subject_list'] = $this->Admin_model->get_subject_info_by_id($school_id, $subject_id);
        $this->load->view('admin/subject_edit', $data);
    }
    
    public function subject_edit_save(){
        if(isPostBack()){
            $subject_id = $_POST['subject_id'];
            $data['subject_name'] = $_POST['subject_name'];
            $data['subject_bn'] = $_POST['subject_bn'];
            $data['subject_code'] = $_POST['subject_code'];
            $data['is_optional'] = $_POST['is_optional'];
            $data['marks_type'] = $_POST['marks_type'];
            $this->Common_model->common_update($data, $subject_id,'subject_id','tbl_subject');        
           $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            redirect('admin/subject_list');exit;                    
        }
    }
    
    function subject_delete($subject_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['subject_id'] = $subject_id;
		$this->Common_model->common_delete($d_data,'tbl_subject');
		$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('admin/subject_list');exit;
    }
    
    function subject_assign(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $this->load->view('admin/subject_assign', $data);
    }
    
    function get_subject_list_json(){
        $class_id  = $_GET['class_id']; 
        $group_id  = $_GET['group_id']; 
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_id'] = $class_id;  
        $data['group_id'] = $group_id;        
        $data['subject_list'] = $this->Admin_model->get_subject_list($school_id);
        $mainContent= $this->load->view('admin/get_subject_list_json', $data, true);

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }
        
        
        
    function save_class_subject()
    {
        if(isPostBack())
        {
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $class_id = $_POST['class_id'];
            $group_id = $_POST['group_id'];
            $subjectArr = $_POST['subject'];             
 
                if($subjectArr)
                {
                    foreach($subjectArr as $k => $v)
                    {
                        $data[] = array(
								'school_id' => $school_id,
								'class_id' => $class_id,
								'group_id' => $group_id,
								'subject_id' => $v,
								'status' => 1,
								'created_on' => date('Y-m-d H:i:s',time())
								);                                            
                    }
					$d_data['school_id']=$school_id;
					$d_data['class_id']=$class_id;
					$d_data['group_id']=$group_id;
					
					$this->Common_model->common_delete($d_data,'tbl_class_subject');
					
					if($this->Common_model->common_insert_batch($data,'tbl_class_subject'))
						{
							$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
						}
					else
						{
							$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
						}
					 
                  
                    redirect('admin/subject_assign','refresh'); exit;
                }
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
                redirect('admin/subject_assign'); exit;
           
        }
    } 
    /**Holiday Management**/
    public function weekly_holiday(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['week_day'] = $this->Admin_model->get_week_list($school_id);
        $this->load->view('admin/weekly_holiday', $data);
    }
    
    function weekly_holiday_update(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            // $idcount = $_POST['status'];
           
            $i=0;
             
            while($i<count($_POST['status'])){
            
            if($_POST['status'][$i]==0)
            {
            $data['status'] = 0 ;
            }
            else
            {
            	$data['status'] = 1;
            }
            $id = $_POST['id'][$i];             
            $data['school_id'] = $school_id;
            
            $this->Common_model->common_update($data, $id,'id','tbl_weekdays');$i++; 
            }
			$this->session->set_flashdata('message', " Weekly holiday has been updated successfully ");
            redirect('admin/weekly_holiday');exit;
            
        }
    }
    
      
    /**Designation Portion**/
    public function designation_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['designation_list'] = $this->Admin_model->get_designation_list($school_id);
        $this->load->view('admin/designation_list', $data);
    }
    
    
    function designation_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['designation_name'] = $_POST['designation_name'];            
            $data['bn_designation_name'] = $_POST['bn_designation_name'];            
            $data['school_id'] = $school_id;
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            if($this->Common_model->common_insert($data,'tbl_designation'))
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
		
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('admin/designation_list');exit;
        }
    }
    
    public function designation_edit($designation_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['designation_list'] = $this->Admin_model->get_designation_info_by_id($school_id, $designation_id);
        $this->load->view('admin/designation_edit', $data);
    }
    
    function designation_edit_save(){
        if(isPostBack()){
            $designation_id = $_POST['designation_id'];
            $data['designation_name'] = $_POST['designation_name'];
            $data['bn_designation_name'] = $_POST['bn_designation_name'];
            if($this->Common_model->common_update($data, $designation_id,'designation_id','tbl_designation'))       
           $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
		
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('admin/designation_list');exit;                    
        }
    }
    
    function designation_delete($designation_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['designation_id'] = $designation_id;
		if($this->Common_model->common_delete($d_data,'tbl_designation'))
		 $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
		else
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted.</div>');
        redirect('admin/designation_list');exit;
    }
	   /**Institute Information **/
    public function institute_information(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
       
		$this->load->view('admin/institute_information', $data);
    }
    
    public function institute_information_edit(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $this->load->view('admin/institute_information_edit', $data);
    }
    
    function institute_information_edit_save(){
        if(isPostBack())
        {
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $school_information_id = $_POST['school_information_id'];

            if ($_FILES AND $_FILES['school_logo']['name'] ) 
            {
                $config['upload_path']   =   "upload/institute_logo";
                $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']      =   "720";
                $config['max_width']     =   "1500";
                $config['max_height']    =   "1500";			
                $config['file_name']    =   $school_id."_logo";			

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('school_logo'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                   $spinfo=$this->upload->data();
                   $school_logo = $spinfo['file_name'];
                }
                $data['school_name'] = $_POST['school_name'];
                $data['school_id'] = $school_id;
                $data['school_title'] = $_POST['school_title'];
                $data['established'] = $_POST['established'];
                $data['eiin_no'] = $_POST['eiin_no'];
                $data['school_index_no'] = $_POST['school_index_no'];
                $data['school_code'] = $_POST['school_code'];
                $data['upazilla_code'] = $_POST['upazilla_code'];
                $data['district_code'] = $_POST['district_code'];
                $data['founder'] = $_POST['founder'];
                $data['address'] = $_POST['address'];
                $data['post_office'] = $_POST['post_office'];
                $data['district'] = $_POST['district'];
                $data['police_station'] = $_POST['police_station'];
                $data['contact_no'] = $_POST['contact_no'];
                $data['email'] = $_POST['email'];
                $data['website'] = $_POST['website'];
                $data['logo'] = $school_logo;
                $data['created_on'] = date('Y-m-d H:i:s',time()); 
                if($this->Common_model->common_update($data, $school_information_id,'school_information_id','tbl_school_information')){
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				}
				else{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				}
                redirect('admin/institute_information','refresh');exit;  
            }
            else{
                $data['school_name'] = $_POST['school_name'];
                $data['school_id'] = $school_id;
                $data['school_title'] = $_POST['school_title'];
                $data['established'] = $_POST['established'];
                $data['eiin_no'] = $_POST['eiin_no'];
                $data['school_index_no'] = $_POST['school_index_no'];
                $data['school_code'] = $_POST['school_code'];
                $data['upazilla_code'] = $_POST['upazilla_code'];
                $data['district_code'] = $_POST['district_code'];
                $data['founder'] = $_POST['founder'];
                $data['address'] = $_POST['address'];
                $data['post_office'] = $_POST['post_office'];
                $data['district'] = $_POST['district'];
                $data['police_station'] = $_POST['police_station'];
                $data['contact_no'] = $_POST['contact_no'];
                $data['email'] = $_POST['email'];
                $data['website'] = $_POST['website'];
                $data['created_on'] = date('Y-m-d H:i:s',time()); 
							
                if($this->Common_model->common_update($data, $school_information_id,'school_information_id','tbl_school_information')){
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				}
				else{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				}
                redirect('admin/institute_information','refresh');exit;  
            }
        }
    }
    
    
        public function student_list_print(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['group_list'] = $this->Admin_model->get_group_list($school_id);
		$where='';
		if($_POST['class_id']){
			if($_POST['class_id']!="all"){
				$this->session->set_userdata('class_id', $_POST['class_id']);
			}
			elseif($_POST['class_id']=="all"){
				$this->session->unset_userdata('class_id');
				$this->session->unset_userdata('section_id');
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['section_id']){
			
			if($_POST['section_id']!="all"){
				$this->session->set_userdata('section_id', $_POST['section_id']);
			}
			elseif($_POST['section_id']=="all"){
				$this->session->unset_userdata('section_id');
			}
		}
		if($_POST['group_id']){
			
			if($_POST['group_id']!="all"){
				$this->session->set_userdata('group_id', $_POST['group_id']);
			}
			elseif($_POST['group_id']=="all"){
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['shift_id']){
			
			if($_POST['shift_id']!="all"){
				$this->session->set_userdata('shift_id', $_POST['shift_id']);
			}
			elseif($_POST['shift_id']=="all"){
				$this->session->unset_userdata('shift_id');
			}
		}
		if($_POST['gender_id']){
			
			if($_POST['gender_id']!="all"){
				$this->session->set_userdata('gender_id', $_POST['gender_id']);
			}
			elseif($_POST['gender_id']=="all"){
				$this->session->unset_userdata('gender_id');
			}
		}
		
		if($this->session->userdata('class_id'))
			$where.=' and tbl_student_class.class_id='.$this->session->userdata('class_id').' ';
		
		if($this->session->userdata('section_id'))
			$where.=' and tbl_student_class.section_id='.$this->session->userdata('section_id').' ';
		
		if($this->session->userdata('group_id'))
			$where.=' and tbl_student_class.group_id='.$this->session->userdata('group_id').' ';

		if($this->session->userdata('shift_id'))
			$where.=' and tbl_student_class.shift_id='.$this->session->userdata('shift_id').' ';

		if($this->session->userdata('gender_id'))
			$where.=' and tbl_student.gender="'.$this->session->userdata('gender_id').'" ';
		
        $data['student_list'] = $this->Admin_model->get_all_student_list($school_id,$where);
		
        //load the view and saved it into $html variable
        $html=$this->load->view('admin/student_list_print', $data, true);
 
        //this the the PDF filename that user will get to download
        $pdfFilePath = "Student_list.pdf";
 
        //load mPDF library
        $this->load->library('m_pdf');
 
       //generate the PDF from the given html
        $this->m_pdf->pdf->WriteHTML($html);
 
        //download it.
        $this->m_pdf->pdf->Output($pdfFilePath, "D"); 
		
		redirect('admin/student_list');exit;
        
    }
    
}
?>