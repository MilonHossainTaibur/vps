<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class School extends CI_Controller {

    public function __construct()
        {            
            session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('academic_model', 'Academic_model', true);
			$this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
            $this->load->library('form_validation');
            if($_SESSION['is_superadmin']!=2)
            {
                redirect('login');
                exit;
            }
					
        }
	

        public function index()
        {    
            $this->load->view('school/index');
        }
 
 function section_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['section_id']."'>".$sInfo['section_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
function subject_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
 function subject_list_ajax_ct()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id_ct($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
 /*** CT ***/
    
    public function set_ct_marks(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
		 $data['term_list'] = $this->Academic_model->get_term_list($school_id);
        $this->load->view('school/set_ct_marks', $data);
    }
	
	
    
    public function get_student_list_for_ct_json(){
        #$school_id = $_SESSION['school_id'];
		
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$subject_id = $_GET['subject_id'];
		$term_id = $_GET['term_id'];
		$exam_year = $_GET['exam_year'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id);
		$data['mark_dis_info'] = $this->Academic_model->get_mark_dis_info_subject_wise($school_id, $class_id,$group_id,$subject_id);
        $data['details'] =  array("class"=>$class_id,"section"=>$section_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"ct"=>$ct_id,"exam_year"=>$exam_year,"term_id"=>$term_id,"subject_id"=>$subject_id);
					
	
					$mainContent=$this->load->view('school/set_ct_marks_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	public function ct_marks_save(){
	    #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
		$exam_year = $_POST['exam_year'];
		$status = 1;
	
	$this->Academic_model->delete_ct_marks_info($school_id,$class_id,$section_id,$group_id,$shift_id,$term_id,$exam_year,$subject_id);
	
	$i=0;
	while($i<count($_POST['student_iddfsd'])){
	
	$student_id = $_POST['student_iddfsd'][$i];
	$marks = $_POST['obtain_marks'][$i];
	$remarks= $_POST['remarks'][$i];
	
	$data = array ('school_id'=>$school_id,'class_id'=>$class_id,'section_id'=>$section_id,'group_id'=>$group_id,'shift_id'=>$shift_id,'exam_year'=>$exam_year,'term_id'=>$term_id,'subject_id'=>$subject_id,'student_id'=>$student_id,'obtained_marks'=>$marks,'remarks'=>$remarks,'status'=>$status,'created_on'=>date('Y-m-d H:i:s',time()));
	           $this->Common_model->common_insert($data,'tbl_ct_marks');
			   
	$i++;
	}
     $this->session->set_flashdata('message', " CT marks has been Saved successfully "); 
		redirect('school/set_ct_marks','refresh');exit;
	
	 	}
    	
    /***  /CT ***/

	/*** Term  ***/	
	  function set_term_marks(){
      $school_id = 1;
      $data['class_list'] = $this->Admin_model->get_class_list($school_id);
      $data['term'] = $this->Academic_model->get_term_list($school_id); 
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
        $this->load->view('school/set_term_marks', $data);
	  }
      
      
	  function get_student_list_for_term_json(){
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
        $subject_id = $_GET['subject_id'];
		
		$data['subject_info'] = $this->Academic_model->get_subject_info($school_id, $subject_id);

        $data['student_list'] = $this->Academic_model->get_class_wise_student_list($school_id, $class_id,$section_id,$group_id,$shift_id);
		//$data['term_marks'] = $this->Academic_model->get_class_wise_student_list_term_marks($school_id, $class_id,$section_id,$term_id,$group_id,$shift_id);
		$data['term_details'] = $this->Academic_model->get_term_info_by_id($school_id,$term_id);
        $data['subject_name']=$this->Common_model->common_row_by_condition($subject_id,'subject_id','tbl_subject');
		$data['sml'] = $this->Academic_model->subject_wise_total_marks_class_wise($school_id,$subject_id,$class_id);
        $data['details'] =  array("class"=>$class_id,"section"=>$section_id,"term"=>$term_id,"exam_year"=>$exam_year,'subject_id'=>$subject_id,'group_id'=>$group_id,'shift_id'=>$shift_id);
	
					$mainContent=$this->load->view('school/set_term_marks_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }

public function term_marks_save(){
	    #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		
	$subject_type = $_POST['subject_type'];
		
	$class_id = $_POST['class_id'];
	$section_id = $_POST['section_id'];
	$group_id = $_POST['group_id'];
	$shift_id = $_POST['shift_id'];
	$term_id = $_POST['term_id'];
    $sub_id = $_POST['subject_id'];
    $exam_year = $_POST['exam_year'];
	$status = 1;
    $created_on = date('Y-m-d H:i:s',time());
     $this->Academic_model->delete_term_marks( $school_id,$class_id,$section_id,$group_id,$term_id,$sub_id,$exam_year,$shift_id);
     
	 if($subject_type==1)
	 {
		 $i=0;
		while($i<count($_POST['student_iddfsd'])){
		$student_id = $_POST['student_iddfsd'][$i];
		$subjective_marks = $_POST['subjective_marks'][$i];
		$remarks= $_POST['remarks'][$i];
		$data = array ('term_id'=>$term_id,'school_id'=>$school_id,'class_id'=>$class_id,'section_id'=>$section_id,'group_id'=>$group_id,'shift_id'=>$shift_id,'sub_id'=>$sub_id,'student_id'=>$student_id,'subjective_marks'=>$subjective_marks,'remarks'=>$remarks,'exam_year'=>$exam_year,'status'=>$status,'created_on'=>$created_on);
					 $this->Common_model->common_insert($data,'tbl_term_marks');
		
		$i++;
		}

	 }
	 elseif($subject_type==2)
	 {
		 $i=0;
		while($i<count($_POST['student_iddfsd'])){
		$student_id = $_POST['student_iddfsd'][$i];
		$subjective_marks = $_POST['subjective_marks'][$i];
		$objective_marks = $_POST['objective_marks'][$i];
		$remarks= $_POST['remarks'][$i];
		$data = array ('term_id'=>$term_id,'school_id'=>$school_id,'class_id'=>$class_id,'section_id'=>$section_id,'group_id'=>$group_id,'shift_id'=>$shift_id,'sub_id'=>$sub_id,'student_id'=>$student_id,'subjective_marks'=>$subjective_marks,'objective_marks'=>$objective_marks,'remarks'=>$remarks,'exam_year'=>$exam_year,'status'=>$status,'created_on'=>$created_on);
					 $this->Common_model->common_insert($data,'tbl_term_marks');
		
		$i++;
		}

	 }
	 else
	 {
     
		$i=0;
		while($i<count($_POST['student_iddfsd'])){
		$student_id = $_POST['student_iddfsd'][$i];
		$subjective_marks = $_POST['subjective_marks'][$i];
		$objective_marks = $_POST['objective_marks'][$i];
		$practical_marks = $_POST['practical_marks'][$i];
		$remarks= $_POST['remarks'][$i];
		$data = array ('term_id'=>$term_id,'school_id'=>$school_id,'class_id'=>$class_id,'section_id'=>$section_id,'group_id'=>$group_id,'shift_id'=>$shift_id,'sub_id'=>$sub_id,'student_id'=>$student_id,'subjective_marks'=>$subjective_marks,'objective_marks'=>$objective_marks,'practical_marks'=>$practical_marks,'remarks'=>$remarks,'exam_year'=>$exam_year,'status'=>$status,'created_on'=>$created_on);
					 $this->Common_model->common_insert($data,'tbl_term_marks');
		
		$i++;
		}
	 }
            $this->session->set_flashdata('message', " Term Marks has been saved successfully ");
		redirect('school/set_term_marks','refresh');exit;
	
	 	}
      
      /*** /Term  ***/
	
		 /***  tabulation sheet subject wise ***/
	public function tabulation_sheet_subject_wise()
      {
      #$school_id = $_SESSION['school_id'];
       $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
      $this->load->view('school/tabulation_sheet_subject_wise',$data);
      }
	public function tabulation_marks_subject_wise_json()
	{
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$subject_id = $_GET['subject_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
		$passing_id = $_GET['passing_id'];
		$type_id = $_POST['type_id'];
		
		$data['subject_infos'] = $this->Academic_model->subject_info_for_tabulation_sheet_subject_wise($school_id,$term_id,$exam_year,$class_id,$section_id,$subject_id);
		$data['school_infos'] = $this->Academic_model->admit_card_view_school($school_id);
        $data['student_list']=$this->Academic_model->get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id);
        $data['term']=$this->Academic_model->get_term_list_by_id($term_id,$school_id);
		$data['details']=array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);
		
			$mainContent=$this->load->view('school/tabulation_marks_subject_wise_json', $data, true);
        
		$result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  }
  public function tabulation_marks_subject_wise_print()
	{
		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		 $passing_id = $_POST['passing_id'];
		 $type_id = $_POST['type_id'];
		
        $data['subject_infos'] = $this->Academic_model->subject_info_for_tabulation_sheet_subject_wise($school_id,$term_id,$exam_year,$class_id,$section_id,$subject_id);
		 $data['school_infos'] = $this->Academic_model->admit_card_view_school($school_id);
		$data['student_list']=$this->Academic_model->get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id);
        $data['term']=$this->Academic_model->get_term_list_by_id($term_id,$school_id);
		$data['details']=array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);
		
		$this->load->view('school/tabulation_marks_subject_wise_print', $data);
	}

 public function marks_status_change()
 {
	  	$school_id = $_POST['school_id'];
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		$status = $_POST['status'];
		
		$data_term = array ('status'=>$status);
	            $where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"sub_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>1);		
				 $this->db->where($where_term);
                $this->db->update('tbl_term_marks', $data_term);
				
		$data = array ('status'=>$status);
	            $where = array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>1);
                $this->db->where($where);
                $this->db->update('tbl_ct_marks', $data);
		
		
				
				 $this->session->set_flashdata('message', " Final submition successful ");
		redirect('school/tabulation_sheet_subject_wise','refresh');exit;  
 }

}