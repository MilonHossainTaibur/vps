<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Accounting
*
* Version: 2.5.2
*
* Author: Ashiqur Rahman
*		  ashik75@gmail.com
*/

$config['tables']['users']           = 'users';

$config['author_email']                 = "ashik75@gmail.com";       
$config['author_mobile']                = "01726019427"; 
