﻿$(document).ready(function () {

    $('#btnLoad').click(function () {
        var classID = $('#ddlClass').val();
        var sectionID = $('#ddlSection').val();
        var shiftID = $('#ddlShift').val();
        var groupID = $('#ddlGroup').val();
        var sessionID = $('#ddlSession').val();
        var versionID = $('#ddlVersion').val();
        var className = $("#ddlClass option:selected").text();
        var roll = $('#txtRoll').val();
        // LoadGrid(sessionID, versionID, classID, shiftID, sectionID, groupID, roll, className);
        loadsource(sessionID, versionID, classID, shiftID, sectionID, groupID, roll, className);
    });
    $('body').on('click', '.ab', function () {
        var selectedID = $(this).attr('id'); 
        window.location.href = 'StudentDetails.aspx?StdId=' + selectedID + '';
    });
    // var aa;
 

    //grid.fnSetFilteringDelay(1000);

   
   
    //    function loadsource(sessionID, versionID, classID, shiftID, sectionID, groupID, roll, className) {
    //        $.ajax({
    //            dataType: 'json',
    //            cache: false,
    //            contentType: "application/json",
    //            url: 'StudentInfo.aspx/GetStudentInfoByParam',
    //            data: "{sessionID:'" + sessionID + "',classID:'" + classID + "',shiftID:'" + shiftID + "',sectionID:'" + sectionID + "',groupID:'" + groupID + "',versionID:'" + versionID + "',roll:'" + roll + "',className:'" + className + "'}",
    //            type: "POST",
    //            dataType: "json",
    //            success: function (data) {
    //                aa = data; 
    //                //console.log(aa);
    //            }
             
    //        });
    //      $('#myDataTable').dataTable({
    //        "iDisplayLength": 25,
    //        "aaData": aa,
    //        "aoColumns": [
    //            {
    //                "mDataProp": "PhotoUrl",
    //                "bSearchable": false,
    //                "bSortable": false,
    //                "mRender": function (oObj) {
    //                    return '<img width="80" height="60" src="' + (oObj != null ? oObj.replace("~", baseUrl) : '') + '" />';
    //                }
    //            },
    //            {
    //                "mDataProp": "StudentID",
    //                "bSearchable": false,
    //                "bSortable": false,
    //                "mRender": function (oObj) {
    //                    return '<a class="glyphicon glyphicon-log-out" style="cursor:pointer;" href="StudentDetails.aspx?StdId=' + oObj + '">View Details</a>';
    //                }
    //            },
    //            {
    //                "mDataProp": "FullName"
    //            }, {
    //                "mDataProp": "FatherFullName"
    //            }, {
    //                "mDataProp": "RollNo"
    //            }, {
    //                "mDataProp": "stuClassName"
    //            }, {
    //                "mDataProp": "SectionName"
    //            }, {
    //                "mDataProp": "ShiftName"
    //            }, {
    //                "mDataProp": "VersionTypeName"
    //            }
    //        ]
    //    });
    //    }

    //});
 

    function loadsource(sessionID, versionID, classID, shiftID, sectionID, groupID, roll, className) {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/";
        $.ajax({
            type: "POST",
            url: 'StudentInfo.aspx/GetStudentInfoByParam',
            data: "{sessionID:'" + sessionID + "',classID:'" + classID + "',shiftID:'" + shiftID + "',sectionID:'" + sectionID + "',groupID:'" + groupID + "',versionID:'" + versionID + "',roll:'" + roll + "',className:'" + className + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {

                $("#users tbody").text("");
                var i = 0;
                $.each(msg.d, function (index, item) { 
                    i = i + 1;
                    var link="StudentDetails.aspx?StdId='" + item.StudentID + "'";
                    $("#users tbody").append("<tr id='" + i + "'>" +
                    //"<td>'<img width='80' height='60' src='" + (item.StudentID != null ? item.StudentID.replace("~", baseUrl) : '') + "' /></td>" +
                    //"<td>'<img width='80' height='60' src='http://www.rajukcollege.net/Uploads/StudentPhoto/'" + item.StudentID + " /></td>" + 
                    //"<td><a class='ab' id='" + item.StudentID + "' cursor='ponter;'> View Details </a></td>" +
                    "<td>" + item.FullName + "</td>" +
                     "<td>" + item.FatherFullName + "</td>" +
                     "<td>" + item.RollNo + "</td>" +
                     "<td>" + item.stuClassName + "</td>" +
                     "<td>" + item.SectionName + "</td>" +
                     "<td>" + item.ShiftName + "</td>" +
                     "<td>" + item.VersionTypeName + "</td>" +
                 
                   
                    //<a class='ab' id='" + item.QuestionID + "'> Pick For Answer </a></td>" +
                   "</tr>");
                });
            },
            error: function () {
                alert("Failed to load");
            }
        });
    }
});

 
    